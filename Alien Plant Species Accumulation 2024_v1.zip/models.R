# libs
library(lme4)
library(lmerTest)
library(dplyr)

# header
awc_header_studyperiod <- read.csv("Data input/awc_plot_data.txt")

awc_header_studyperiod$PERC_NEOX <- awc_header_studyperiod$NB_NEOXS/awc_header_studyperiod$NB_SPECIES
awc_header_studyperiod$ASIN_SQRT_RATIO_NEOX <- asin(sqrt(awc_header_studyperiod$PERC_NEOX))
awc_header_studyperiod$PERC_ARCX <- awc_header_studyperiod$NB_ARCXS/awc_header_studyperiod$NB_SPECIES
awc_header_studyperiod$ASIN_SQRT_RATIO_ARCX <- asin(sqrt(awc_header_studyperiod$PERC_ARCX))
awc_header_studyperiod$ASIN_SQRT_RELABUN_NEOX <- asin(sqrt(awc_header_studyperiod$RELABUN_NEOX))
awc_header_studyperiod$ASIN_SQRT_RELABUN_ARCX <- asin(sqrt(awc_header_studyperiod$RELABUN_ARCX))

awc_header_studyperiod_invaded_neox <- subset(awc_header_studyperiod, RELABUN_NEOX > 0)
awc_header_studyperiod_invaded_arcx <- subset(awc_header_studyperiod, RELABUN_ARCX > 0)


#### Neophytes ####
# Basic models
model.output.neo.excl0.q1 <- glmer(PA_NEOX ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod,control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl0 <- summary(model.output.neo.excl0.q1)

model.output.neo.excl0.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox)
summary.model.neo.q2.excl0 <- summary(model.output.neo.excl0.q2)

model.output.neo.excl0.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox)
summary.model.neo.q3.excl0 <- summary(model.output.neo.excl0.q3)

# Model for excl1 Q1
model.output.neo.excl1.q1 <- glmer(PA_NEOX_EXCL_TOP1 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl1 <- summary(model.output.neo.excl1.q1)

# Data prep Q2,Q3 for excl1
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 1)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 1), paste0("RELABUN_NEOX_EXCL_TOP", 1), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP1 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 1)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP1 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 1)]))

# Model for excl1 Q2
model.output.neo.excl1.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP1 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl1 <- summary(model.output.neo.excl1.q2)

# Model for excl1 Q3
model.output.neo.excl1.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP1 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl1 <- summary(model.output.neo.excl1.q3)

cat("Model number 1 processed\n")

# Model for excl2 Q1
model.output.neo.excl2.q1 <- glmer(PA_NEOX_EXCL_TOP2 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl2 <- summary(model.output.neo.excl2.q1)

# Data prep Q2,Q3 for excl2
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 2)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 2), paste0("RELABUN_NEOX_EXCL_TOP", 2), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP2 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 2)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP2 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 2)]))

# Model for excl2 Q2
model.output.neo.excl2.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP2 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl2 <- summary(model.output.neo.excl2.q2)

# Model for excl2 Q3
model.output.neo.excl2.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP2 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl2 <- summary(model.output.neo.excl2.q3)
cat("Model number 2 processed\n")

# Model for excl3 Q1
model.output.neo.excl3.q1 <- glmer(PA_NEOX_EXCL_TOP3 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl3 <- summary(model.output.neo.excl3.q1)

# Data prep Q2,Q3 for excl3
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 3)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 3), paste0("RELABUN_NEOX_EXCL_TOP", 3), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP3 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 3)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP3 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 3)]))

# Model for excl3 Q2
model.output.neo.excl3.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP3 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl3 <- summary(model.output.neo.excl3.q2)

# Model for excl3 Q3
model.output.neo.excl3.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP3 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl3 <- summary(model.output.neo.excl3.q3)

cat("Model number 3 processed\n")

# Model for excl4 Q1
model.output.neo.excl4.q1 <- glmer(PA_NEOX_EXCL_TOP4 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl4 <- summary(model.output.neo.excl4.q1)

# Data prep Q2,Q3 for excl4
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 4)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 4), paste0("RELABUN_NEOX_EXCL_TOP", 4), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP4 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 4)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP4 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 4)]))

# Model for excl4 Q2
model.output.neo.excl4.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP4 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl4 <- summary(model.output.neo.excl4.q2)

# Model for excl4 Q3
model.output.neo.excl4.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP4 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl4 <- summary(model.output.neo.excl4.q3)

cat("Model number 4 processed\n")

# Model for excl5 Q1
model.output.neo.excl5.q1 <- glmer(PA_NEOX_EXCL_TOP5 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl5 <- summary(model.output.neo.excl5.q1)

# Data prep Q2,Q3 for excl5
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 5)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 5), paste0("RELABUN_NEOX_EXCL_TOP", 5), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP5 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 5)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP5 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 5)]))

# Model for excl5 Q2
model.output.neo.excl5.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP5 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl5 <- summary(model.output.neo.excl5.q2)

# Model for excl5 Q3
model.output.neo.excl5.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP5 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl5 <- summary(model.output.neo.excl5.q3)

cat("Model number 5 processed\n")

# Model for excl6 Q1
model.output.neo.excl6.q1 <- glmer(PA_NEOX_EXCL_TOP6 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl6 <- summary(model.output.neo.excl6.q1)

# Data prep Q2,Q3 for excl6
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 6)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 6), paste0("RELABUN_NEOX_EXCL_TOP", 6), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP6 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 6)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP6 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 6)]))

# Model for excl6 Q2
model.output.neo.excl6.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP6 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl6 <- summary(model.output.neo.excl6.q2)

# Model for excl6 Q3
model.output.neo.excl6.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP6 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl6 <- summary(model.output.neo.excl6.q3)

cat("Model number 6 processed\n")

# Model for excl7 Q1
model.output.neo.excl7.q1 <- glmer(PA_NEOX_EXCL_TOP7 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl7 <- summary(model.output.neo.excl7.q1)

# Data prep Q2,Q3 for excl7
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 7)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 7), paste0("RELABUN_NEOX_EXCL_TOP", 7), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP7 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 7)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP7 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 7)]))

# Model for excl7 Q2
model.output.neo.excl7.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP7 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl7 <- summary(model.output.neo.excl7.q2)

# Model for excl7 Q3
model.output.neo.excl7.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP7 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl7 <- summary(model.output.neo.excl7.q3)

cat("Model number 7 processed\n")

# Model for excl8 Q1
model.output.neo.excl8.q1 <- glmer(PA_NEOX_EXCL_TOP8 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl8 <- summary(model.output.neo.excl8.q1)

# Data prep Q2,Q3 for excl8
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 8)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 8), paste0("RELABUN_NEOX_EXCL_TOP", 8), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP8 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 8)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP8 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 8)]))

# Model for excl8 Q2
model.output.neo.excl8.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP8 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl8 <- summary(model.output.neo.excl8.q2)

# Model for excl8 Q3
model.output.neo.excl8.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP8 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl8 <- summary(model.output.neo.excl8.q3)

cat("Model number 8 processed\n")

# Model for excl9 Q1
model.output.neo.excl9.q1 <- glmer(PA_NEOX_EXCL_TOP9 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl9 <- summary(model.output.neo.excl9.q1)

# Data prep Q2,Q3 for excl9
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 9)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 9), paste0("RELABUN_NEOX_EXCL_TOP", 9), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP9 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 9)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP9 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 9)]))

# Model for excl9 Q2
model.output.neo.excl9.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP9 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl9 <- summary(model.output.neo.excl9.q2)

# Model for excl9 Q3
model.output.neo.excl9.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP9 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl9 <- summary(model.output.neo.excl9.q3)

cat("Model number 9 processed\n")

# Model for excl10 Q1
model.output.neo.excl10.q1 <- glmer(PA_NEOX_EXCL_TOP10 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl10 <- summary(model.output.neo.excl10.q1)

# Data prep Q2,Q3 for excl10
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 10)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 10), paste0("RELABUN_NEOX_EXCL_TOP", 10), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP10 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 10)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP10 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 10)]))

# Model for excl10 Q2
model.output.neo.excl10.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP10 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl10 <- summary(model.output.neo.excl10.q2)

# Model for excl10 Q3
model.output.neo.excl10.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP10 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl10 <- summary(model.output.neo.excl10.q3)

cat("Model number 10 processed\n")

# Model for excl11 Q1
model.output.neo.excl11.q1 <- glmer(PA_NEOX_EXCL_TOP11 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl11 <- summary(model.output.neo.excl11.q1)

# Data prep Q2,Q3 for excl11
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 11)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 11), paste0("RELABUN_NEOX_EXCL_TOP", 11), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP11 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 11)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP11 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 11)]))

# Model for excl11 Q2
model.output.neo.excl11.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP11 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl11 <- summary(model.output.neo.excl11.q2)

# Model for excl11 Q3
model.output.neo.excl11.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP11 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl11 <- summary(model.output.neo.excl11.q3)

cat("Model number 11 processed\n")

# Model for excl12 Q1
model.output.neo.excl12.q1 <- glmer(PA_NEOX_EXCL_TOP12 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl12 <- summary(model.output.neo.excl12.q1)

# Data prep Q2,Q3 for excl12
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 12)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 12), paste0("RELABUN_NEOX_EXCL_TOP", 12), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP12 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 12)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP12 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 12)]))

# Model for excl12 Q2
model.output.neo.excl12.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP12 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl12 <- summary(model.output.neo.excl12.q2)

# Model for excl12 Q3
model.output.neo.excl12.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP12 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl12 <- summary(model.output.neo.excl12.q3)

cat("Model number 12 processed\n")

# Model for excl13 Q1
model.output.neo.excl13.q1 <- glmer(PA_NEOX_EXCL_TOP13 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl13 <- summary(model.output.neo.excl13.q1)

# Data prep Q2,Q3 for excl13
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 13)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 13), paste0("RELABUN_NEOX_EXCL_TOP", 13), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP13 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 13)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP13 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 13)]))

# Model for excl13 Q2
model.output.neo.excl13.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP13 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl13 <- summary(model.output.neo.excl13.q2)

# Model for excl13 Q3
model.output.neo.excl13.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP13 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl13 <- summary(model.output.neo.excl13.q3)

cat("Model number 13 processed\n")

# Model for excl14 Q1
model.output.neo.excl14.q1 <- glmer(PA_NEOX_EXCL_TOP14 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl14 <- summary(model.output.neo.excl14.q1)

# Data prep Q2,Q3 for excl14
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 14)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 14), paste0("RELABUN_NEOX_EXCL_TOP", 14), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP14 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 14)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP14 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 14)]))

# Model for excl14 Q2
model.output.neo.excl14.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP14 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl14 <- summary(model.output.neo.excl14.q2)

# Model for excl14 Q3
model.output.neo.excl14.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP14 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl14 <- summary(model.output.neo.excl14.q3)

cat("Model number 14 processed\n")

# Model for excl15 Q1
model.output.neo.excl15.q1 <- glmer(PA_NEOX_EXCL_TOP15 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl15 <- summary(model.output.neo.excl15.q1)

# Data prep Q2,Q3 for excl15
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 15)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 15), paste0("RELABUN_NEOX_EXCL_TOP", 15), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP15 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 15)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP15 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 15)]))

# Model for excl15 Q2
model.output.neo.excl15.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP15 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl15 <- summary(model.output.neo.excl15.q2)

# Model for excl15 Q3
model.output.neo.excl15.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP15 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl15 <- summary(model.output.neo.excl15.q3)

cat("Model number 15 processed\n")

# Model for excl16 Q1
model.output.neo.excl16.q1 <- glmer(PA_NEOX_EXCL_TOP16 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl16 <- summary(model.output.neo.excl16.q1)

# Data prep Q2,Q3 for excl16
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 16)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 16), paste0("RELABUN_NEOX_EXCL_TOP", 16), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP16 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 16)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP16 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 16)]))

# Model for excl16 Q2
model.output.neo.excl16.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP16 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl16 <- summary(model.output.neo.excl16.q2)

# Model for excl16 Q3
model.output.neo.excl16.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP16 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl16 <- summary(model.output.neo.excl16.q3)

cat("Model number 16 processed\n")

# Model for excl17 Q1
model.output.neo.excl17.q1 <- glmer(PA_NEOX_EXCL_TOP17 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl17 <- summary(model.output.neo.excl17.q1)

# Data prep Q2,Q3 for excl17
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 17)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 17), paste0("RELABUN_NEOX_EXCL_TOP", 17), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP17 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 17)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP17 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 17)]))

# Model for excl17 Q2
model.output.neo.excl17.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP17 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl17 <- summary(model.output.neo.excl17.q2)

# Model for excl17 Q3
model.output.neo.excl17.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP17 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl17 <- summary(model.output.neo.excl17.q3)

cat("Model number 17 processed\n")

# Model for excl18 Q1
model.output.neo.excl18.q1 <- glmer(PA_NEOX_EXCL_TOP18 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl18 <- summary(model.output.neo.excl18.q1)

# Data prep Q2,Q3 for excl18
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 18)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 18), paste0("RELABUN_NEOX_EXCL_TOP", 18), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP18 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 18)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP18 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 18)]))

# Model for excl18 Q2
model.output.neo.excl18.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP18 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl18 <- summary(model.output.neo.excl18.q2)

# Model for excl18 Q3
model.output.neo.excl18.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP18 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl18 <- summary(model.output.neo.excl18.q3)

cat("Model number 18 processed\n")

# Model for excl19 Q1
model.output.neo.excl19.q1 <- glmer(PA_NEOX_EXCL_TOP19 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl19 <- summary(model.output.neo.excl19.q1)

# Data prep Q2,Q3 for excl19
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 19)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 19), paste0("RELABUN_NEOX_EXCL_TOP", 19), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP19 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 19)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP19 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 19)]))

# Model for excl19 Q2
model.output.neo.excl19.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP19 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl19 <- summary(model.output.neo.excl19.q2)

# Model for excl19 Q3
model.output.neo.excl19.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP19 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl19 <- summary(model.output.neo.excl19.q3)

cat("Model number 19 processed\n")

# Model for excl20 Q1
model.output.neo.excl20.q1 <- glmer(PA_NEOX_EXCL_TOP20 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl20 <- summary(model.output.neo.excl20.q1)

# Data prep Q2,Q3 for excl20
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 20)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 20), paste0("RELABUN_NEOX_EXCL_TOP", 20), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP20 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 20)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP20 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 20)]))

# Model for excl20 Q2
model.output.neo.excl20.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP20 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl20 <- summary(model.output.neo.excl20.q2)

# Model for excl20 Q3
model.output.neo.excl20.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP20 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl20 <- summary(model.output.neo.excl20.q3)

cat("Model number 20 processed\n")

# Model for excl21 Q1
model.output.neo.excl21.q1 <- glmer(PA_NEOX_EXCL_TOP21 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl21 <- summary(model.output.neo.excl21.q1)

# Data prep Q2,Q3 for excl21
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 21)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 21), paste0("RELABUN_NEOX_EXCL_TOP", 21), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP21 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 21)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP21 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 21)]))

# Model for excl21 Q2
model.output.neo.excl21.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP21 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl21 <- summary(model.output.neo.excl21.q2)

# Model for excl21 Q3
model.output.neo.excl21.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP21 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl21 <- summary(model.output.neo.excl21.q3)

cat("Model number 21 processed\n")

# Model for excl22 Q1
model.output.neo.excl22.q1 <- glmer(PA_NEOX_EXCL_TOP22 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl22 <- summary(model.output.neo.excl22.q1)

# Data prep Q2,Q3 for excl22
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 22)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 22), paste0("RELABUN_NEOX_EXCL_TOP", 22), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP22 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 22)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP22 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 22)]))

# Model for excl22 Q2
model.output.neo.excl22.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP22 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl22 <- summary(model.output.neo.excl22.q2)

# Model for excl22 Q3
model.output.neo.excl22.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP22 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl22 <- summary(model.output.neo.excl22.q3)

cat("Model number 22 processed\n")

# Model for excl23 Q1
model.output.neo.excl23.q1 <- glmer(PA_NEOX_EXCL_TOP23 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl23 <- summary(model.output.neo.excl23.q1)

# Data prep Q2,Q3 for excl23
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 23)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 23), paste0("RELABUN_NEOX_EXCL_TOP", 23), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP23 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 23)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP23 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 23)]))

# Model for excl23 Q2
model.output.neo.excl23.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP23 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl23 <- summary(model.output.neo.excl23.q2)

# Model for excl23 Q3
model.output.neo.excl23.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP23 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl23 <- summary(model.output.neo.excl23.q3)

cat("Model number 23 processed\n")

# Model for excl24 Q1
model.output.neo.excl24.q1 <- glmer(PA_NEOX_EXCL_TOP24 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl24 <- summary(model.output.neo.excl24.q1)

# Data prep Q2,Q3 for excl24
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 24)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 24), paste0("RELABUN_NEOX_EXCL_TOP", 24), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP24 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 24)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP24 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 24)]))

# Model for excl24 Q2
model.output.neo.excl24.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP24 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl24 <- summary(model.output.neo.excl24.q2)

# Model for excl24 Q3
model.output.neo.excl24.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP24 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl24 <- summary(model.output.neo.excl24.q3)

cat("Model number 24 processed\n")

# Model for excl25 Q1
model.output.neo.excl25.q1 <- glmer(PA_NEOX_EXCL_TOP25 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl25 <- summary(model.output.neo.excl25.q1)

# Data prep Q2,Q3 for excl25
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 25)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 25), paste0("RELABUN_NEOX_EXCL_TOP", 25), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP25 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 25)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP25 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 25)]))

# Model for excl25 Q2
model.output.neo.excl25.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP25 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl25 <- summary(model.output.neo.excl25.q2)

# Model for excl25 Q3
model.output.neo.excl25.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP25 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl25 <- summary(model.output.neo.excl25.q3)

cat("Model number 25 processed\n")

# Model for excl26 Q1
model.output.neo.excl26.q1 <- glmer(PA_NEOX_EXCL_TOP26 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl26 <- summary(model.output.neo.excl26.q1)

# Data prep Q2,Q3 for excl26
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 26)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 26), paste0("RELABUN_NEOX_EXCL_TOP", 26), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP26 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 26)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP26 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 26)]))

# Model for excl26 Q2
model.output.neo.excl26.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP26 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl26 <- summary(model.output.neo.excl26.q2)

# Model for excl26 Q3
model.output.neo.excl26.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP26 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl26 <- summary(model.output.neo.excl26.q3)

cat("Model number 26 processed\n")

# Model for excl27 Q1
model.output.neo.excl27.q1 <- glmer(PA_NEOX_EXCL_TOP27 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl27 <- summary(model.output.neo.excl27.q1)

# Data prep Q2,Q3 for excl27
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 27)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 27), paste0("RELABUN_NEOX_EXCL_TOP", 27), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP27 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 27)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP27 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 27)]))

# Model for excl27 Q2
model.output.neo.excl27.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP27 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl27 <- summary(model.output.neo.excl27.q2)

# Model for excl27 Q3
model.output.neo.excl27.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP27 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl27 <- summary(model.output.neo.excl27.q3)

cat("Model number 27 processed\n")

# Model for excl28 Q1
model.output.neo.excl28.q1 <- glmer(PA_NEOX_EXCL_TOP28 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl28 <- summary(model.output.neo.excl28.q1)

# Data prep Q2,Q3 for excl28
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 28)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 28), paste0("RELABUN_NEOX_EXCL_TOP", 28), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP28 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 28)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP28 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 28)]))

# Model for excl28 Q2
model.output.neo.excl28.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP28 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl28 <- summary(model.output.neo.excl28.q2)

# Model for excl28 Q3
model.output.neo.excl28.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP28 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl28 <- summary(model.output.neo.excl28.q3)

cat("Model number 28 processed\n")

# Model for excl29 Q1
model.output.neo.excl29.q1 <- glmer(PA_NEOX_EXCL_TOP29 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl29 <- summary(model.output.neo.excl29.q1)

# Data prep Q2,Q3 for excl29
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 29)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 29), paste0("RELABUN_NEOX_EXCL_TOP", 29), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP29 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 29)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP29 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 29)]))

# Model for excl29 Q2
model.output.neo.excl29.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP29 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl29 <- summary(model.output.neo.excl29.q2)

# Model for excl29 Q3
model.output.neo.excl29.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP29 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl29 <- summary(model.output.neo.excl29.q3)

cat("Model number 29 processed\n")

# Model for excl30 Q1
model.output.neo.excl30.q1 <- glmer(PA_NEOX_EXCL_TOP30 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl30 <- summary(model.output.neo.excl30.q1)

# Data prep Q2,Q3 for excl30
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 30)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 30), paste0("RELABUN_NEOX_EXCL_TOP", 30), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP30 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 30)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP30 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 30)]))

# Model for excl30 Q2
model.output.neo.excl30.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP30 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl30 <- summary(model.output.neo.excl30.q2)

# Model for excl30 Q3
model.output.neo.excl30.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP30 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl30 <- summary(model.output.neo.excl30.q3)

cat("Model number 30 processed\n")

# Model for excl31 Q1
model.output.neo.excl31.q1 <- glmer(PA_NEOX_EXCL_TOP31 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl31 <- summary(model.output.neo.excl31.q1)

# Data prep Q2,Q3 for excl31
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 31)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 31), paste0("RELABUN_NEOX_EXCL_TOP", 31), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP31 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 31)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP31 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 31)]))

# Model for excl31 Q2
model.output.neo.excl31.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP31 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl31 <- summary(model.output.neo.excl31.q2)

# Model for excl31 Q3
model.output.neo.excl31.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP31 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl31 <- summary(model.output.neo.excl31.q3)

cat("Model number 31 processed\n")

# Model for excl32 Q1
model.output.neo.excl32.q1 <- glmer(PA_NEOX_EXCL_TOP32 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl32 <- summary(model.output.neo.excl32.q1)

# Data prep Q2,Q3 for excl32
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 32)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 32), paste0("RELABUN_NEOX_EXCL_TOP", 32), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP32 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 32)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP32 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 32)]))

# Model for excl32 Q2
model.output.neo.excl32.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP32 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl32 <- summary(model.output.neo.excl32.q2)

# Model for excl32 Q3
model.output.neo.excl32.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP32 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl32 <- summary(model.output.neo.excl32.q3)

cat("Model number 32 processed\n")

# Model for excl33 Q1
model.output.neo.excl33.q1 <- glmer(PA_NEOX_EXCL_TOP33 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl33 <- summary(model.output.neo.excl33.q1)

# Data prep Q2,Q3 for excl33
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 33)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 33), paste0("RELABUN_NEOX_EXCL_TOP", 33), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP33 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 33)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP33 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 33)]))

# Model for excl33 Q2
model.output.neo.excl33.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP33 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl33 <- summary(model.output.neo.excl33.q2)

# Model for excl33 Q3
model.output.neo.excl33.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP33 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl33 <- summary(model.output.neo.excl33.q3)

cat("Model number 33 processed\n")

# Model for excl34 Q1
model.output.neo.excl34.q1 <- glmer(PA_NEOX_EXCL_TOP34 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl34 <- summary(model.output.neo.excl34.q1)

# Data prep Q2,Q3 for excl34
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 34)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 34), paste0("RELABUN_NEOX_EXCL_TOP", 34), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP34 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 34)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP34 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 34)]))

# Model for excl34 Q2
model.output.neo.excl34.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP34 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl34 <- summary(model.output.neo.excl34.q2)

# Model for excl34 Q3
model.output.neo.excl34.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP34 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl34 <- summary(model.output.neo.excl34.q3)

cat("Model number 34 processed\n")

# Model for excl35 Q1
model.output.neo.excl35.q1 <- glmer(PA_NEOX_EXCL_TOP35 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl35 <- summary(model.output.neo.excl35.q1)

# Data prep Q2,Q3 for excl35
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 35)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 35), paste0("RELABUN_NEOX_EXCL_TOP", 35), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP35 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 35)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP35 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 35)]))

# Model for excl35 Q2
model.output.neo.excl35.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP35 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl35 <- summary(model.output.neo.excl35.q2)

# Model for excl35 Q3
model.output.neo.excl35.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP35 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl35 <- summary(model.output.neo.excl35.q3)

cat("Model number 35 processed\n")

# Model for excl36 Q1
model.output.neo.excl36.q1 <- glmer(PA_NEOX_EXCL_TOP36 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl36 <- summary(model.output.neo.excl36.q1)

# Data prep Q2,Q3 for excl36
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 36)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 36), paste0("RELABUN_NEOX_EXCL_TOP", 36), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP36 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 36)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP36 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 36)]))

# Model for excl36 Q2
model.output.neo.excl36.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP36 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl36 <- summary(model.output.neo.excl36.q2)

# Model for excl36 Q3
model.output.neo.excl36.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP36 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl36 <- summary(model.output.neo.excl36.q3)

cat("Model number 36 processed\n")

# Model for excl37 Q1
model.output.neo.excl37.q1 <- glmer(PA_NEOX_EXCL_TOP37 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl37 <- summary(model.output.neo.excl37.q1)

# Data prep Q2,Q3 for excl37
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 37)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 37), paste0("RELABUN_NEOX_EXCL_TOP", 37), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP37 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 37)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP37 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 37)]))

# Model for excl37 Q2
model.output.neo.excl37.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP37 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl37 <- summary(model.output.neo.excl37.q2)

# Model for excl37 Q3
model.output.neo.excl37.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP37 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl37 <- summary(model.output.neo.excl37.q3)

cat("Model number 37 processed\n")

# Model for excl38 Q1
model.output.neo.excl38.q1 <- glmer(PA_NEOX_EXCL_TOP38 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl38 <- summary(model.output.neo.excl38.q1)

# Data prep Q2,Q3 for excl38
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 38)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 38), paste0("RELABUN_NEOX_EXCL_TOP", 38), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP38 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 38)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP38 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 38)]))

# Model for excl38 Q2
model.output.neo.excl38.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP38 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl38 <- summary(model.output.neo.excl38.q2)

# Model for excl38 Q3
model.output.neo.excl38.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP38 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl38 <- summary(model.output.neo.excl38.q3)

cat("Model number 38 processed\n")

# Model for excl39 Q1
model.output.neo.excl39.q1 <- glmer(PA_NEOX_EXCL_TOP39 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl39 <- summary(model.output.neo.excl39.q1)

# Data prep Q2,Q3 for excl39
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 39)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 39), paste0("RELABUN_NEOX_EXCL_TOP", 39), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP39 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 39)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP39 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 39)]))

# Model for excl39 Q2
model.output.neo.excl39.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP39 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl39 <- summary(model.output.neo.excl39.q2)

# Model for excl39 Q3
model.output.neo.excl39.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP39 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl39 <- summary(model.output.neo.excl39.q3)

cat("Model number 39 processed\n")

# Model for excl40 Q1
model.output.neo.excl40.q1 <- glmer(PA_NEOX_EXCL_TOP40 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl40 <- summary(model.output.neo.excl40.q1)

# Data prep Q2,Q3 for excl40
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 40)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 40), paste0("RELABUN_NEOX_EXCL_TOP", 40), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP40 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 40)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP40 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 40)]))

# Model for excl40 Q2
model.output.neo.excl40.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP40 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl40 <- summary(model.output.neo.excl40.q2)

# Model for excl40 Q3
model.output.neo.excl40.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP40 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl40 <- summary(model.output.neo.excl40.q3)

cat("Model number 40 processed\n")

# Model for excl41 Q1
model.output.neo.excl41.q1 <- glmer(PA_NEOX_EXCL_TOP41 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl41 <- summary(model.output.neo.excl41.q1)

# Data prep Q2,Q3 for excl41
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 41)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 41), paste0("RELABUN_NEOX_EXCL_TOP", 41), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP41 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 41)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP41 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 41)]))

# Model for excl41 Q2
model.output.neo.excl41.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP41 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl41 <- summary(model.output.neo.excl41.q2)

# Model for excl41 Q3
model.output.neo.excl41.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP41 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl41 <- summary(model.output.neo.excl41.q3)

cat("Model number 41 processed\n")

# Model for excl42 Q1
model.output.neo.excl42.q1 <- glmer(PA_NEOX_EXCL_TOP42 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl42 <- summary(model.output.neo.excl42.q1)

# Data prep Q2,Q3 for excl42
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 42)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 42), paste0("RELABUN_NEOX_EXCL_TOP", 42), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP42 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 42)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP42 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 42)]))

# Model for excl42 Q2
model.output.neo.excl42.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP42 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl42 <- summary(model.output.neo.excl42.q2)

# Model for excl42 Q3
model.output.neo.excl42.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP42 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl42 <- summary(model.output.neo.excl42.q3)

cat("Model number 42 processed\n")

# Model for excl43 Q1
model.output.neo.excl43.q1 <- glmer(PA_NEOX_EXCL_TOP43 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl43 <- summary(model.output.neo.excl43.q1)

# Data prep Q2,Q3 for excl43
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 43)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 43), paste0("RELABUN_NEOX_EXCL_TOP", 43), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP43 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 43)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP43 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 43)]))

# Model for excl43 Q2
model.output.neo.excl43.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP43 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl43 <- summary(model.output.neo.excl43.q2)

# Model for excl43 Q3
model.output.neo.excl43.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP43 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl43 <- summary(model.output.neo.excl43.q3)

cat("Model number 43 processed\n")

# Model for excl44 Q1
model.output.neo.excl44.q1 <- glmer(PA_NEOX_EXCL_TOP44 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl44 <- summary(model.output.neo.excl44.q1)

# Data prep Q2,Q3 for excl44
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 44)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 44), paste0("RELABUN_NEOX_EXCL_TOP", 44), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP44 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 44)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP44 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 44)]))

# Model for excl44 Q2
model.output.neo.excl44.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP44 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl44 <- summary(model.output.neo.excl44.q2)

# Model for excl44 Q3
model.output.neo.excl44.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP44 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl44 <- summary(model.output.neo.excl44.q3)

cat("Model number 44 processed\n")

# Model for excl45 Q1
model.output.neo.excl45.q1 <- glmer(PA_NEOX_EXCL_TOP45 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl45 <- summary(model.output.neo.excl45.q1)

# Data prep Q2,Q3 for excl45
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 45)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 45), paste0("RELABUN_NEOX_EXCL_TOP", 45), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP45 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 45)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP45 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 45)]))

# Model for excl45 Q2
model.output.neo.excl45.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP45 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl45 <- summary(model.output.neo.excl45.q2)

# Model for excl45 Q3
model.output.neo.excl45.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP45 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl45 <- summary(model.output.neo.excl45.q3)

cat("Model number 45 processed\n")

# Model for excl46 Q1
model.output.neo.excl46.q1 <- glmer(PA_NEOX_EXCL_TOP46 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl46 <- summary(model.output.neo.excl46.q1)

# Data prep Q2,Q3 for excl46
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 46)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 46), paste0("RELABUN_NEOX_EXCL_TOP", 46), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP46 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 46)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP46 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 46)]))

# Model for excl46 Q2
model.output.neo.excl46.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP46 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl46 <- summary(model.output.neo.excl46.q2)

# Model for excl46 Q3
model.output.neo.excl46.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP46 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl46 <- summary(model.output.neo.excl46.q3)

cat("Model number 46 processed\n")

# Model for excl47 Q1
model.output.neo.excl47.q1 <- glmer(PA_NEOX_EXCL_TOP47 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl47 <- summary(model.output.neo.excl47.q1)

# Data prep Q2,Q3 for excl47
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 47)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 47), paste0("RELABUN_NEOX_EXCL_TOP", 47), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP47 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 47)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP47 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 47)]))

# Model for excl47 Q2
model.output.neo.excl47.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP47 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl47 <- summary(model.output.neo.excl47.q2)

# Model for excl47 Q3
model.output.neo.excl47.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP47 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl47 <- summary(model.output.neo.excl47.q3)

cat("Model number 47 processed\n")

# Model for excl48 Q1
model.output.neo.excl48.q1 <- glmer(PA_NEOX_EXCL_TOP48 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl48 <- summary(model.output.neo.excl48.q1)

# Data prep Q2,Q3 for excl48
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 48)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 48), paste0("RELABUN_NEOX_EXCL_TOP", 48), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP48 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 48)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP48 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 48)]))

# Model for excl48 Q2
model.output.neo.excl48.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP48 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl48 <- summary(model.output.neo.excl48.q2)

# Model for excl48 Q3
model.output.neo.excl48.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP48 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl48 <- summary(model.output.neo.excl48.q3)

cat("Model number 48 processed\n")

# Model for excl49 Q1
model.output.neo.excl49.q1 <- glmer(PA_NEOX_EXCL_TOP49 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl49 <- summary(model.output.neo.excl49.q1)

# Data prep Q2,Q3 for excl49
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 49)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 49), paste0("RELABUN_NEOX_EXCL_TOP", 49), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP49 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 49)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP49 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 49)]))

# Model for excl49 Q2
model.output.neo.excl49.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP49 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl49 <- summary(model.output.neo.excl49.q2)

# Model for excl49 Q3
model.output.neo.excl49.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP49 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl49 <- summary(model.output.neo.excl49.q3)

cat("Model number 49 processed\n")

# Model for excl50 Q1
model.output.neo.excl50.q1 <- glmer(PA_NEOX_EXCL_TOP50 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl50 <- summary(model.output.neo.excl50.q1)

# Data prep Q2,Q3 for excl50
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 50)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 50), paste0("RELABUN_NEOX_EXCL_TOP", 50), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP50 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 50)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP50 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 50)]))

# Model for excl50 Q2
model.output.neo.excl50.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP50 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl50 <- summary(model.output.neo.excl50.q2)

# Model for excl50 Q3
model.output.neo.excl50.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP50 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl50 <- summary(model.output.neo.excl50.q3)

cat("Model number 50 processed\n")

# Model for excl51 Q1
model.output.neo.excl51.q1 <- glmer(PA_NEOX_EXCL_TOP51 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl51 <- summary(model.output.neo.excl51.q1)

# Data prep Q2,Q3 for excl51
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 51)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 51), paste0("RELABUN_NEOX_EXCL_TOP", 51), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP51 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 51)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP51 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 51)]))

# Model for excl51 Q2
model.output.neo.excl51.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP51 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl51 <- summary(model.output.neo.excl51.q2)

# Model for excl51 Q3
model.output.neo.excl51.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP51 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl51 <- summary(model.output.neo.excl51.q3)

cat("Model number 51 processed\n")

# Model for excl52 Q1
model.output.neo.excl52.q1 <- glmer(PA_NEOX_EXCL_TOP52 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl52 <- summary(model.output.neo.excl52.q1)

# Data prep Q2,Q3 for excl52
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 52)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 52), paste0("RELABUN_NEOX_EXCL_TOP", 52), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP52 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 52)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP52 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 52)]))

# Model for excl52 Q2
model.output.neo.excl52.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP52 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl52 <- summary(model.output.neo.excl52.q2)

# Model for excl52 Q3
model.output.neo.excl52.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP52 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl52 <- summary(model.output.neo.excl52.q3)

cat("Model number 52 processed\n")

# Model for excl53 Q1
model.output.neo.excl53.q1 <- glmer(PA_NEOX_EXCL_TOP53 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl53 <- summary(model.output.neo.excl53.q1)

# Data prep Q2,Q3 for excl53
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 53)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 53), paste0("RELABUN_NEOX_EXCL_TOP", 53), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP53 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 53)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP53 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 53)]))

# Model for excl53 Q2
model.output.neo.excl53.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP53 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl53 <- summary(model.output.neo.excl53.q2)

# Model for excl53 Q3
model.output.neo.excl53.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP53 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl53 <- summary(model.output.neo.excl53.q3)

cat("Model number 53 processed\n")

# Model for excl54 Q1
model.output.neo.excl54.q1 <- glmer(PA_NEOX_EXCL_TOP54 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl54 <- summary(model.output.neo.excl54.q1)

# Data prep Q2,Q3 for excl54
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 54)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 54), paste0("RELABUN_NEOX_EXCL_TOP", 54), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP54 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 54)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP54 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 54)]))

# Model for excl54 Q2
model.output.neo.excl54.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP54 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl54 <- summary(model.output.neo.excl54.q2)

# Model for excl54 Q3
model.output.neo.excl54.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP54 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl54 <- summary(model.output.neo.excl54.q3)

cat("Model number 54 processed\n")

# Model for excl55 Q1
model.output.neo.excl55.q1 <- glmer(PA_NEOX_EXCL_TOP55 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl55 <- summary(model.output.neo.excl55.q1)

# Data prep Q2,Q3 for excl55
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 55)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 55), paste0("RELABUN_NEOX_EXCL_TOP", 55), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP55 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 55)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP55 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 55)]))

# Model for excl55 Q2
model.output.neo.excl55.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP55 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl55 <- summary(model.output.neo.excl55.q2)

# Model for excl55 Q3
model.output.neo.excl55.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP55 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl55 <- summary(model.output.neo.excl55.q3)

cat("Model number 55 processed\n")

# Model for excl56 Q1
model.output.neo.excl56.q1 <- glmer(PA_NEOX_EXCL_TOP56 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl56 <- summary(model.output.neo.excl56.q1)

# Data prep Q2,Q3 for excl56
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 56)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 56), paste0("RELABUN_NEOX_EXCL_TOP", 56), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP56 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 56)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP56 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 56)]))

# Model for excl56 Q2
model.output.neo.excl56.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP56 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl56 <- summary(model.output.neo.excl56.q2)

# Model for excl56 Q3
model.output.neo.excl56.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP56 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl56 <- summary(model.output.neo.excl56.q3)

cat("Model number 56 processed\n")

# Model for excl57 Q1
model.output.neo.excl57.q1 <- glmer(PA_NEOX_EXCL_TOP57 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl57 <- summary(model.output.neo.excl57.q1)

# Data prep Q2,Q3 for excl57
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 57)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 57), paste0("RELABUN_NEOX_EXCL_TOP", 57), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP57 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 57)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP57 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 57)]))

# Model for excl57 Q2
model.output.neo.excl57.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP57 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl57 <- summary(model.output.neo.excl57.q2)

# Model for excl57 Q3
model.output.neo.excl57.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP57 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl57 <- summary(model.output.neo.excl57.q3)

cat("Model number 57 processed\n")

# Model for excl58 Q1
model.output.neo.excl58.q1 <- glmer(PA_NEOX_EXCL_TOP58 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl58 <- summary(model.output.neo.excl58.q1)

# Data prep Q2,Q3 for excl58
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 58)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 58), paste0("RELABUN_NEOX_EXCL_TOP", 58), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP58 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 58)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP58 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 58)]))

# Model for excl58 Q2
model.output.neo.excl58.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP58 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl58 <- summary(model.output.neo.excl58.q2)

# Model for excl58 Q3
model.output.neo.excl58.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP58 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl58 <- summary(model.output.neo.excl58.q3)

cat("Model number 58 processed\n")

# Model for excl59 Q1
model.output.neo.excl59.q1 <- glmer(PA_NEOX_EXCL_TOP59 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl59 <- summary(model.output.neo.excl59.q1)

# Data prep Q2,Q3 for excl59
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 59)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 59), paste0("RELABUN_NEOX_EXCL_TOP", 59), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP59 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 59)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP59 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 59)]))

# Model for excl59 Q2
model.output.neo.excl59.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP59 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl59 <- summary(model.output.neo.excl59.q2)

# Model for excl59 Q3
model.output.neo.excl59.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP59 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl59 <- summary(model.output.neo.excl59.q3)

cat("Model number 59 processed\n")

# Model for excl60 Q1
model.output.neo.excl60.q1 <- glmer(PA_NEOX_EXCL_TOP60 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl60 <- summary(model.output.neo.excl60.q1)

# Data prep Q2,Q3 for excl60
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 60)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 60), paste0("RELABUN_NEOX_EXCL_TOP", 60), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP60 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 60)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP60 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 60)]))

# Model for excl60 Q2
model.output.neo.excl60.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP60 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl60 <- summary(model.output.neo.excl60.q2)

# Model for excl60 Q3
model.output.neo.excl60.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP60 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl60 <- summary(model.output.neo.excl60.q3)

cat("Model number 60 processed\n")

# Model for excl61 Q1
model.output.neo.excl61.q1 <- glmer(PA_NEOX_EXCL_TOP61 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl61 <- summary(model.output.neo.excl61.q1)

# Data prep Q2,Q3 for excl61
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 61)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 61), paste0("RELABUN_NEOX_EXCL_TOP", 61), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP61 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 61)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP61 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 61)]))

# Model for excl61 Q2
model.output.neo.excl61.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP61 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl61 <- summary(model.output.neo.excl61.q2)

# Model for excl61 Q3
model.output.neo.excl61.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP61 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl61 <- summary(model.output.neo.excl61.q3)

cat("Model number 61 processed\n")

# Model for excl62 Q1
model.output.neo.excl62.q1 <- glmer(PA_NEOX_EXCL_TOP62 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl62 <- summary(model.output.neo.excl62.q1)

# Data prep Q2,Q3 for excl62
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 62)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 62), paste0("RELABUN_NEOX_EXCL_TOP", 62), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP62 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 62)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP62 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 62)]))

# Model for excl62 Q2
model.output.neo.excl62.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP62 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl62 <- summary(model.output.neo.excl62.q2)

# Model for excl62 Q3
model.output.neo.excl62.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP62 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl62 <- summary(model.output.neo.excl62.q3)

cat("Model number 62 processed\n")

# Model for excl63 Q1
model.output.neo.excl63.q1 <- glmer(PA_NEOX_EXCL_TOP63 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl63 <- summary(model.output.neo.excl63.q1)

# Data prep Q2,Q3 for excl63
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 63)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 63), paste0("RELABUN_NEOX_EXCL_TOP", 63), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP63 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 63)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP63 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 63)]))

# Model for excl63 Q2
model.output.neo.excl63.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP63 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl63 <- summary(model.output.neo.excl63.q2)

# Model for excl63 Q3
model.output.neo.excl63.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP63 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl63 <- summary(model.output.neo.excl63.q3)

cat("Model number 63 processed\n")

# Model for excl64 Q1
model.output.neo.excl64.q1 <- glmer(PA_NEOX_EXCL_TOP64 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl64 <- summary(model.output.neo.excl64.q1)

# Data prep Q2,Q3 for excl64
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 64)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 64), paste0("RELABUN_NEOX_EXCL_TOP", 64), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP64 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 64)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP64 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 64)]))

# Model for excl64 Q2
model.output.neo.excl64.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP64 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl64 <- summary(model.output.neo.excl64.q2)

# Model for excl64 Q3
model.output.neo.excl64.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP64 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl64 <- summary(model.output.neo.excl64.q3)

cat("Model number 64 processed\n")

# Model for excl65 Q1
model.output.neo.excl65.q1 <- glmer(PA_NEOX_EXCL_TOP65 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl65 <- summary(model.output.neo.excl65.q1)

# Data prep Q2,Q3 for excl65
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 65)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 65), paste0("RELABUN_NEOX_EXCL_TOP", 65), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP65 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 65)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP65 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 65)]))

# Model for excl65 Q2
model.output.neo.excl65.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP65 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl65 <- summary(model.output.neo.excl65.q2)

# Model for excl65 Q3
model.output.neo.excl65.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP65 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl65 <- summary(model.output.neo.excl65.q3)

cat("Model number 65 processed\n")

# Model for excl66 Q1
model.output.neo.excl66.q1 <- glmer(PA_NEOX_EXCL_TOP66 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl66 <- summary(model.output.neo.excl66.q1)

# Data prep Q2,Q3 for excl66
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 66)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 66), paste0("RELABUN_NEOX_EXCL_TOP", 66), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP66 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 66)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP66 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 66)]))

# Model for excl66 Q2
model.output.neo.excl66.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP66 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl66 <- summary(model.output.neo.excl66.q2)

# Model for excl66 Q3
model.output.neo.excl66.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP66 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl66 <- summary(model.output.neo.excl66.q3)

cat("Model number 66 processed\n")

# Model for excl67 Q1
model.output.neo.excl67.q1 <- glmer(PA_NEOX_EXCL_TOP67 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl67 <- summary(model.output.neo.excl67.q1)

# Data prep Q2,Q3 for excl67
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 67)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 67), paste0("RELABUN_NEOX_EXCL_TOP", 67), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP67 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 67)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP67 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 67)]))

# Model for excl67 Q2
model.output.neo.excl67.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP67 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl67 <- summary(model.output.neo.excl67.q2)

# Model for excl67 Q3
model.output.neo.excl67.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP67 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl67 <- summary(model.output.neo.excl67.q3)

cat("Model number 67 processed\n")

# Model for excl68 Q1
model.output.neo.excl68.q1 <- glmer(PA_NEOX_EXCL_TOP68 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl68 <- summary(model.output.neo.excl68.q1)

# Data prep Q2,Q3 for excl68
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 68)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 68), paste0("RELABUN_NEOX_EXCL_TOP", 68), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP68 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 68)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP68 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 68)]))

# Model for excl68 Q2
model.output.neo.excl68.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP68 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl68 <- summary(model.output.neo.excl68.q2)

# Model for excl68 Q3
model.output.neo.excl68.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP68 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl68 <- summary(model.output.neo.excl68.q3)

cat("Model number 68 processed\n")

# Model for excl69 Q1
model.output.neo.excl69.q1 <- glmer(PA_NEOX_EXCL_TOP69 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl69 <- summary(model.output.neo.excl69.q1)

# Data prep Q2,Q3 for excl69
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 69)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 69), paste0("RELABUN_NEOX_EXCL_TOP", 69), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP69 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 69)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP69 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 69)]))

# Model for excl69 Q2
model.output.neo.excl69.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP69 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl69 <- summary(model.output.neo.excl69.q2)

# Model for excl69 Q3
model.output.neo.excl69.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP69 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl69 <- summary(model.output.neo.excl69.q3)

cat("Model number 69 processed\n")

# Model for excl70 Q1
model.output.neo.excl70.q1 <- glmer(PA_NEOX_EXCL_TOP70 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl70 <- summary(model.output.neo.excl70.q1)

# Data prep Q2,Q3 for excl70
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 70)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 70), paste0("RELABUN_NEOX_EXCL_TOP", 70), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP70 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 70)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP70 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 70)]))

# Model for excl70 Q2
model.output.neo.excl70.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP70 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl70 <- summary(model.output.neo.excl70.q2)

# Model for excl70 Q3
model.output.neo.excl70.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP70 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl70 <- summary(model.output.neo.excl70.q3)

cat("Model number 70 processed\n")

# Model for excl71 Q1
model.output.neo.excl71.q1 <- glmer(PA_NEOX_EXCL_TOP71 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl71 <- summary(model.output.neo.excl71.q1)

# Data prep Q2,Q3 for excl71
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 71)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 71), paste0("RELABUN_NEOX_EXCL_TOP", 71), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP71 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 71)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP71 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 71)]))

# Model for excl71 Q2
model.output.neo.excl71.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP71 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl71 <- summary(model.output.neo.excl71.q2)

# Model for excl71 Q3
model.output.neo.excl71.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP71 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl71 <- summary(model.output.neo.excl71.q3)

cat("Model number 71 processed\n")

# Model for excl72 Q1
model.output.neo.excl72.q1 <- glmer(PA_NEOX_EXCL_TOP72 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl72 <- summary(model.output.neo.excl72.q1)

# Data prep Q2,Q3 for excl72
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 72)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 72), paste0("RELABUN_NEOX_EXCL_TOP", 72), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP72 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 72)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP72 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 72)]))

# Model for excl72 Q2
model.output.neo.excl72.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP72 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl72 <- summary(model.output.neo.excl72.q2)

# Model for excl72 Q3
model.output.neo.excl72.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP72 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl72 <- summary(model.output.neo.excl72.q3)

cat("Model number 72 processed\n")

# Model for excl73 Q1
model.output.neo.excl73.q1 <- glmer(PA_NEOX_EXCL_TOP73 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl73 <- summary(model.output.neo.excl73.q1)

# Data prep Q2,Q3 for excl73
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 73)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 73), paste0("RELABUN_NEOX_EXCL_TOP", 73), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP73 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 73)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP73 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 73)]))

# Model for excl73 Q2
model.output.neo.excl73.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP73 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl73 <- summary(model.output.neo.excl73.q2)

# Model for excl73 Q3
model.output.neo.excl73.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP73 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl73 <- summary(model.output.neo.excl73.q3)

cat("Model number 73 processed\n")

# Model for excl74 Q1
model.output.neo.excl74.q1 <- glmer(PA_NEOX_EXCL_TOP74 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl74 <- summary(model.output.neo.excl74.q1)

# Data prep Q2,Q3 for excl74
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 74)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 74), paste0("RELABUN_NEOX_EXCL_TOP", 74), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP74 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 74)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP74 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 74)]))

# Model for excl74 Q2
model.output.neo.excl74.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP74 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl74 <- summary(model.output.neo.excl74.q2)

# Model for excl74 Q3
model.output.neo.excl74.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP74 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl74 <- summary(model.output.neo.excl74.q3)

cat("Model number 74 processed\n")

# Model for excl75 Q1
model.output.neo.excl75.q1 <- glmer(PA_NEOX_EXCL_TOP75 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl75 <- summary(model.output.neo.excl75.q1)

# Data prep Q2,Q3 for excl75
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 75)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 75), paste0("RELABUN_NEOX_EXCL_TOP", 75), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP75 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 75)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP75 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 75)]))

# Model for excl75 Q2
model.output.neo.excl75.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP75 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl75 <- summary(model.output.neo.excl75.q2)

# Model for excl75 Q3
model.output.neo.excl75.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP75 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl75 <- summary(model.output.neo.excl75.q3)

cat("Model number 75 processed\n")

# Model for excl76 Q1
model.output.neo.excl76.q1 <- glmer(PA_NEOX_EXCL_TOP76 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl76 <- summary(model.output.neo.excl76.q1)

# Data prep Q2,Q3 for excl76
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 76)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 76), paste0("RELABUN_NEOX_EXCL_TOP", 76), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP76 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 76)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP76 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 76)]))

# Model for excl76 Q2
model.output.neo.excl76.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP76 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl76 <- summary(model.output.neo.excl76.q2)

# Model for excl76 Q3
model.output.neo.excl76.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP76 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl76 <- summary(model.output.neo.excl76.q3)

cat("Model number 76 processed\n")

# Model for excl77 Q1
model.output.neo.excl77.q1 <- glmer(PA_NEOX_EXCL_TOP77 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl77 <- summary(model.output.neo.excl77.q1)

# Data prep Q2,Q3 for excl77
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 77)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 77), paste0("RELABUN_NEOX_EXCL_TOP", 77), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP77 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 77)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP77 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 77)]))

# Model for excl77 Q2
model.output.neo.excl77.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP77 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl77 <- summary(model.output.neo.excl77.q2)

# Model for excl77 Q3
model.output.neo.excl77.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP77 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl77 <- summary(model.output.neo.excl77.q3)

cat("Model number 77 processed\n")

# Model for excl78 Q1
model.output.neo.excl78.q1 <- glmer(PA_NEOX_EXCL_TOP78 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl78 <- summary(model.output.neo.excl78.q1)

# Data prep Q2,Q3 for excl78
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 78)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 78), paste0("RELABUN_NEOX_EXCL_TOP", 78), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP78 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 78)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP78 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 78)]))

# Model for excl78 Q2
model.output.neo.excl78.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP78 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl78 <- summary(model.output.neo.excl78.q2)

# Model for excl78 Q3
model.output.neo.excl78.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP78 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl78 <- summary(model.output.neo.excl78.q3)

cat("Model number 78 processed\n")

# Model for excl79 Q1
model.output.neo.excl79.q1 <- glmer(PA_NEOX_EXCL_TOP79 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl79 <- summary(model.output.neo.excl79.q1)

# Data prep Q2,Q3 for excl79
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 79)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 79), paste0("RELABUN_NEOX_EXCL_TOP", 79), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP79 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 79)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP79 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 79)]))

# Model for excl79 Q2
model.output.neo.excl79.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP79 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl79 <- summary(model.output.neo.excl79.q2)

# Model for excl79 Q3
model.output.neo.excl79.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP79 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl79 <- summary(model.output.neo.excl79.q3)

cat("Model number 79 processed\n")

# Model for excl80 Q1
model.output.neo.excl80.q1 <- glmer(PA_NEOX_EXCL_TOP80 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl80 <- summary(model.output.neo.excl80.q1)

# Data prep Q2,Q3 for excl80
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 80)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 80), paste0("RELABUN_NEOX_EXCL_TOP", 80), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP80 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 80)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP80 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 80)]))

# Model for excl80 Q2
model.output.neo.excl80.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP80 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl80 <- summary(model.output.neo.excl80.q2)

# Model for excl80 Q3
model.output.neo.excl80.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP80 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl80 <- summary(model.output.neo.excl80.q3)

cat("Model number 80 processed\n")

# Model for excl81 Q1
model.output.neo.excl81.q1 <- glmer(PA_NEOX_EXCL_TOP81 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl81 <- summary(model.output.neo.excl81.q1)

# Data prep Q2,Q3 for excl81
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 81)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 81), paste0("RELABUN_NEOX_EXCL_TOP", 81), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP81 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 81)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP81 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 81)]))

# Model for excl81 Q2
model.output.neo.excl81.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP81 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl81 <- summary(model.output.neo.excl81.q2)

# Model for excl81 Q3
model.output.neo.excl81.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP81 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl81 <- summary(model.output.neo.excl81.q3)

cat("Model number 81 processed\n")

# Model for excl82 Q1
model.output.neo.excl82.q1 <- glmer(PA_NEOX_EXCL_TOP82 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl82 <- summary(model.output.neo.excl82.q1)

# Data prep Q2,Q3 for excl82
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 82)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 82), paste0("RELABUN_NEOX_EXCL_TOP", 82), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP82 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 82)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP82 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 82)]))

# Model for excl82 Q2
model.output.neo.excl82.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP82 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl82 <- summary(model.output.neo.excl82.q2)

# Model for excl82 Q3
model.output.neo.excl82.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP82 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl82 <- summary(model.output.neo.excl82.q3)

cat("Model number 82 processed\n")

# Model for excl83 Q1
model.output.neo.excl83.q1 <- glmer(PA_NEOX_EXCL_TOP83 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl83 <- summary(model.output.neo.excl83.q1)

# Data prep Q2,Q3 for excl83
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 83)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 83), paste0("RELABUN_NEOX_EXCL_TOP", 83), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP83 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 83)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP83 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 83)]))

# Model for excl83 Q2
model.output.neo.excl83.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP83 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl83 <- summary(model.output.neo.excl83.q2)

# Model for excl83 Q3
model.output.neo.excl83.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP83 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl83 <- summary(model.output.neo.excl83.q3)

cat("Model number 83 processed\n")

# Model for excl84 Q1
model.output.neo.excl84.q1 <- glmer(PA_NEOX_EXCL_TOP84 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl84 <- summary(model.output.neo.excl84.q1)

# Data prep Q2,Q3 for excl84
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 84)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 84), paste0("RELABUN_NEOX_EXCL_TOP", 84), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP84 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 84)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP84 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 84)]))

# Model for excl84 Q2
model.output.neo.excl84.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP84 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl84 <- summary(model.output.neo.excl84.q2)

# Model for excl84 Q3
model.output.neo.excl84.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP84 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl84 <- summary(model.output.neo.excl84.q3)

cat("Model number 84 processed\n")

# Model for excl85 Q1
model.output.neo.excl85.q1 <- glmer(PA_NEOX_EXCL_TOP85 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl85 <- summary(model.output.neo.excl85.q1)

# Data prep Q2,Q3 for excl85
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 85)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 85), paste0("RELABUN_NEOX_EXCL_TOP", 85), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP85 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 85)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP85 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 85)]))

# Model for excl85 Q2
model.output.neo.excl85.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP85 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl85 <- summary(model.output.neo.excl85.q2)

# Model for excl85 Q3
model.output.neo.excl85.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP85 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl85 <- summary(model.output.neo.excl85.q3)

cat("Model number 85 processed\n")

# Model for excl86 Q1
model.output.neo.excl86.q1 <- glmer(PA_NEOX_EXCL_TOP86 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl86 <- summary(model.output.neo.excl86.q1)

# Data prep Q2,Q3 for excl86
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 86)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 86), paste0("RELABUN_NEOX_EXCL_TOP", 86), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP86 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 86)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP86 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 86)]))

# Model for excl86 Q2
model.output.neo.excl86.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP86 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl86 <- summary(model.output.neo.excl86.q2)

# Model for excl86 Q3
model.output.neo.excl86.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP86 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl86 <- summary(model.output.neo.excl86.q3)

cat("Model number 86 processed\n")

# Model for excl87 Q1
model.output.neo.excl87.q1 <- glmer(PA_NEOX_EXCL_TOP87 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl87 <- summary(model.output.neo.excl87.q1)

# Data prep Q2,Q3 for excl87
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 87)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 87), paste0("RELABUN_NEOX_EXCL_TOP", 87), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP87 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 87)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP87 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 87)]))

# Model for excl87 Q2
model.output.neo.excl87.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP87 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl87 <- summary(model.output.neo.excl87.q2)

# Model for excl87 Q3
model.output.neo.excl87.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP87 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl87 <- summary(model.output.neo.excl87.q3)

cat("Model number 87 processed\n")

# Model for excl88 Q1
model.output.neo.excl88.q1 <- glmer(PA_NEOX_EXCL_TOP88 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl88 <- summary(model.output.neo.excl88.q1)

# Data prep Q2,Q3 for excl88
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 88)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 88), paste0("RELABUN_NEOX_EXCL_TOP", 88), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP88 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 88)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP88 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 88)]))

# Model for excl88 Q2
model.output.neo.excl88.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP88 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl88 <- summary(model.output.neo.excl88.q2)

# Model for excl88 Q3
model.output.neo.excl88.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP88 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl88 <- summary(model.output.neo.excl88.q3)

cat("Model number 88 processed\n")

# Model for excl89 Q1
model.output.neo.excl89.q1 <- glmer(PA_NEOX_EXCL_TOP89 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl89 <- summary(model.output.neo.excl89.q1)

# Data prep Q2,Q3 for excl89
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 89)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 89), paste0("RELABUN_NEOX_EXCL_TOP", 89), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP89 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 89)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP89 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 89)]))

# Model for excl89 Q2
model.output.neo.excl89.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP89 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl89 <- summary(model.output.neo.excl89.q2)

# Model for excl89 Q3
model.output.neo.excl89.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP89 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl89 <- summary(model.output.neo.excl89.q3)

cat("Model number 89 processed\n")

# Model for excl90 Q1
model.output.neo.excl90.q1 <- glmer(PA_NEOX_EXCL_TOP90 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl90 <- summary(model.output.neo.excl90.q1)

# Data prep Q2,Q3 for excl90
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 90)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 90), paste0("RELABUN_NEOX_EXCL_TOP", 90), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP90 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 90)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP90 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 90)]))

# Model for excl90 Q2
model.output.neo.excl90.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP90 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl90 <- summary(model.output.neo.excl90.q2)

# Model for excl90 Q3
model.output.neo.excl90.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP90 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl90 <- summary(model.output.neo.excl90.q3)

cat("Model number 90 processed\n")

# Model for excl91 Q1
model.output.neo.excl91.q1 <- glmer(PA_NEOX_EXCL_TOP91 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl91 <- summary(model.output.neo.excl91.q1)

# Data prep Q2,Q3 for excl91
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 91)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 91), paste0("RELABUN_NEOX_EXCL_TOP", 91), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP91 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 91)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP91 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 91)]))

# Model for excl91 Q2
model.output.neo.excl91.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP91 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl91 <- summary(model.output.neo.excl91.q2)

# Model for excl91 Q3
model.output.neo.excl91.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP91 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl91 <- summary(model.output.neo.excl91.q3)

cat("Model number 91 processed\n")

# Model for excl92 Q1
model.output.neo.excl92.q1 <- glmer(PA_NEOX_EXCL_TOP92 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl92 <- summary(model.output.neo.excl92.q1)

# Data prep Q2,Q3 for excl92
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 92)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 92), paste0("RELABUN_NEOX_EXCL_TOP", 92), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP92 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 92)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP92 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 92)]))

# Model for excl92 Q2
model.output.neo.excl92.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP92 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl92 <- summary(model.output.neo.excl92.q2)

# Model for excl92 Q3
model.output.neo.excl92.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP92 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl92 <- summary(model.output.neo.excl92.q3)

cat("Model number 92 processed\n")

# Model for excl93 Q1
model.output.neo.excl93.q1 <- glmer(PA_NEOX_EXCL_TOP93 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl93 <- summary(model.output.neo.excl93.q1)

# Data prep Q2,Q3 for excl93
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 93)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 93), paste0("RELABUN_NEOX_EXCL_TOP", 93), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP93 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 93)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP93 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 93)]))

# Model for excl93 Q2
model.output.neo.excl93.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP93 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl93 <- summary(model.output.neo.excl93.q2)

# Model for excl93 Q3
model.output.neo.excl93.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP93 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl93 <- summary(model.output.neo.excl93.q3)

cat("Model number 93 processed\n")

# Model for excl94 Q1
model.output.neo.excl94.q1 <- glmer(PA_NEOX_EXCL_TOP94 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl94 <- summary(model.output.neo.excl94.q1)

# Data prep Q2,Q3 for excl94
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 94)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 94), paste0("RELABUN_NEOX_EXCL_TOP", 94), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP94 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 94)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP94 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 94)]))

# Model for excl94 Q2
model.output.neo.excl94.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP94 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl94 <- summary(model.output.neo.excl94.q2)

# Model for excl94 Q3
model.output.neo.excl94.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP94 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl94 <- summary(model.output.neo.excl94.q3)

cat("Model number 94 processed\n")

# Model for excl95 Q1
model.output.neo.excl95.q1 <- glmer(PA_NEOX_EXCL_TOP95 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl95 <- summary(model.output.neo.excl95.q1)

# Data prep Q2,Q3 for excl95
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 95)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 95), paste0("RELABUN_NEOX_EXCL_TOP", 95), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP95 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 95)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP95 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 95)]))

# Model for excl95 Q2
model.output.neo.excl95.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP95 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl95 <- summary(model.output.neo.excl95.q2)

# Model for excl95 Q3
model.output.neo.excl95.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP95 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl95 <- summary(model.output.neo.excl95.q3)

cat("Model number 95 processed\n")

# Model for excl96 Q1
model.output.neo.excl96.q1 <- glmer(PA_NEOX_EXCL_TOP96 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl96 <- summary(model.output.neo.excl96.q1)

# Data prep Q2,Q3 for excl96
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 96)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 96), paste0("RELABUN_NEOX_EXCL_TOP", 96), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP96 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 96)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP96 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 96)]))

# Model for excl96 Q2
model.output.neo.excl96.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP96 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl96 <- summary(model.output.neo.excl96.q2)

# Model for excl96 Q3
model.output.neo.excl96.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP96 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl96 <- summary(model.output.neo.excl96.q3)

cat("Model number 96 processed\n")

# Model for excl97 Q1
model.output.neo.excl97.q1 <- glmer(PA_NEOX_EXCL_TOP97 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl97 <- summary(model.output.neo.excl97.q1)

# Data prep Q2,Q3 for excl97
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 97)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 97), paste0("RELABUN_NEOX_EXCL_TOP", 97), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP97 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 97)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP97 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 97)]))

# Model for excl97 Q2
model.output.neo.excl97.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP97 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl97 <- summary(model.output.neo.excl97.q2)

# Model for excl97 Q3
model.output.neo.excl97.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP97 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl97 <- summary(model.output.neo.excl97.q3)

cat("Model number 97 processed\n")

# Model for excl98 Q1
model.output.neo.excl98.q1 <- glmer(PA_NEOX_EXCL_TOP98 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl98 <- summary(model.output.neo.excl98.q1)

# Data prep Q2,Q3 for excl98
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 98)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 98), paste0("RELABUN_NEOX_EXCL_TOP", 98), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP98 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 98)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP98 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 98)]))

# Model for excl98 Q2
model.output.neo.excl98.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP98 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl98 <- summary(model.output.neo.excl98.q2)

# Model for excl98 Q3
model.output.neo.excl98.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP98 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl98 <- summary(model.output.neo.excl98.q3)

cat("Model number 98 processed\n")

# Model for excl99 Q1
model.output.neo.excl99.q1 <- glmer(PA_NEOX_EXCL_TOP99 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl99 <- summary(model.output.neo.excl99.q1)

# Data prep Q2,Q3 for excl99
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 99)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 99), paste0("RELABUN_NEOX_EXCL_TOP", 99), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP99 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 99)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP99 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 99)]))

# Model for excl99 Q2
model.output.neo.excl99.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP99 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl99 <- summary(model.output.neo.excl99.q2)

# Model for excl99 Q3
model.output.neo.excl99.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP99 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl99 <- summary(model.output.neo.excl99.q3)

cat("Model number 99 processed\n")

# Model for excl100 Q1
model.output.neo.excl100.q1 <- glmer(PA_NEOX_EXCL_TOP100 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl100 <- summary(model.output.neo.excl100.q1)

# Data prep Q2,Q3 for excl100
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 100)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 100), paste0("RELABUN_NEOX_EXCL_TOP", 100), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP100 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 100)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP100 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 100)]))

# Model for excl100 Q2
model.output.neo.excl100.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP100 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl100 <- summary(model.output.neo.excl100.q2)

# Model for excl100 Q3
model.output.neo.excl100.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP100 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl100 <- summary(model.output.neo.excl100.q3)

cat("Model number 100 processed\n")

# Model for excl101 Q1
model.output.neo.excl101.q1 <- glmer(PA_NEOX_EXCL_TOP101 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl101 <- summary(model.output.neo.excl101.q1)

# Data prep Q2,Q3 for excl101
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 101)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 101), paste0("RELABUN_NEOX_EXCL_TOP", 101), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP101 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 101)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP101 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 101)]))

# Model for excl101 Q2
model.output.neo.excl101.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP101 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl101 <- summary(model.output.neo.excl101.q2)

# Model for excl101 Q3
model.output.neo.excl101.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP101 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl101 <- summary(model.output.neo.excl101.q3)

cat("Model number 101 processed\n")

# Model for excl102 Q1
model.output.neo.excl102.q1 <- glmer(PA_NEOX_EXCL_TOP102 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl102 <- summary(model.output.neo.excl102.q1)

# Data prep Q2,Q3 for excl102
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 102)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 102), paste0("RELABUN_NEOX_EXCL_TOP", 102), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP102 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 102)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP102 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 102)]))

# Model for excl102 Q2
model.output.neo.excl102.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP102 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl102 <- summary(model.output.neo.excl102.q2)

# Model for excl102 Q3
model.output.neo.excl102.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP102 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl102 <- summary(model.output.neo.excl102.q3)

cat("Model number 102 processed\n")

# Model for excl103 Q1
model.output.neo.excl103.q1 <- glmer(PA_NEOX_EXCL_TOP103 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl103 <- summary(model.output.neo.excl103.q1)

# Data prep Q2,Q3 for excl103
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 103)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 103), paste0("RELABUN_NEOX_EXCL_TOP", 103), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP103 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 103)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP103 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 103)]))

# Model for excl103 Q2
model.output.neo.excl103.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP103 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl103 <- summary(model.output.neo.excl103.q2)

# Model for excl103 Q3
model.output.neo.excl103.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP103 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl103 <- summary(model.output.neo.excl103.q3)

cat("Model number 103 processed\n")

# Model for excl104 Q1
model.output.neo.excl104.q1 <- glmer(PA_NEOX_EXCL_TOP104 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl104 <- summary(model.output.neo.excl104.q1)

# Data prep Q2,Q3 for excl104
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 104)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 104), paste0("RELABUN_NEOX_EXCL_TOP", 104), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP104 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 104)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP104 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 104)]))

# Model for excl104 Q2
model.output.neo.excl104.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP104 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl104 <- summary(model.output.neo.excl104.q2)

# Model for excl104 Q3
model.output.neo.excl104.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP104 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl104 <- summary(model.output.neo.excl104.q3)

cat("Model number 104 processed\n")

# Model for excl105 Q1
model.output.neo.excl105.q1 <- glmer(PA_NEOX_EXCL_TOP105 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl105 <- summary(model.output.neo.excl105.q1)

# Data prep Q2,Q3 for excl105
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 105)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 105), paste0("RELABUN_NEOX_EXCL_TOP", 105), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP105 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 105)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP105 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 105)]))

# Model for excl105 Q2
model.output.neo.excl105.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP105 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl105 <- summary(model.output.neo.excl105.q2)

# Model for excl105 Q3
model.output.neo.excl105.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP105 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl105 <- summary(model.output.neo.excl105.q3)

cat("Model number 105 processed\n")

# Model for excl106 Q1
model.output.neo.excl106.q1 <- glmer(PA_NEOX_EXCL_TOP106 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl106 <- summary(model.output.neo.excl106.q1)

# Data prep Q2,Q3 for excl106
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 106)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 106), paste0("RELABUN_NEOX_EXCL_TOP", 106), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP106 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 106)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP106 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 106)]))

# Model for excl106 Q2
model.output.neo.excl106.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP106 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl106 <- summary(model.output.neo.excl106.q2)

# Model for excl106 Q3
model.output.neo.excl106.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP106 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl106 <- summary(model.output.neo.excl106.q3)

cat("Model number 106 processed\n")

# Model for excl107 Q1
model.output.neo.excl107.q1 <- glmer(PA_NEOX_EXCL_TOP107 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl107 <- summary(model.output.neo.excl107.q1)

# Data prep Q2,Q3 for excl107
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 107)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 107), paste0("RELABUN_NEOX_EXCL_TOP", 107), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP107 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 107)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP107 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 107)]))

# Model for excl107 Q2
model.output.neo.excl107.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP107 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl107 <- summary(model.output.neo.excl107.q2)

# Model for excl107 Q3
model.output.neo.excl107.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP107 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl107 <- summary(model.output.neo.excl107.q3)

cat("Model number 107 processed\n")

# Model for excl108 Q1
model.output.neo.excl108.q1 <- glmer(PA_NEOX_EXCL_TOP108 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl108 <- summary(model.output.neo.excl108.q1)

# Data prep Q2,Q3 for excl108
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 108)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 108), paste0("RELABUN_NEOX_EXCL_TOP", 108), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP108 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 108)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP108 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 108)]))

# Model for excl108 Q2
model.output.neo.excl108.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP108 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl108 <- summary(model.output.neo.excl108.q2)

# Model for excl108 Q3
model.output.neo.excl108.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP108 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl108 <- summary(model.output.neo.excl108.q3)

cat("Model number 108 processed\n")

# Model for excl109 Q1
model.output.neo.excl109.q1 <- glmer(PA_NEOX_EXCL_TOP109 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl109 <- summary(model.output.neo.excl109.q1)

# Data prep Q2,Q3 for excl109
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 109)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 109), paste0("RELABUN_NEOX_EXCL_TOP", 109), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP109 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 109)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP109 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 109)]))

# Model for excl109 Q2
model.output.neo.excl109.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP109 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl109 <- summary(model.output.neo.excl109.q2)

# Model for excl109 Q3
model.output.neo.excl109.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP109 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl109 <- summary(model.output.neo.excl109.q3)

cat("Model number 109 processed\n")

# Model for excl110 Q1
model.output.neo.excl110.q1 <- glmer(PA_NEOX_EXCL_TOP110 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl110 <- summary(model.output.neo.excl110.q1)

# Data prep Q2,Q3 for excl110
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 110)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 110), paste0("RELABUN_NEOX_EXCL_TOP", 110), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP110 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 110)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP110 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 110)]))

# Model for excl110 Q2
model.output.neo.excl110.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP110 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl110 <- summary(model.output.neo.excl110.q2)

# Model for excl110 Q3
model.output.neo.excl110.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP110 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl110 <- summary(model.output.neo.excl110.q3)

cat("Model number 110 processed\n")

# Model for excl111 Q1
model.output.neo.excl111.q1 <- glmer(PA_NEOX_EXCL_TOP111 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl111 <- summary(model.output.neo.excl111.q1)

# Data prep Q2,Q3 for excl111
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 111)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 111), paste0("RELABUN_NEOX_EXCL_TOP", 111), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP111 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 111)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP111 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 111)]))

# Model for excl111 Q2
model.output.neo.excl111.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP111 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl111 <- summary(model.output.neo.excl111.q2)

# Model for excl111 Q3
model.output.neo.excl111.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP111 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl111 <- summary(model.output.neo.excl111.q3)

cat("Model number 111 processed\n")

# Model for excl112 Q1
model.output.neo.excl112.q1 <- glmer(PA_NEOX_EXCL_TOP112 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl112 <- summary(model.output.neo.excl112.q1)

# Data prep Q2,Q3 for excl112
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 112)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 112), paste0("RELABUN_NEOX_EXCL_TOP", 112), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP112 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 112)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP112 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 112)]))

# Model for excl112 Q2
model.output.neo.excl112.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP112 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl112 <- summary(model.output.neo.excl112.q2)

# Model for excl112 Q3
model.output.neo.excl112.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP112 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl112 <- summary(model.output.neo.excl112.q3)

cat("Model number 112 processed\n")

# Model for excl113 Q1
model.output.neo.excl113.q1 <- glmer(PA_NEOX_EXCL_TOP113 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl113 <- summary(model.output.neo.excl113.q1)

# Data prep Q2,Q3 for excl113
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 113)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 113), paste0("RELABUN_NEOX_EXCL_TOP", 113), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP113 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 113)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP113 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 113)]))

# Model for excl113 Q2
model.output.neo.excl113.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP113 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl113 <- summary(model.output.neo.excl113.q2)

# Model for excl113 Q3
model.output.neo.excl113.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP113 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl113 <- summary(model.output.neo.excl113.q3)

cat("Model number 113 processed\n")

# Model for excl114 Q1
model.output.neo.excl114.q1 <- glmer(PA_NEOX_EXCL_TOP114 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl114 <- summary(model.output.neo.excl114.q1)

# Data prep Q2,Q3 for excl114
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 114)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 114), paste0("RELABUN_NEOX_EXCL_TOP", 114), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP114 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 114)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP114 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 114)]))

# Model for excl114 Q2
model.output.neo.excl114.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP114 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl114 <- summary(model.output.neo.excl114.q2)

# Model for excl114 Q3
model.output.neo.excl114.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP114 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl114 <- summary(model.output.neo.excl114.q3)

cat("Model number 114 processed\n")

# Model for excl115 Q1
model.output.neo.excl115.q1 <- glmer(PA_NEOX_EXCL_TOP115 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl115 <- summary(model.output.neo.excl115.q1)

# Data prep Q2,Q3 for excl115
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 115)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 115), paste0("RELABUN_NEOX_EXCL_TOP", 115), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP115 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 115)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP115 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 115)]))

# Model for excl115 Q2
model.output.neo.excl115.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP115 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl115 <- summary(model.output.neo.excl115.q2)

# Model for excl115 Q3
model.output.neo.excl115.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP115 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl115 <- summary(model.output.neo.excl115.q3)

cat("Model number 115 processed\n")

# Model for excl116 Q1
model.output.neo.excl116.q1 <- glmer(PA_NEOX_EXCL_TOP116 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl116 <- summary(model.output.neo.excl116.q1)

# Data prep Q2,Q3 for excl116
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 116)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 116), paste0("RELABUN_NEOX_EXCL_TOP", 116), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP116 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 116)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP116 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 116)]))

# Model for excl116 Q2
model.output.neo.excl116.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP116 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl116 <- summary(model.output.neo.excl116.q2)

# Model for excl116 Q3
model.output.neo.excl116.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP116 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl116 <- summary(model.output.neo.excl116.q3)

cat("Model number 116 processed\n")

# Model for excl117 Q1
model.output.neo.excl117.q1 <- glmer(PA_NEOX_EXCL_TOP117 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl117 <- summary(model.output.neo.excl117.q1)

# Data prep Q2,Q3 for excl117
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 117)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 117), paste0("RELABUN_NEOX_EXCL_TOP", 117), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP117 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 117)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP117 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 117)]))

# Model for excl117 Q2
model.output.neo.excl117.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP117 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl117 <- summary(model.output.neo.excl117.q2)

# Model for excl117 Q3
model.output.neo.excl117.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP117 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl117 <- summary(model.output.neo.excl117.q3)

cat("Model number 117 processed\n")

# Model for excl118 Q1
model.output.neo.excl118.q1 <- glmer(PA_NEOX_EXCL_TOP118 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl118 <- summary(model.output.neo.excl118.q1)

# Data prep Q2,Q3 for excl118
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 118)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 118), paste0("RELABUN_NEOX_EXCL_TOP", 118), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP118 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 118)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP118 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 118)]))

# Model for excl118 Q2
model.output.neo.excl118.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP118 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl118 <- summary(model.output.neo.excl118.q2)

# Model for excl118 Q3
model.output.neo.excl118.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP118 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl118 <- summary(model.output.neo.excl118.q3)

cat("Model number 118 processed\n")

# Model for excl119 Q1
model.output.neo.excl119.q1 <- glmer(PA_NEOX_EXCL_TOP119 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl119 <- summary(model.output.neo.excl119.q1)

# Data prep Q2,Q3 for excl119
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 119)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 119), paste0("RELABUN_NEOX_EXCL_TOP", 119), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP119 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 119)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP119 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 119)]))

# Model for excl119 Q2
model.output.neo.excl119.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP119 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl119 <- summary(model.output.neo.excl119.q2)

# Model for excl119 Q3
model.output.neo.excl119.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP119 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl119 <- summary(model.output.neo.excl119.q3)

cat("Model number 119 processed\n")

# Model for excl120 Q1
model.output.neo.excl120.q1 <- glmer(PA_NEOX_EXCL_TOP120 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl120 <- summary(model.output.neo.excl120.q1)

# Data prep Q2,Q3 for excl120
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 120)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 120), paste0("RELABUN_NEOX_EXCL_TOP", 120), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP120 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 120)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP120 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 120)]))

# Model for excl120 Q2
model.output.neo.excl120.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP120 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl120 <- summary(model.output.neo.excl120.q2)

# Model for excl120 Q3
model.output.neo.excl120.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP120 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl120 <- summary(model.output.neo.excl120.q3)

cat("Model number 120 processed\n")

# Model for excl121 Q1
model.output.neo.excl121.q1 <- glmer(PA_NEOX_EXCL_TOP121 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl121 <- summary(model.output.neo.excl121.q1)

# Data prep Q2,Q3 for excl121
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 121)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 121), paste0("RELABUN_NEOX_EXCL_TOP", 121), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP121 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 121)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP121 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 121)]))

# Model for excl121 Q2
model.output.neo.excl121.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP121 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl121 <- summary(model.output.neo.excl121.q2)

# Model for excl121 Q3
model.output.neo.excl121.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP121 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl121 <- summary(model.output.neo.excl121.q3)

cat("Model number 121 processed\n")

# Model for excl122 Q1
model.output.neo.excl122.q1 <- glmer(PA_NEOX_EXCL_TOP122 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl122 <- summary(model.output.neo.excl122.q1)

# Data prep Q2,Q3 for excl122
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 122)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 122), paste0("RELABUN_NEOX_EXCL_TOP", 122), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP122 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 122)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP122 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 122)]))

# Model for excl122 Q2
model.output.neo.excl122.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP122 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl122 <- summary(model.output.neo.excl122.q2)

# Model for excl122 Q3
model.output.neo.excl122.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP122 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl122 <- summary(model.output.neo.excl122.q3)

cat("Model number 122 processed\n")

# Model for excl123 Q1
model.output.neo.excl123.q1 <- glmer(PA_NEOX_EXCL_TOP123 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl123 <- summary(model.output.neo.excl123.q1)

# Data prep Q2,Q3 for excl123
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 123)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 123), paste0("RELABUN_NEOX_EXCL_TOP", 123), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP123 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 123)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP123 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 123)]))

# Model for excl123 Q2
model.output.neo.excl123.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP123 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl123 <- summary(model.output.neo.excl123.q2)

# Model for excl123 Q3
model.output.neo.excl123.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP123 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl123 <- summary(model.output.neo.excl123.q3)

cat("Model number 123 processed\n")

# Model for excl124 Q1
model.output.neo.excl124.q1 <- glmer(PA_NEOX_EXCL_TOP124 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl124 <- summary(model.output.neo.excl124.q1)

# Data prep Q2,Q3 for excl124
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 124)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 124), paste0("RELABUN_NEOX_EXCL_TOP", 124), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP124 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 124)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP124 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 124)]))

# Model for excl124 Q2
model.output.neo.excl124.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP124 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl124 <- summary(model.output.neo.excl124.q2)

# Model for excl124 Q3
model.output.neo.excl124.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP124 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl124 <- summary(model.output.neo.excl124.q3)

cat("Model number 124 processed\n")

# Model for excl125 Q1
model.output.neo.excl125.q1 <- glmer(PA_NEOX_EXCL_TOP125 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl125 <- summary(model.output.neo.excl125.q1)

# Data prep Q2,Q3 for excl125
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 125)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 125), paste0("RELABUN_NEOX_EXCL_TOP", 125), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP125 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 125)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP125 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 125)]))

# Model for excl125 Q2
model.output.neo.excl125.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP125 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl125 <- summary(model.output.neo.excl125.q2)

# Model for excl125 Q3
model.output.neo.excl125.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP125 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl125 <- summary(model.output.neo.excl125.q3)

cat("Model number 125 processed\n")

# Model for excl126 Q1
model.output.neo.excl126.q1 <- glmer(PA_NEOX_EXCL_TOP126 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl126 <- summary(model.output.neo.excl126.q1)

# Data prep Q2,Q3 for excl126
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 126)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 126), paste0("RELABUN_NEOX_EXCL_TOP", 126), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP126 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 126)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP126 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 126)]))

# Model for excl126 Q2
model.output.neo.excl126.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP126 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl126 <- summary(model.output.neo.excl126.q2)

# Model for excl126 Q3
model.output.neo.excl126.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP126 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl126 <- summary(model.output.neo.excl126.q3)

cat("Model number 126 processed\n")

# Model for excl127 Q1
model.output.neo.excl127.q1 <- glmer(PA_NEOX_EXCL_TOP127 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl127 <- summary(model.output.neo.excl127.q1)

# Data prep Q2,Q3 for excl127
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 127)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 127), paste0("RELABUN_NEOX_EXCL_TOP", 127), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP127 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 127)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP127 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 127)]))

# Model for excl127 Q2
model.output.neo.excl127.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP127 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl127 <- summary(model.output.neo.excl127.q2)

# Model for excl127 Q3
model.output.neo.excl127.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP127 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl127 <- summary(model.output.neo.excl127.q3)

cat("Model number 127 processed\n")

# Model for excl128 Q1
model.output.neo.excl128.q1 <- glmer(PA_NEOX_EXCL_TOP128 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl128 <- summary(model.output.neo.excl128.q1)

# Data prep Q2,Q3 for excl128
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 128)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 128), paste0("RELABUN_NEOX_EXCL_TOP", 128), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP128 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 128)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP128 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 128)]))

# Model for excl128 Q2
model.output.neo.excl128.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP128 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl128 <- summary(model.output.neo.excl128.q2)

# Model for excl128 Q3
model.output.neo.excl128.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP128 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl128 <- summary(model.output.neo.excl128.q3)

cat("Model number 128 processed\n")

# Model for excl129 Q1
model.output.neo.excl129.q1 <- glmer(PA_NEOX_EXCL_TOP129 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl129 <- summary(model.output.neo.excl129.q1)

# Data prep Q2,Q3 for excl129
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 129)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 129), paste0("RELABUN_NEOX_EXCL_TOP", 129), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP129 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 129)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP129 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 129)]))

# Model for excl129 Q2
model.output.neo.excl129.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP129 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl129 <- summary(model.output.neo.excl129.q2)

# Model for excl129 Q3
model.output.neo.excl129.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP129 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl129 <- summary(model.output.neo.excl129.q3)

cat("Model number 129 processed\n")

# Model for excl130 Q1
model.output.neo.excl130.q1 <- glmer(PA_NEOX_EXCL_TOP130 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl130 <- summary(model.output.neo.excl130.q1)

# Data prep Q2,Q3 for excl130
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 130)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 130), paste0("RELABUN_NEOX_EXCL_TOP", 130), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP130 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 130)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP130 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 130)]))

# Model for excl130 Q2
model.output.neo.excl130.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP130 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl130 <- summary(model.output.neo.excl130.q2)

# Model for excl130 Q3
model.output.neo.excl130.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP130 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl130 <- summary(model.output.neo.excl130.q3)

cat("Model number 130 processed\n")

# Model for excl131 Q1
model.output.neo.excl131.q1 <- glmer(PA_NEOX_EXCL_TOP131 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl131 <- summary(model.output.neo.excl131.q1)

# Data prep Q2,Q3 for excl131
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 131)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 131), paste0("RELABUN_NEOX_EXCL_TOP", 131), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP131 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 131)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP131 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 131)]))

# Model for excl131 Q2
model.output.neo.excl131.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP131 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl131 <- summary(model.output.neo.excl131.q2)

# Model for excl131 Q3
model.output.neo.excl131.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP131 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl131 <- summary(model.output.neo.excl131.q3)

cat("Model number 131 processed\n")

# Model for excl132 Q1
model.output.neo.excl132.q1 <- glmer(PA_NEOX_EXCL_TOP132 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl132 <- summary(model.output.neo.excl132.q1)

# Data prep Q2,Q3 for excl132
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 132)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 132), paste0("RELABUN_NEOX_EXCL_TOP", 132), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP132 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 132)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP132 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 132)]))

# Model for excl132 Q2
model.output.neo.excl132.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP132 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl132 <- summary(model.output.neo.excl132.q2)

# Model for excl132 Q3
model.output.neo.excl132.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP132 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl132 <- summary(model.output.neo.excl132.q3)

cat("Model number 132 processed\n")

# Model for excl133 Q1
model.output.neo.excl133.q1 <- glmer(PA_NEOX_EXCL_TOP133 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl133 <- summary(model.output.neo.excl133.q1)

# Data prep Q2,Q3 for excl133
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 133)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 133), paste0("RELABUN_NEOX_EXCL_TOP", 133), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP133 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 133)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP133 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 133)]))

# Model for excl133 Q2
model.output.neo.excl133.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP133 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl133 <- summary(model.output.neo.excl133.q2)

# Model for excl133 Q3
model.output.neo.excl133.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP133 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl133 <- summary(model.output.neo.excl133.q3)

cat("Model number 133 processed\n")

# Model for excl134 Q1
model.output.neo.excl134.q1 <- glmer(PA_NEOX_EXCL_TOP134 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl134 <- summary(model.output.neo.excl134.q1)

# Data prep Q2,Q3 for excl134
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 134)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 134), paste0("RELABUN_NEOX_EXCL_TOP", 134), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP134 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 134)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP134 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 134)]))

# Model for excl134 Q2
model.output.neo.excl134.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP134 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl134 <- summary(model.output.neo.excl134.q2)

# Model for excl134 Q3
model.output.neo.excl134.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP134 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl134 <- summary(model.output.neo.excl134.q3)

cat("Model number 134 processed\n")

# Model for excl135 Q1
model.output.neo.excl135.q1 <- glmer(PA_NEOX_EXCL_TOP135 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl135 <- summary(model.output.neo.excl135.q1)

# Data prep Q2,Q3 for excl135
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 135)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 135), paste0("RELABUN_NEOX_EXCL_TOP", 135), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP135 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 135)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP135 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 135)]))

# Model for excl135 Q2
model.output.neo.excl135.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP135 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl135 <- summary(model.output.neo.excl135.q2)

# Model for excl135 Q3
model.output.neo.excl135.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP135 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl135 <- summary(model.output.neo.excl135.q3)

cat("Model number 135 processed\n")

# Model for excl136 Q1
model.output.neo.excl136.q1 <- glmer(PA_NEOX_EXCL_TOP136 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl136 <- summary(model.output.neo.excl136.q1)

# Data prep Q2,Q3 for excl136
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 136)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 136), paste0("RELABUN_NEOX_EXCL_TOP", 136), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP136 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 136)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP136 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 136)]))

# Model for excl136 Q2
model.output.neo.excl136.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP136 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl136 <- summary(model.output.neo.excl136.q2)

# Model for excl136 Q3
model.output.neo.excl136.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP136 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl136 <- summary(model.output.neo.excl136.q3)

cat("Model number 136 processed\n")

# Model for excl137 Q1
model.output.neo.excl137.q1 <- glmer(PA_NEOX_EXCL_TOP137 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl137 <- summary(model.output.neo.excl137.q1)

# Data prep Q2,Q3 for excl137
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 137)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 137), paste0("RELABUN_NEOX_EXCL_TOP", 137), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP137 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 137)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP137 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 137)]))

# Model for excl137 Q2
model.output.neo.excl137.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP137 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl137 <- summary(model.output.neo.excl137.q2)

# Model for excl137 Q3
model.output.neo.excl137.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP137 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl137 <- summary(model.output.neo.excl137.q3)

cat("Model number 137 processed\n")

# Model for excl138 Q1
model.output.neo.excl138.q1 <- glmer(PA_NEOX_EXCL_TOP138 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl138 <- summary(model.output.neo.excl138.q1)

# Data prep Q2,Q3 for excl138
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 138)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 138), paste0("RELABUN_NEOX_EXCL_TOP", 138), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP138 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 138)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP138 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 138)]))

# Model for excl138 Q2
model.output.neo.excl138.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP138 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl138 <- summary(model.output.neo.excl138.q2)

# Model for excl138 Q3
model.output.neo.excl138.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP138 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl138 <- summary(model.output.neo.excl138.q3)

cat("Model number 138 processed\n")

# Model for excl139 Q1
model.output.neo.excl139.q1 <- glmer(PA_NEOX_EXCL_TOP139 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl139 <- summary(model.output.neo.excl139.q1)

# Data prep Q2,Q3 for excl139
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 139)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 139), paste0("RELABUN_NEOX_EXCL_TOP", 139), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP139 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 139)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP139 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 139)]))

# Model for excl139 Q2
model.output.neo.excl139.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP139 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl139 <- summary(model.output.neo.excl139.q2)

# Model for excl139 Q3
model.output.neo.excl139.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP139 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl139 <- summary(model.output.neo.excl139.q3)

cat("Model number 139 processed\n")

# Model for excl140 Q1
model.output.neo.excl140.q1 <- glmer(PA_NEOX_EXCL_TOP140 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl140 <- summary(model.output.neo.excl140.q1)

# Data prep Q2,Q3 for excl140
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 140)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 140), paste0("RELABUN_NEOX_EXCL_TOP", 140), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP140 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 140)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP140 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 140)]))

# Model for excl140 Q2
model.output.neo.excl140.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP140 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl140 <- summary(model.output.neo.excl140.q2)

# Model for excl140 Q3
model.output.neo.excl140.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP140 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl140 <- summary(model.output.neo.excl140.q3)

cat("Model number 140 processed\n")

# Model for excl141 Q1
model.output.neo.excl141.q1 <- glmer(PA_NEOX_EXCL_TOP141 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl141 <- summary(model.output.neo.excl141.q1)

# Data prep Q2,Q3 for excl141
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 141)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 141), paste0("RELABUN_NEOX_EXCL_TOP", 141), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP141 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 141)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP141 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 141)]))

# Model for excl141 Q2
model.output.neo.excl141.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP141 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl141 <- summary(model.output.neo.excl141.q2)

# Model for excl141 Q3
model.output.neo.excl141.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP141 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl141 <- summary(model.output.neo.excl141.q3)

cat("Model number 141 processed\n")

# Model for excl142 Q1
model.output.neo.excl142.q1 <- glmer(PA_NEOX_EXCL_TOP142 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl142 <- summary(model.output.neo.excl142.q1)

# Data prep Q2,Q3 for excl142
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 142)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 142), paste0("RELABUN_NEOX_EXCL_TOP", 142), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP142 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 142)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP142 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 142)]))

# Model for excl142 Q2
model.output.neo.excl142.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP142 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl142 <- summary(model.output.neo.excl142.q2)

# Model for excl142 Q3
model.output.neo.excl142.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP142 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl142 <- summary(model.output.neo.excl142.q3)

cat("Model number 142 processed\n")

# Model for excl143 Q1
model.output.neo.excl143.q1 <- glmer(PA_NEOX_EXCL_TOP143 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl143 <- summary(model.output.neo.excl143.q1)

# Data prep Q2,Q3 for excl143
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 143)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 143), paste0("RELABUN_NEOX_EXCL_TOP", 143), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP143 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 143)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP143 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 143)]))

# Model for excl143 Q2
model.output.neo.excl143.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP143 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl143 <- summary(model.output.neo.excl143.q2)

# Model for excl143 Q3
model.output.neo.excl143.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP143 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl143 <- summary(model.output.neo.excl143.q3)

cat("Model number 143 processed\n")

# Model for excl144 Q1
model.output.neo.excl144.q1 <- glmer(PA_NEOX_EXCL_TOP144 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl144 <- summary(model.output.neo.excl144.q1)

# Data prep Q2,Q3 for excl144
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 144)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 144), paste0("RELABUN_NEOX_EXCL_TOP", 144), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP144 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 144)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP144 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 144)]))

# Model for excl144 Q2
model.output.neo.excl144.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP144 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl144 <- summary(model.output.neo.excl144.q2)

# Model for excl144 Q3
model.output.neo.excl144.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP144 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl144 <- summary(model.output.neo.excl144.q3)

cat("Model number 144 processed\n")

# Model for excl145 Q1
model.output.neo.excl145.q1 <- glmer(PA_NEOX_EXCL_TOP145 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl145 <- summary(model.output.neo.excl145.q1)

# Data prep Q2,Q3 for excl145
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 145)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 145), paste0("RELABUN_NEOX_EXCL_TOP", 145), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP145 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 145)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP145 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 145)]))

# Model for excl145 Q2
model.output.neo.excl145.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP145 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl145 <- summary(model.output.neo.excl145.q2)

# Model for excl145 Q3
model.output.neo.excl145.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP145 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl145 <- summary(model.output.neo.excl145.q3)

cat("Model number 145 processed\n")

# Model for excl146 Q1
model.output.neo.excl146.q1 <- glmer(PA_NEOX_EXCL_TOP146 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl146 <- summary(model.output.neo.excl146.q1)

# Data prep Q2,Q3 for excl146
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 146)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 146), paste0("RELABUN_NEOX_EXCL_TOP", 146), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP146 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 146)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP146 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 146)]))

# Model for excl146 Q2
model.output.neo.excl146.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP146 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl146 <- summary(model.output.neo.excl146.q2)

# Model for excl146 Q3
model.output.neo.excl146.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP146 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl146 <- summary(model.output.neo.excl146.q3)

cat("Model number 146 processed\n")

# Model for excl147 Q1
model.output.neo.excl147.q1 <- glmer(PA_NEOX_EXCL_TOP147 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl147 <- summary(model.output.neo.excl147.q1)

# Data prep Q2,Q3 for excl147
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 147)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 147), paste0("RELABUN_NEOX_EXCL_TOP", 147), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP147 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 147)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP147 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 147)]))

# Model for excl147 Q2
model.output.neo.excl147.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP147 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl147 <- summary(model.output.neo.excl147.q2)

# Model for excl147 Q3
model.output.neo.excl147.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP147 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl147 <- summary(model.output.neo.excl147.q3)

cat("Model number 147 processed\n")

# Model for excl148 Q1
model.output.neo.excl148.q1 <- glmer(PA_NEOX_EXCL_TOP148 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl148 <- summary(model.output.neo.excl148.q1)

# Data prep Q2,Q3 for excl148
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 148)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 148), paste0("RELABUN_NEOX_EXCL_TOP", 148), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP148 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 148)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP148 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 148)]))

# Model for excl148 Q2
model.output.neo.excl148.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP148 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl148 <- summary(model.output.neo.excl148.q2)

# Model for excl148 Q3
model.output.neo.excl148.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP148 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl148 <- summary(model.output.neo.excl148.q3)

cat("Model number 148 processed\n")

# Model for excl149 Q1
model.output.neo.excl149.q1 <- glmer(PA_NEOX_EXCL_TOP149 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl149 <- summary(model.output.neo.excl149.q1)

# Data prep Q2,Q3 for excl149
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 149)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 149), paste0("RELABUN_NEOX_EXCL_TOP", 149), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP149 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 149)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP149 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 149)]))

# Model for excl149 Q2
model.output.neo.excl149.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP149 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl149 <- summary(model.output.neo.excl149.q2)

# Model for excl149 Q3
model.output.neo.excl149.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP149 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl149 <- summary(model.output.neo.excl149.q3)

cat("Model number 149 processed\n")

# Model for excl150 Q1
model.output.neo.excl150.q1 <- glmer(PA_NEOX_EXCL_TOP150 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl150 <- summary(model.output.neo.excl150.q1)

# Data prep Q2,Q3 for excl150
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 150)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 150), paste0("RELABUN_NEOX_EXCL_TOP", 150), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP150 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 150)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP150 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 150)]))

# Model for excl150 Q2
model.output.neo.excl150.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP150 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl150 <- summary(model.output.neo.excl150.q2)

# Model for excl150 Q3
model.output.neo.excl150.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP150 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl150 <- summary(model.output.neo.excl150.q3)

cat("Model number 150 processed\n")

# Model for excl151 Q1
model.output.neo.excl151.q1 <- glmer(PA_NEOX_EXCL_TOP151 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl151 <- summary(model.output.neo.excl151.q1)

# Data prep Q2,Q3 for excl151
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 151)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 151), paste0("RELABUN_NEOX_EXCL_TOP", 151), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP151 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 151)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP151 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 151)]))

# Model for excl151 Q2
model.output.neo.excl151.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP151 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl151 <- summary(model.output.neo.excl151.q2)

# Model for excl151 Q3
model.output.neo.excl151.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP151 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl151 <- summary(model.output.neo.excl151.q3)

cat("Model number 151 processed\n")

# Model for excl152 Q1
model.output.neo.excl152.q1 <- glmer(PA_NEOX_EXCL_TOP152 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl152 <- summary(model.output.neo.excl152.q1)

# Data prep Q2,Q3 for excl152
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 152)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 152), paste0("RELABUN_NEOX_EXCL_TOP", 152), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP152 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 152)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP152 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 152)]))

# Model for excl152 Q2
model.output.neo.excl152.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP152 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl152 <- summary(model.output.neo.excl152.q2)

# Model for excl152 Q3
model.output.neo.excl152.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP152 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl152 <- summary(model.output.neo.excl152.q3)

cat("Model number 152 processed\n")

# Model for excl153 Q1
model.output.neo.excl153.q1 <- glmer(PA_NEOX_EXCL_TOP153 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl153 <- summary(model.output.neo.excl153.q1)

# Data prep Q2,Q3 for excl153
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 153)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 153), paste0("RELABUN_NEOX_EXCL_TOP", 153), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP153 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 153)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP153 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 153)]))

# Model for excl153 Q2
model.output.neo.excl153.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP153 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl153 <- summary(model.output.neo.excl153.q2)

# Model for excl153 Q3
model.output.neo.excl153.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP153 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl153 <- summary(model.output.neo.excl153.q3)

cat("Model number 153 processed\n")

# Model for excl154 Q1
model.output.neo.excl154.q1 <- glmer(PA_NEOX_EXCL_TOP154 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl154 <- summary(model.output.neo.excl154.q1)

# Data prep Q2,Q3 for excl154
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 154)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 154), paste0("RELABUN_NEOX_EXCL_TOP", 154), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP154 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 154)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP154 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 154)]))

# Model for excl154 Q2
model.output.neo.excl154.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP154 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl154 <- summary(model.output.neo.excl154.q2)

# Model for excl154 Q3
model.output.neo.excl154.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP154 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl154 <- summary(model.output.neo.excl154.q3)

cat("Model number 154 processed\n")

# Model for excl155 Q1
model.output.neo.excl155.q1 <- glmer(PA_NEOX_EXCL_TOP155 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl155 <- summary(model.output.neo.excl155.q1)

# Data prep Q2,Q3 for excl155
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 155)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 155), paste0("RELABUN_NEOX_EXCL_TOP", 155), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP155 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 155)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP155 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 155)]))

# Model for excl155 Q2
model.output.neo.excl155.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP155 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl155 <- summary(model.output.neo.excl155.q2)

# Model for excl155 Q3
model.output.neo.excl155.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP155 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl155 <- summary(model.output.neo.excl155.q3)

cat("Model number 155 processed\n")

# Model for excl156 Q1
model.output.neo.excl156.q1 <- glmer(PA_NEOX_EXCL_TOP156 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl156 <- summary(model.output.neo.excl156.q1)

# Data prep Q2,Q3 for excl156
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 156)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 156), paste0("RELABUN_NEOX_EXCL_TOP", 156), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP156 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 156)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP156 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 156)]))

# Model for excl156 Q2
model.output.neo.excl156.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP156 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl156 <- summary(model.output.neo.excl156.q2)

# Model for excl156 Q3
model.output.neo.excl156.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP156 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl156 <- summary(model.output.neo.excl156.q3)

cat("Model number 156 processed\n")

# Model for excl157 Q1
model.output.neo.excl157.q1 <- glmer(PA_NEOX_EXCL_TOP157 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl157 <- summary(model.output.neo.excl157.q1)

# Data prep Q2,Q3 for excl157
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 157)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 157), paste0("RELABUN_NEOX_EXCL_TOP", 157), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP157 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 157)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP157 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 157)]))

# Model for excl157 Q2
model.output.neo.excl157.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP157 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl157 <- summary(model.output.neo.excl157.q2)

# Model for excl157 Q3
model.output.neo.excl157.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP157 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl157 <- summary(model.output.neo.excl157.q3)

cat("Model number 157 processed\n")

# Model for excl158 Q1
model.output.neo.excl158.q1 <- glmer(PA_NEOX_EXCL_TOP158 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl158 <- summary(model.output.neo.excl158.q1)

# Data prep Q2,Q3 for excl158
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 158)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 158), paste0("RELABUN_NEOX_EXCL_TOP", 158), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP158 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 158)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP158 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 158)]))

# Model for excl158 Q2
model.output.neo.excl158.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP158 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl158 <- summary(model.output.neo.excl158.q2)

# Model for excl158 Q3
model.output.neo.excl158.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP158 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl158 <- summary(model.output.neo.excl158.q3)

cat("Model number 158 processed\n")

# Model for excl159 Q1
model.output.neo.excl159.q1 <- glmer(PA_NEOX_EXCL_TOP159 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl159 <- summary(model.output.neo.excl159.q1)

# Data prep Q2,Q3 for excl159
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 159)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 159), paste0("RELABUN_NEOX_EXCL_TOP", 159), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP159 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 159)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP159 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 159)]))

# Model for excl159 Q2
model.output.neo.excl159.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP159 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl159 <- summary(model.output.neo.excl159.q2)

# Model for excl159 Q3
model.output.neo.excl159.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP159 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl159 <- summary(model.output.neo.excl159.q3)

cat("Model number 159 processed\n")

# Model for excl160 Q1
model.output.neo.excl160.q1 <- glmer(PA_NEOX_EXCL_TOP160 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s +  (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = "bobyqa", optCtrl = list(maxfun = 1e5)))
summary.model.neo.q1.excl160 <- summary(model.output.neo.excl160.q1)

# Data prep Q2,Q3 for excl160
awc_header_studyperiod_invaded_neox_excl <- subset(awc_header_studyperiod, get(paste0("RELABUN_NEOX_EXCL_TOP", 160)) > 0)
# Selecting relevant columns
relevant_cols <- c("YEAR", "LAT", "LON", "TEMP10", paste0("NB_NEOXS_EXCL_TOP", 160), paste0("RELABUN_NEOX_EXCL_TOP", 160), "NB_SPECIES", "MONTH", "Biblioref", "CROP_TYPE")
awc_header_studyperiod_invaded_neox_excl <- awc_header_studyperiod_invaded_neox_excl[, relevant_cols]
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RATIO_NEOX_EXCL_TOP160 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("NB_NEOXS_EXCL_TOP", 160)] / awc_header_studyperiod_invaded_neox_excl$NB_SPECIES))
awc_header_studyperiod_invaded_neox_excl$ASIN_SQRT_RELABUN_NEOX_EXCL_TOP160 <- asin(sqrt(awc_header_studyperiod_invaded_neox_excl[, paste0("RELABUN_NEOX_EXCL_TOP", 160)]))

# Model for excl160 Q2
model.output.neo.excl160.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_NEOX_EXCL_TOP160 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q2.excl160 <- summary(model.output.neo.excl160.q2)

# Model for excl160 Q3
model.output.neo.excl160.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_NEOX_EXCL_TOP160 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_neox_excl)
summary.model.neo.q3.excl160 <- summary(model.output.neo.excl160.q3)

cat("Model number 160 processed\n")

#### Archaeophytes ####
# Basic Models
model.output.arc.excl0.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) +  (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx)
summary.model.arc.q2.excl0 <- summary(model.output.arc.excl0.q2)

model.output.arc.excl0.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx)
summary.model.arc.q3.excl0 <- summary(model.output.arc.excl0.q3)

# Data prep Q2,Q3 for excl1
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 1)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 1), paste0('RELABUN_ARCX_EXCL_TOP', 1), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP1 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 1)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP1 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 1)]))

# Model for excl1 Q2
model.output.arc.excl1.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP1 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl1 <- summary(model.output.arc.excl1.q2)

# Model for excl1 Q3
model.output.arc.excl1.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP1 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl1 <- summary(model.output.arc.excl1.q3)
cat('Model number 1 processed\n')

# Model for excl2 Q1
model.output.arc.excl2.q1 <- glmer(PA_ARCX_EXCL_TOP2 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl2 <- summary(model.output.arc.excl2.q1)

# Data prep Q2,Q3 for excl2
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 2)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 2), paste0('RELABUN_ARCX_EXCL_TOP', 2), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP2 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 2)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP2 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 2)]))

# Model for excl2 Q2
model.output.arc.excl2.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP2 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl2 <- summary(model.output.arc.excl2.q2)

# Model for excl2 Q3
model.output.arc.excl2.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP2 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl2 <- summary(model.output.arc.excl2.q3)
cat('Model number 2 processed\n')

# Model for excl3 Q1
model.output.arc.excl3.q1 <- glmer(PA_ARCX_EXCL_TOP3 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl3 <- summary(model.output.arc.excl3.q1)

# Data prep Q2,Q3 for excl3
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 3)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 3), paste0('RELABUN_ARCX_EXCL_TOP', 3), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP3 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 3)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP3 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 3)]))

# Model for excl3 Q2
model.output.arc.excl3.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP3 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl3 <- summary(model.output.arc.excl3.q2)

# Model for excl3 Q3
model.output.arc.excl3.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP3 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl3 <- summary(model.output.arc.excl3.q3)
cat('Model number 3 processed\n')

# Model for excl4 Q1
model.output.arc.excl4.q1 <- glmer(PA_ARCX_EXCL_TOP4 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl4 <- summary(model.output.arc.excl4.q1)

# Data prep Q2,Q3 for excl4
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 4)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 4), paste0('RELABUN_ARCX_EXCL_TOP', 4), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP4 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 4)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP4 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 4)]))

# Model for excl4 Q2
model.output.arc.excl4.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP4 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl4 <- summary(model.output.arc.excl4.q2)

# Model for excl4 Q3
model.output.arc.excl4.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP4 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl4 <- summary(model.output.arc.excl4.q3)
cat('Model number 4 processed\n')

# Model for excl5 Q1
model.output.arc.excl5.q1 <- glmer(PA_ARCX_EXCL_TOP5 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl5 <- summary(model.output.arc.excl5.q1)

# Data prep Q2,Q3 for excl5
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 5)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 5), paste0('RELABUN_ARCX_EXCL_TOP', 5), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP5 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 5)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP5 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 5)]))

# Model for excl5 Q2
model.output.arc.excl5.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP5 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl5 <- summary(model.output.arc.excl5.q2)

# Model for excl5 Q3
model.output.arc.excl5.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP5 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl5 <- summary(model.output.arc.excl5.q3)
cat('Model number 5 processed\n')

# Model for excl6 Q1
model.output.arc.excl6.q1 <- glmer(PA_ARCX_EXCL_TOP6 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl6 <- summary(model.output.arc.excl6.q1)

# Data prep Q2,Q3 for excl6
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 6)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 6), paste0('RELABUN_ARCX_EXCL_TOP', 6), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP6 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 6)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP6 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 6)]))

# Model for excl6 Q2
model.output.arc.excl6.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP6 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl6 <- summary(model.output.arc.excl6.q2)

# Model for excl6 Q3
model.output.arc.excl6.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP6 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl6 <- summary(model.output.arc.excl6.q3)
cat('Model number 6 processed\n')

# Model for excl7 Q1
model.output.arc.excl7.q1 <- glmer(PA_ARCX_EXCL_TOP7 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl7 <- summary(model.output.arc.excl7.q1)

# Data prep Q2,Q3 for excl7
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 7)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 7), paste0('RELABUN_ARCX_EXCL_TOP', 7), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP7 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 7)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP7 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 7)]))

# Model for excl7 Q2
model.output.arc.excl7.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP7 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl7 <- summary(model.output.arc.excl7.q2)

# Model for excl7 Q3
model.output.arc.excl7.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP7 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl7 <- summary(model.output.arc.excl7.q3)
cat('Model number 7 processed\n')

# Model for excl8 Q1
model.output.arc.excl8.q1 <- glmer(PA_ARCX_EXCL_TOP8 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl8 <- summary(model.output.arc.excl8.q1)

# Data prep Q2,Q3 for excl8
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 8)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 8), paste0('RELABUN_ARCX_EXCL_TOP', 8), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP8 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 8)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP8 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 8)]))

# Model for excl8 Q2
model.output.arc.excl8.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP8 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl8 <- summary(model.output.arc.excl8.q2)

# Model for excl8 Q3
model.output.arc.excl8.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP8 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl8 <- summary(model.output.arc.excl8.q3)
cat('Model number 8 processed\n')

# Model for excl9 Q1
model.output.arc.excl9.q1 <- glmer(PA_ARCX_EXCL_TOP9 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl9 <- summary(model.output.arc.excl9.q1)

# Data prep Q2,Q3 for excl9
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 9)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 9), paste0('RELABUN_ARCX_EXCL_TOP', 9), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP9 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 9)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP9 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 9)]))

# Model for excl9 Q2
model.output.arc.excl9.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP9 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl9 <- summary(model.output.arc.excl9.q2)

# Model for excl9 Q3
model.output.arc.excl9.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP9 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl9 <- summary(model.output.arc.excl9.q3)
cat('Model number 9 processed\n')

# Model for excl10 Q1
model.output.arc.excl10.q1 <- glmer(PA_ARCX_EXCL_TOP10 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl10 <- summary(model.output.arc.excl10.q1)

# Data prep Q2,Q3 for excl10
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 10)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 10), paste0('RELABUN_ARCX_EXCL_TOP', 10), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP10 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 10)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP10 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 10)]))

# Model for excl10 Q2
model.output.arc.excl10.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP10 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl10 <- summary(model.output.arc.excl10.q2)

# Model for excl10 Q3
model.output.arc.excl10.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP10 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl10 <- summary(model.output.arc.excl10.q3)
cat('Model number 10 processed\n')

# Model for excl11 Q1
model.output.arc.excl11.q1 <- glmer(PA_ARCX_EXCL_TOP11 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl11 <- summary(model.output.arc.excl11.q1)

# Data prep Q2,Q3 for excl11
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 11)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 11), paste0('RELABUN_ARCX_EXCL_TOP', 11), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP11 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 11)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP11 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 11)]))

# Model for excl11 Q2
model.output.arc.excl11.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP11 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl11 <- summary(model.output.arc.excl11.q2)

# Model for excl11 Q3
model.output.arc.excl11.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP11 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl11 <- summary(model.output.arc.excl11.q3)
cat('Model number 11 processed\n')

# Model for excl12 Q1
model.output.arc.excl12.q1 <- glmer(PA_ARCX_EXCL_TOP12 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl12 <- summary(model.output.arc.excl12.q1)

# Data prep Q2,Q3 for excl12
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 12)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 12), paste0('RELABUN_ARCX_EXCL_TOP', 12), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP12 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 12)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP12 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 12)]))

# Model for excl12 Q2
model.output.arc.excl12.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP12 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl12 <- summary(model.output.arc.excl12.q2)

# Model for excl12 Q3
model.output.arc.excl12.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP12 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl12 <- summary(model.output.arc.excl12.q3)
cat('Model number 12 processed\n')

# Model for excl13 Q1
model.output.arc.excl13.q1 <- glmer(PA_ARCX_EXCL_TOP13 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl13 <- summary(model.output.arc.excl13.q1)

# Data prep Q2,Q3 for excl13
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 13)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 13), paste0('RELABUN_ARCX_EXCL_TOP', 13), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP13 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 13)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP13 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 13)]))

# Model for excl13 Q2
model.output.arc.excl13.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP13 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl13 <- summary(model.output.arc.excl13.q2)

# Model for excl13 Q3
model.output.arc.excl13.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP13 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl13 <- summary(model.output.arc.excl13.q3)
cat('Model number 13 processed\n')

# Model for excl14 Q1
model.output.arc.excl14.q1 <- glmer(PA_ARCX_EXCL_TOP14 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl14 <- summary(model.output.arc.excl14.q1)

# Data prep Q2,Q3 for excl14
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 14)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 14), paste0('RELABUN_ARCX_EXCL_TOP', 14), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP14 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 14)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP14 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 14)]))

# Model for excl14 Q2
model.output.arc.excl14.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP14 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl14 <- summary(model.output.arc.excl14.q2)

# Model for excl14 Q3
model.output.arc.excl14.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP14 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl14 <- summary(model.output.arc.excl14.q3)
cat('Model number 14 processed\n')

# Model for excl15 Q1
model.output.arc.excl15.q1 <- glmer(PA_ARCX_EXCL_TOP15 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl15 <- summary(model.output.arc.excl15.q1)

# Data prep Q2,Q3 for excl15
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 15)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 15), paste0('RELABUN_ARCX_EXCL_TOP', 15), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP15 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 15)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP15 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 15)]))

# Model for excl15 Q2
model.output.arc.excl15.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP15 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl15 <- summary(model.output.arc.excl15.q2)

# Model for excl15 Q3
model.output.arc.excl15.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP15 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl15 <- summary(model.output.arc.excl15.q3)
cat('Model number 15 processed\n')

# Model for excl16 Q1
model.output.arc.excl16.q1 <- glmer(PA_ARCX_EXCL_TOP16 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl16 <- summary(model.output.arc.excl16.q1)

# Data prep Q2,Q3 for excl16
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 16)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 16), paste0('RELABUN_ARCX_EXCL_TOP', 16), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP16 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 16)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP16 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 16)]))

# Model for excl16 Q2
model.output.arc.excl16.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP16 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl16 <- summary(model.output.arc.excl16.q2)

# Model for excl16 Q3
model.output.arc.excl16.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP16 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl16 <- summary(model.output.arc.excl16.q3)
cat('Model number 16 processed\n')

# Model for excl17 Q1
model.output.arc.excl17.q1 <- glmer(PA_ARCX_EXCL_TOP17 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl17 <- summary(model.output.arc.excl17.q1)

# Data prep Q2,Q3 for excl17
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 17)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 17), paste0('RELABUN_ARCX_EXCL_TOP', 17), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP17 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 17)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP17 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 17)]))

# Model for excl17 Q2
model.output.arc.excl17.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP17 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl17 <- summary(model.output.arc.excl17.q2)

# Model for excl17 Q3
model.output.arc.excl17.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP17 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl17 <- summary(model.output.arc.excl17.q3)
cat('Model number 17 processed\n')

# Model for excl18 Q1
model.output.arc.excl18.q1 <- glmer(PA_ARCX_EXCL_TOP18 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl18 <- summary(model.output.arc.excl18.q1)

# Data prep Q2,Q3 for excl18
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 18)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 18), paste0('RELABUN_ARCX_EXCL_TOP', 18), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP18 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 18)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP18 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 18)]))

# Model for excl18 Q2
model.output.arc.excl18.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP18 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl18 <- summary(model.output.arc.excl18.q2)

# Model for excl18 Q3
model.output.arc.excl18.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP18 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl18 <- summary(model.output.arc.excl18.q3)
cat('Model number 18 processed\n')

# Model for excl19 Q1
model.output.arc.excl19.q1 <- glmer(PA_ARCX_EXCL_TOP19 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl19 <- summary(model.output.arc.excl19.q1)

# Data prep Q2,Q3 for excl19
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 19)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 19), paste0('RELABUN_ARCX_EXCL_TOP', 19), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP19 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 19)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP19 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 19)]))

# Model for excl19 Q2
model.output.arc.excl19.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP19 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl19 <- summary(model.output.arc.excl19.q2)

# Model for excl19 Q3
model.output.arc.excl19.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP19 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl19 <- summary(model.output.arc.excl19.q3)
cat('Model number 19 processed\n')

# Model for excl20 Q1
model.output.arc.excl20.q1 <- glmer(PA_ARCX_EXCL_TOP20 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl20 <- summary(model.output.arc.excl20.q1)

# Data prep Q2,Q3 for excl20
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 20)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 20), paste0('RELABUN_ARCX_EXCL_TOP', 20), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP20 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 20)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP20 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 20)]))

# Model for excl20 Q2
model.output.arc.excl20.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP20 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl20 <- summary(model.output.arc.excl20.q2)

# Model for excl20 Q3
model.output.arc.excl20.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP20 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl20 <- summary(model.output.arc.excl20.q3)
cat('Model number 20 processed\n')

# Model for excl21 Q1
model.output.arc.excl21.q1 <- glmer(PA_ARCX_EXCL_TOP21 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl21 <- summary(model.output.arc.excl21.q1)

# Data prep Q2,Q3 for excl21
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 21)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 21), paste0('RELABUN_ARCX_EXCL_TOP', 21), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP21 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 21)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP21 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 21)]))

# Model for excl21 Q2
model.output.arc.excl21.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP21 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl21 <- summary(model.output.arc.excl21.q2)

# Model for excl21 Q3
model.output.arc.excl21.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP21 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl21 <- summary(model.output.arc.excl21.q3)
cat('Model number 21 processed\n')

# Model for excl22 Q1
model.output.arc.excl22.q1 <- glmer(PA_ARCX_EXCL_TOP22 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl22 <- summary(model.output.arc.excl22.q1)

# Data prep Q2,Q3 for excl22
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 22)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 22), paste0('RELABUN_ARCX_EXCL_TOP', 22), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP22 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 22)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP22 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 22)]))

# Model for excl22 Q2
model.output.arc.excl22.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP22 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl22 <- summary(model.output.arc.excl22.q2)

# Model for excl22 Q3
model.output.arc.excl22.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP22 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl22 <- summary(model.output.arc.excl22.q3)
cat('Model number 22 processed\n')

# Model for excl23 Q1
model.output.arc.excl23.q1 <- glmer(PA_ARCX_EXCL_TOP23 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl23 <- summary(model.output.arc.excl23.q1)

# Data prep Q2,Q3 for excl23
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 23)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 23), paste0('RELABUN_ARCX_EXCL_TOP', 23), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP23 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 23)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP23 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 23)]))

# Model for excl23 Q2
model.output.arc.excl23.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP23 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl23 <- summary(model.output.arc.excl23.q2)

# Model for excl23 Q3
model.output.arc.excl23.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP23 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl23 <- summary(model.output.arc.excl23.q3)
cat('Model number 23 processed\n')

# Model for excl24 Q1
model.output.arc.excl24.q1 <- glmer(PA_ARCX_EXCL_TOP24 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl24 <- summary(model.output.arc.excl24.q1)

# Data prep Q2,Q3 for excl24
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 24)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 24), paste0('RELABUN_ARCX_EXCL_TOP', 24), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP24 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 24)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP24 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 24)]))

# Model for excl24 Q2
model.output.arc.excl24.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP24 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl24 <- summary(model.output.arc.excl24.q2)

# Model for excl24 Q3
model.output.arc.excl24.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP24 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl24 <- summary(model.output.arc.excl24.q3)
cat('Model number 24 processed\n')

# Model for excl25 Q1
model.output.arc.excl25.q1 <- glmer(PA_ARCX_EXCL_TOP25 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl25 <- summary(model.output.arc.excl25.q1)

# Data prep Q2,Q3 for excl25
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 25)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 25), paste0('RELABUN_ARCX_EXCL_TOP', 25), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP25 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 25)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP25 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 25)]))

# Model for excl25 Q2
model.output.arc.excl25.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP25 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl25 <- summary(model.output.arc.excl25.q2)

# Model for excl25 Q3
model.output.arc.excl25.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP25 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl25 <- summary(model.output.arc.excl25.q3)
cat('Model number 25 processed\n')

# Model for excl26 Q1
model.output.arc.excl26.q1 <- glmer(PA_ARCX_EXCL_TOP26 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl26 <- summary(model.output.arc.excl26.q1)

# Data prep Q2,Q3 for excl26
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 26)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 26), paste0('RELABUN_ARCX_EXCL_TOP', 26), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP26 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 26)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP26 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 26)]))

# Model for excl26 Q2
model.output.arc.excl26.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP26 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl26 <- summary(model.output.arc.excl26.q2)

# Model for excl26 Q3
model.output.arc.excl26.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP26 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl26 <- summary(model.output.arc.excl26.q3)
cat('Model number 26 processed\n')

# Model for excl27 Q1
model.output.arc.excl27.q1 <- glmer(PA_ARCX_EXCL_TOP27 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl27 <- summary(model.output.arc.excl27.q1)

# Data prep Q2,Q3 for excl27
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 27)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 27), paste0('RELABUN_ARCX_EXCL_TOP', 27), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP27 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 27)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP27 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 27)]))

# Model for excl27 Q2
model.output.arc.excl27.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP27 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl27 <- summary(model.output.arc.excl27.q2)

# Model for excl27 Q3
model.output.arc.excl27.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP27 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl27 <- summary(model.output.arc.excl27.q3)
cat('Model number 27 processed\n')

# Model for excl28 Q1
model.output.arc.excl28.q1 <- glmer(PA_ARCX_EXCL_TOP28 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl28 <- summary(model.output.arc.excl28.q1)

# Data prep Q2,Q3 for excl28
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 28)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 28), paste0('RELABUN_ARCX_EXCL_TOP', 28), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP28 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 28)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP28 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 28)]))

# Model for excl28 Q2
model.output.arc.excl28.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP28 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl28 <- summary(model.output.arc.excl28.q2)

# Model for excl28 Q3
model.output.arc.excl28.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP28 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl28 <- summary(model.output.arc.excl28.q3)
cat('Model number 28 processed\n')

# Model for excl29 Q1
model.output.arc.excl29.q1 <- glmer(PA_ARCX_EXCL_TOP29 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl29 <- summary(model.output.arc.excl29.q1)

# Data prep Q2,Q3 for excl29
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 29)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 29), paste0('RELABUN_ARCX_EXCL_TOP', 29), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP29 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 29)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP29 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 29)]))

# Model for excl29 Q2
model.output.arc.excl29.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP29 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl29 <- summary(model.output.arc.excl29.q2)

# Model for excl29 Q3
model.output.arc.excl29.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP29 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl29 <- summary(model.output.arc.excl29.q3)
cat('Model number 29 processed\n')

# Model for excl30 Q1
model.output.arc.excl30.q1 <- glmer(PA_ARCX_EXCL_TOP30 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl30 <- summary(model.output.arc.excl30.q1)

# Data prep Q2,Q3 for excl30
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 30)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 30), paste0('RELABUN_ARCX_EXCL_TOP', 30), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP30 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 30)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP30 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 30)]))

# Model for excl30 Q2
model.output.arc.excl30.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP30 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl30 <- summary(model.output.arc.excl30.q2)

# Model for excl30 Q3
model.output.arc.excl30.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP30 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl30 <- summary(model.output.arc.excl30.q3)
cat('Model number 30 processed\n')

# Model for excl31 Q1
model.output.arc.excl31.q1 <- glmer(PA_ARCX_EXCL_TOP31 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl31 <- summary(model.output.arc.excl31.q1)

# Data prep Q2,Q3 for excl31
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 31)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 31), paste0('RELABUN_ARCX_EXCL_TOP', 31), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP31 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 31)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP31 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 31)]))

# Model for excl31 Q2
model.output.arc.excl31.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP31 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl31 <- summary(model.output.arc.excl31.q2)

# Model for excl31 Q3
model.output.arc.excl31.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP31 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl31 <- summary(model.output.arc.excl31.q3)
cat('Model number 31 processed\n')

# Model for excl32 Q1
model.output.arc.excl32.q1 <- glmer(PA_ARCX_EXCL_TOP32 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl32 <- summary(model.output.arc.excl32.q1)

# Data prep Q2,Q3 for excl32
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 32)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 32), paste0('RELABUN_ARCX_EXCL_TOP', 32), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP32 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 32)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP32 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 32)]))

# Model for excl32 Q2
model.output.arc.excl32.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP32 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl32 <- summary(model.output.arc.excl32.q2)

# Model for excl32 Q3
model.output.arc.excl32.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP32 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl32 <- summary(model.output.arc.excl32.q3)
cat('Model number 32 processed\n')

# Model for excl33 Q1
model.output.arc.excl33.q1 <- glmer(PA_ARCX_EXCL_TOP33 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl33 <- summary(model.output.arc.excl33.q1)

# Data prep Q2,Q3 for excl33
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 33)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 33), paste0('RELABUN_ARCX_EXCL_TOP', 33), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP33 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 33)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP33 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 33)]))

# Model for excl33 Q2
model.output.arc.excl33.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP33 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl33 <- summary(model.output.arc.excl33.q2)

# Model for excl33 Q3
model.output.arc.excl33.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP33 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl33 <- summary(model.output.arc.excl33.q3)
cat('Model number 33 processed\n')

# Model for excl34 Q1
model.output.arc.excl34.q1 <- glmer(PA_ARCX_EXCL_TOP34 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl34 <- summary(model.output.arc.excl34.q1)

# Data prep Q2,Q3 for excl34
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 34)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 34), paste0('RELABUN_ARCX_EXCL_TOP', 34), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP34 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 34)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP34 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 34)]))

# Model for excl34 Q2
model.output.arc.excl34.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP34 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl34 <- summary(model.output.arc.excl34.q2)

# Model for excl34 Q3
model.output.arc.excl34.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP34 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl34 <- summary(model.output.arc.excl34.q3)
cat('Model number 34 processed\n')

# Model for excl35 Q1
model.output.arc.excl35.q1 <- glmer(PA_ARCX_EXCL_TOP35 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl35 <- summary(model.output.arc.excl35.q1)

# Data prep Q2,Q3 for excl35
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 35)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 35), paste0('RELABUN_ARCX_EXCL_TOP', 35), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP35 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 35)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP35 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 35)]))

# Model for excl35 Q2
model.output.arc.excl35.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP35 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl35 <- summary(model.output.arc.excl35.q2)

# Model for excl35 Q3
model.output.arc.excl35.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP35 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl35 <- summary(model.output.arc.excl35.q3)
cat('Model number 35 processed\n')

# Model for excl36 Q1
model.output.arc.excl36.q1 <- glmer(PA_ARCX_EXCL_TOP36 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl36 <- summary(model.output.arc.excl36.q1)

# Data prep Q2,Q3 for excl36
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 36)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 36), paste0('RELABUN_ARCX_EXCL_TOP', 36), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP36 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 36)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP36 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 36)]))

# Model for excl36 Q2
model.output.arc.excl36.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP36 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl36 <- summary(model.output.arc.excl36.q2)

# Model for excl36 Q3
model.output.arc.excl36.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP36 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl36 <- summary(model.output.arc.excl36.q3)
cat('Model number 36 processed\n')

# Model for excl37 Q1
model.output.arc.excl37.q1 <- glmer(PA_ARCX_EXCL_TOP37 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl37 <- summary(model.output.arc.excl37.q1)

# Data prep Q2,Q3 for excl37
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 37)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 37), paste0('RELABUN_ARCX_EXCL_TOP', 37), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP37 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 37)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP37 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 37)]))

# Model for excl37 Q2
model.output.arc.excl37.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP37 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl37 <- summary(model.output.arc.excl37.q2)

# Model for excl37 Q3
model.output.arc.excl37.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP37 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl37 <- summary(model.output.arc.excl37.q3)
cat('Model number 37 processed\n')

# Model for excl38 Q1
model.output.arc.excl38.q1 <- glmer(PA_ARCX_EXCL_TOP38 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl38 <- summary(model.output.arc.excl38.q1)

# Data prep Q2,Q3 for excl38
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 38)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 38), paste0('RELABUN_ARCX_EXCL_TOP', 38), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP38 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 38)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP38 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 38)]))

# Model for excl38 Q2
model.output.arc.excl38.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP38 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl38 <- summary(model.output.arc.excl38.q2)

# Model for excl38 Q3
model.output.arc.excl38.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP38 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl38 <- summary(model.output.arc.excl38.q3)
cat('Model number 38 processed\n')

# Model for excl39 Q1
model.output.arc.excl39.q1 <- glmer(PA_ARCX_EXCL_TOP39 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl39 <- summary(model.output.arc.excl39.q1)

# Data prep Q2,Q3 for excl39
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 39)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 39), paste0('RELABUN_ARCX_EXCL_TOP', 39), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP39 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 39)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP39 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 39)]))

# Model for excl39 Q2
model.output.arc.excl39.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP39 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl39 <- summary(model.output.arc.excl39.q2)

# Model for excl39 Q3
model.output.arc.excl39.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP39 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl39 <- summary(model.output.arc.excl39.q3)
cat('Model number 39 processed\n')

# Model for excl40 Q1
model.output.arc.excl40.q1 <- glmer(PA_ARCX_EXCL_TOP40 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl40 <- summary(model.output.arc.excl40.q1)

# Data prep Q2,Q3 for excl40
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 40)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 40), paste0('RELABUN_ARCX_EXCL_TOP', 40), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP40 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 40)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP40 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 40)]))

# Model for excl40 Q2
model.output.arc.excl40.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP40 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl40 <- summary(model.output.arc.excl40.q2)

# Model for excl40 Q3
model.output.arc.excl40.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP40 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl40 <- summary(model.output.arc.excl40.q3)
cat('Model number 40 processed\n')

# Model for excl41 Q1
model.output.arc.excl41.q1 <- glmer(PA_ARCX_EXCL_TOP41 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl41 <- summary(model.output.arc.excl41.q1)

# Data prep Q2,Q3 for excl41
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 41)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 41), paste0('RELABUN_ARCX_EXCL_TOP', 41), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP41 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 41)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP41 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 41)]))

# Model for excl41 Q2
model.output.arc.excl41.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP41 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl41 <- summary(model.output.arc.excl41.q2)

# Model for excl41 Q3
model.output.arc.excl41.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP41 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl41 <- summary(model.output.arc.excl41.q3)
cat('Model number 41 processed\n')

# Model for excl42 Q1
model.output.arc.excl42.q1 <- glmer(PA_ARCX_EXCL_TOP42 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl42 <- summary(model.output.arc.excl42.q1)

# Data prep Q2,Q3 for excl42
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 42)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 42), paste0('RELABUN_ARCX_EXCL_TOP', 42), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP42 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 42)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP42 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 42)]))

# Model for excl42 Q2
model.output.arc.excl42.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP42 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl42 <- summary(model.output.arc.excl42.q2)

# Model for excl42 Q3
model.output.arc.excl42.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP42 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl42 <- summary(model.output.arc.excl42.q3)
cat('Model number 42 processed\n')

# Model for excl43 Q1
model.output.arc.excl43.q1 <- glmer(PA_ARCX_EXCL_TOP43 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl43 <- summary(model.output.arc.excl43.q1)

# Data prep Q2,Q3 for excl43
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 43)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 43), paste0('RELABUN_ARCX_EXCL_TOP', 43), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP43 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 43)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP43 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 43)]))

# Model for excl43 Q2
model.output.arc.excl43.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP43 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl43 <- summary(model.output.arc.excl43.q2)

# Model for excl43 Q3
model.output.arc.excl43.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP43 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl43 <- summary(model.output.arc.excl43.q3)
cat('Model number 43 processed\n')

# Model for excl44 Q1
model.output.arc.excl44.q1 <- glmer(PA_ARCX_EXCL_TOP44 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl44 <- summary(model.output.arc.excl44.q1)

# Data prep Q2,Q3 for excl44
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 44)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 44), paste0('RELABUN_ARCX_EXCL_TOP', 44), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP44 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 44)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP44 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 44)]))

# Model for excl44 Q2
model.output.arc.excl44.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP44 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl44 <- summary(model.output.arc.excl44.q2)

# Model for excl44 Q3
model.output.arc.excl44.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP44 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl44 <- summary(model.output.arc.excl44.q3)
cat('Model number 44 processed\n')

# Model for excl45 Q1
model.output.arc.excl45.q1 <- glmer(PA_ARCX_EXCL_TOP45 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl45 <- summary(model.output.arc.excl45.q1)

# Data prep Q2,Q3 for excl45
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 45)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 45), paste0('RELABUN_ARCX_EXCL_TOP', 45), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP45 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 45)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP45 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 45)]))

# Model for excl45 Q2
model.output.arc.excl45.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP45 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl45 <- summary(model.output.arc.excl45.q2)

# Model for excl45 Q3
model.output.arc.excl45.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP45 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl45 <- summary(model.output.arc.excl45.q3)
cat('Model number 45 processed\n')

# Model for excl46 Q1
model.output.arc.excl46.q1 <- glmer(PA_ARCX_EXCL_TOP46 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl46 <- summary(model.output.arc.excl46.q1)

# Data prep Q2,Q3 for excl46
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 46)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 46), paste0('RELABUN_ARCX_EXCL_TOP', 46), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP46 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 46)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP46 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 46)]))

# Model for excl46 Q2
model.output.arc.excl46.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP46 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl46 <- summary(model.output.arc.excl46.q2)

# Model for excl46 Q3
model.output.arc.excl46.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP46 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl46 <- summary(model.output.arc.excl46.q3)
cat('Model number 46 processed\n')

# Model for excl47 Q1
model.output.arc.excl47.q1 <- glmer(PA_ARCX_EXCL_TOP47 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl47 <- summary(model.output.arc.excl47.q1)

# Data prep Q2,Q3 for excl47
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 47)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 47), paste0('RELABUN_ARCX_EXCL_TOP', 47), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP47 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 47)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP47 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 47)]))

# Model for excl47 Q2
model.output.arc.excl47.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP47 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl47 <- summary(model.output.arc.excl47.q2)

# Model for excl47 Q3
model.output.arc.excl47.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP47 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl47 <- summary(model.output.arc.excl47.q3)
cat('Model number 47 processed\n')

# Model for excl48 Q1
model.output.arc.excl48.q1 <- glmer(PA_ARCX_EXCL_TOP48 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl48 <- summary(model.output.arc.excl48.q1)

# Data prep Q2,Q3 for excl48
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 48)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 48), paste0('RELABUN_ARCX_EXCL_TOP', 48), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP48 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 48)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP48 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 48)]))

# Model for excl48 Q2
model.output.arc.excl48.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP48 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl48 <- summary(model.output.arc.excl48.q2)

# Model for excl48 Q3
model.output.arc.excl48.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP48 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl48 <- summary(model.output.arc.excl48.q3)
cat('Model number 48 processed\n')

# Model for excl49 Q1
model.output.arc.excl49.q1 <- glmer(PA_ARCX_EXCL_TOP49 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl49 <- summary(model.output.arc.excl49.q1)

# Data prep Q2,Q3 for excl49
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 49)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 49), paste0('RELABUN_ARCX_EXCL_TOP', 49), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP49 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 49)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP49 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 49)]))

# Model for excl49 Q2
model.output.arc.excl49.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP49 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl49 <- summary(model.output.arc.excl49.q2)

# Model for excl49 Q3
model.output.arc.excl49.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP49 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl49 <- summary(model.output.arc.excl49.q3)
cat('Model number 49 processed\n')

# Model for excl50 Q1
model.output.arc.excl50.q1 <- glmer(PA_ARCX_EXCL_TOP50 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl50 <- summary(model.output.arc.excl50.q1)

# Data prep Q2,Q3 for excl50
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 50)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 50), paste0('RELABUN_ARCX_EXCL_TOP', 50), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP50 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 50)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP50 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 50)]))

# Model for excl50 Q2
model.output.arc.excl50.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP50 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl50 <- summary(model.output.arc.excl50.q2)

# Model for excl50 Q3
model.output.arc.excl50.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP50 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl50 <- summary(model.output.arc.excl50.q3)
cat('Model number 50 processed\n')

# Model for excl51 Q1
model.output.arc.excl51.q1 <- glmer(PA_ARCX_EXCL_TOP51 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl51 <- summary(model.output.arc.excl51.q1)

# Data prep Q2,Q3 for excl51
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 51)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 51), paste0('RELABUN_ARCX_EXCL_TOP', 51), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP51 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 51)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP51 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 51)]))

# Model for excl51 Q2
model.output.arc.excl51.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP51 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl51 <- summary(model.output.arc.excl51.q2)

# Model for excl51 Q3
model.output.arc.excl51.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP51 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl51 <- summary(model.output.arc.excl51.q3)
cat('Model number 51 processed\n')

# Model for excl52 Q1
model.output.arc.excl52.q1 <- glmer(PA_ARCX_EXCL_TOP52 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl52 <- summary(model.output.arc.excl52.q1)

# Data prep Q2,Q3 for excl52
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 52)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 52), paste0('RELABUN_ARCX_EXCL_TOP', 52), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP52 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 52)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP52 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 52)]))

# Model for excl52 Q2
model.output.arc.excl52.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP52 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl52 <- summary(model.output.arc.excl52.q2)

# Model for excl52 Q3
model.output.arc.excl52.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP52 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl52 <- summary(model.output.arc.excl52.q3)
cat('Model number 52 processed\n')

# Model for excl53 Q1
model.output.arc.excl53.q1 <- glmer(PA_ARCX_EXCL_TOP53 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl53 <- summary(model.output.arc.excl53.q1)

# Data prep Q2,Q3 for excl53
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 53)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 53), paste0('RELABUN_ARCX_EXCL_TOP', 53), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP53 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 53)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP53 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 53)]))

# Model for excl53 Q2
model.output.arc.excl53.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP53 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl53 <- summary(model.output.arc.excl53.q2)

# Model for excl53 Q3
model.output.arc.excl53.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP53 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl53 <- summary(model.output.arc.excl53.q3)
cat('Model number 53 processed\n')

# Model for excl54 Q1
model.output.arc.excl54.q1 <- glmer(PA_ARCX_EXCL_TOP54 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl54 <- summary(model.output.arc.excl54.q1)

# Data prep Q2,Q3 for excl54
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 54)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 54), paste0('RELABUN_ARCX_EXCL_TOP', 54), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP54 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 54)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP54 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 54)]))

# Model for excl54 Q2
model.output.arc.excl54.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP54 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl54 <- summary(model.output.arc.excl54.q2)

# Model for excl54 Q3
model.output.arc.excl54.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP54 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl54 <- summary(model.output.arc.excl54.q3)
cat('Model number 54 processed\n')

# Model for excl55 Q1
model.output.arc.excl55.q1 <- glmer(PA_ARCX_EXCL_TOP55 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl55 <- summary(model.output.arc.excl55.q1)

# Data prep Q2,Q3 for excl55
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 55)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 55), paste0('RELABUN_ARCX_EXCL_TOP', 55), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP55 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 55)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP55 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 55)]))

# Model for excl55 Q2
model.output.arc.excl55.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP55 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl55 <- summary(model.output.arc.excl55.q2)

# Model for excl55 Q3
model.output.arc.excl55.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP55 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl55 <- summary(model.output.arc.excl55.q3)
cat('Model number 55 processed\n')

# Model for excl56 Q1
model.output.arc.excl56.q1 <- glmer(PA_ARCX_EXCL_TOP56 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl56 <- summary(model.output.arc.excl56.q1)

# Data prep Q2,Q3 for excl56
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 56)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 56), paste0('RELABUN_ARCX_EXCL_TOP', 56), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP56 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 56)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP56 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 56)]))

# Model for excl56 Q2
model.output.arc.excl56.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP56 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl56 <- summary(model.output.arc.excl56.q2)

# Model for excl56 Q3
model.output.arc.excl56.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP56 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl56 <- summary(model.output.arc.excl56.q3)
cat('Model number 56 processed\n')

# Model for excl57 Q1
model.output.arc.excl57.q1 <- glmer(PA_ARCX_EXCL_TOP57 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl57 <- summary(model.output.arc.excl57.q1)

# Data prep Q2,Q3 for excl57
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 57)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 57), paste0('RELABUN_ARCX_EXCL_TOP', 57), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP57 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 57)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP57 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 57)]))

# Model for excl57 Q2
model.output.arc.excl57.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP57 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl57 <- summary(model.output.arc.excl57.q2)

# Model for excl57 Q3
model.output.arc.excl57.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP57 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl57 <- summary(model.output.arc.excl57.q3)
cat('Model number 57 processed\n')

# Model for excl58 Q1
model.output.arc.excl58.q1 <- glmer(PA_ARCX_EXCL_TOP58 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl58 <- summary(model.output.arc.excl58.q1)

# Data prep Q2,Q3 for excl58
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 58)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 58), paste0('RELABUN_ARCX_EXCL_TOP', 58), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP58 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 58)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP58 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 58)]))

# Model for excl58 Q2
model.output.arc.excl58.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP58 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl58 <- summary(model.output.arc.excl58.q2)

# Model for excl58 Q3
model.output.arc.excl58.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP58 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl58 <- summary(model.output.arc.excl58.q3)
cat('Model number 58 processed\n')

# Model for excl59 Q1
model.output.arc.excl59.q1 <- glmer(PA_ARCX_EXCL_TOP59 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl59 <- summary(model.output.arc.excl59.q1)

# Data prep Q2,Q3 for excl59
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 59)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 59), paste0('RELABUN_ARCX_EXCL_TOP', 59), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP59 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 59)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP59 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 59)]))

# Model for excl59 Q2
model.output.arc.excl59.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP59 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl59 <- summary(model.output.arc.excl59.q2)

# Model for excl59 Q3
model.output.arc.excl59.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP59 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl59 <- summary(model.output.arc.excl59.q3)
cat('Model number 59 processed\n')

# Model for excl60 Q1
model.output.arc.excl60.q1 <- glmer(PA_ARCX_EXCL_TOP60 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl60 <- summary(model.output.arc.excl60.q1)

# Data prep Q2,Q3 for excl60
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 60)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 60), paste0('RELABUN_ARCX_EXCL_TOP', 60), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP60 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 60)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP60 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 60)]))

# Model for excl60 Q2
model.output.arc.excl60.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP60 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl60 <- summary(model.output.arc.excl60.q2)

# Model for excl60 Q3
model.output.arc.excl60.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP60 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl60 <- summary(model.output.arc.excl60.q3)
cat('Model number 60 processed\n')

# Model for excl61 Q1
model.output.arc.excl61.q1 <- glmer(PA_ARCX_EXCL_TOP61 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl61 <- summary(model.output.arc.excl61.q1)

# Data prep Q2,Q3 for excl61
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 61)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 61), paste0('RELABUN_ARCX_EXCL_TOP', 61), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP61 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 61)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP61 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 61)]))

# Model for excl61 Q2
model.output.arc.excl61.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP61 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl61 <- summary(model.output.arc.excl61.q2)

# Model for excl61 Q3
model.output.arc.excl61.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP61 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl61 <- summary(model.output.arc.excl61.q3)
cat('Model number 61 processed\n')

# Model for excl62 Q1
model.output.arc.excl62.q1 <- glmer(PA_ARCX_EXCL_TOP62 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl62 <- summary(model.output.arc.excl62.q1)

# Data prep Q2,Q3 for excl62
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 62)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 62), paste0('RELABUN_ARCX_EXCL_TOP', 62), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP62 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 62)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP62 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 62)]))

# Model for excl62 Q2
model.output.arc.excl62.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP62 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl62 <- summary(model.output.arc.excl62.q2)

# Model for excl62 Q3
model.output.arc.excl62.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP62 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl62 <- summary(model.output.arc.excl62.q3)
cat('Model number 62 processed\n')

# Model for excl63 Q1
model.output.arc.excl63.q1 <- glmer(PA_ARCX_EXCL_TOP63 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl63 <- summary(model.output.arc.excl63.q1)

# Data prep Q2,Q3 for excl63
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 63)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 63), paste0('RELABUN_ARCX_EXCL_TOP', 63), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP63 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 63)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP63 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 63)]))

# Model for excl63 Q2
model.output.arc.excl63.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP63 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl63 <- summary(model.output.arc.excl63.q2)

# Model for excl63 Q3
model.output.arc.excl63.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP63 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl63 <- summary(model.output.arc.excl63.q3)
cat('Model number 63 processed\n')

# Model for excl64 Q1
model.output.arc.excl64.q1 <- glmer(PA_ARCX_EXCL_TOP64 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl64 <- summary(model.output.arc.excl64.q1)

# Data prep Q2,Q3 for excl64
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 64)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 64), paste0('RELABUN_ARCX_EXCL_TOP', 64), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP64 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 64)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP64 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 64)]))

# Model for excl64 Q2
model.output.arc.excl64.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP64 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl64 <- summary(model.output.arc.excl64.q2)

# Model for excl64 Q3
model.output.arc.excl64.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP64 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl64 <- summary(model.output.arc.excl64.q3)
cat('Model number 64 processed\n')

# Model for excl65 Q1
model.output.arc.excl65.q1 <- glmer(PA_ARCX_EXCL_TOP65 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl65 <- summary(model.output.arc.excl65.q1)

# Data prep Q2,Q3 for excl65
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 65)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 65), paste0('RELABUN_ARCX_EXCL_TOP', 65), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP65 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 65)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP65 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 65)]))

# Model for excl65 Q2
model.output.arc.excl65.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP65 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl65 <- summary(model.output.arc.excl65.q2)

# Model for excl65 Q3
model.output.arc.excl65.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP65 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl65 <- summary(model.output.arc.excl65.q3)
cat('Model number 65 processed\n')

# Model for excl66 Q1
model.output.arc.excl66.q1 <- glmer(PA_ARCX_EXCL_TOP66 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl66 <- summary(model.output.arc.excl66.q1)

# Data prep Q2,Q3 for excl66
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 66)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 66), paste0('RELABUN_ARCX_EXCL_TOP', 66), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP66 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 66)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP66 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 66)]))

# Model for excl66 Q2
model.output.arc.excl66.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP66 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl66 <- summary(model.output.arc.excl66.q2)

# Model for excl66 Q3
model.output.arc.excl66.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP66 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl66 <- summary(model.output.arc.excl66.q3)
cat('Model number 66 processed\n')

# Model for excl67 Q1
model.output.arc.excl67.q1 <- glmer(PA_ARCX_EXCL_TOP67 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl67 <- summary(model.output.arc.excl67.q1)

# Data prep Q2,Q3 for excl67
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 67)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 67), paste0('RELABUN_ARCX_EXCL_TOP', 67), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP67 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 67)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP67 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 67)]))

# Model for excl67 Q2
model.output.arc.excl67.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP67 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl67 <- summary(model.output.arc.excl67.q2)

# Model for excl67 Q3
model.output.arc.excl67.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP67 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl67 <- summary(model.output.arc.excl67.q3)
cat('Model number 67 processed\n')

# Model for excl68 Q1
model.output.arc.excl68.q1 <- glmer(PA_ARCX_EXCL_TOP68 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl68 <- summary(model.output.arc.excl68.q1)

# Data prep Q2,Q3 for excl68
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 68)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 68), paste0('RELABUN_ARCX_EXCL_TOP', 68), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP68 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 68)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP68 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 68)]))

# Model for excl68 Q2
model.output.arc.excl68.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP68 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl68 <- summary(model.output.arc.excl68.q2)

# Model for excl68 Q3
model.output.arc.excl68.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP68 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl68 <- summary(model.output.arc.excl68.q3)
cat('Model number 68 processed\n')

# Model for excl69 Q1
model.output.arc.excl69.q1 <- glmer(PA_ARCX_EXCL_TOP69 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl69 <- summary(model.output.arc.excl69.q1)

# Data prep Q2,Q3 for excl69
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 69)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 69), paste0('RELABUN_ARCX_EXCL_TOP', 69), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP69 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 69)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP69 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 69)]))

# Model for excl69 Q2
model.output.arc.excl69.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP69 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl69 <- summary(model.output.arc.excl69.q2)

# Model for excl69 Q3
model.output.arc.excl69.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP69 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl69 <- summary(model.output.arc.excl69.q3)
cat('Model number 69 processed\n')

# Model for excl70 Q1
model.output.arc.excl70.q1 <- glmer(PA_ARCX_EXCL_TOP70 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl70 <- summary(model.output.arc.excl70.q1)

# Data prep Q2,Q3 for excl70
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 70)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 70), paste0('RELABUN_ARCX_EXCL_TOP', 70), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP70 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 70)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP70 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 70)]))

# Model for excl70 Q2
model.output.arc.excl70.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP70 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl70 <- summary(model.output.arc.excl70.q2)

# Model for excl70 Q3
model.output.arc.excl70.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP70 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl70 <- summary(model.output.arc.excl70.q3)
cat('Model number 70 processed\n')

# Model for excl71 Q1
model.output.arc.excl71.q1 <- glmer(PA_ARCX_EXCL_TOP71 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl71 <- summary(model.output.arc.excl71.q1)

# Data prep Q2,Q3 for excl71
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 71)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 71), paste0('RELABUN_ARCX_EXCL_TOP', 71), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP71 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 71)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP71 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 71)]))

# Model for excl71 Q2
model.output.arc.excl71.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP71 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl71 <- summary(model.output.arc.excl71.q2)

# Model for excl71 Q3
model.output.arc.excl71.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP71 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl71 <- summary(model.output.arc.excl71.q3)
cat('Model number 71 processed\n')

# Model for excl72 Q1
model.output.arc.excl72.q1 <- glmer(PA_ARCX_EXCL_TOP72 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl72 <- summary(model.output.arc.excl72.q1)

# Data prep Q2,Q3 for excl72
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 72)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 72), paste0('RELABUN_ARCX_EXCL_TOP', 72), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP72 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 72)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP72 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 72)]))

# Model for excl72 Q2
model.output.arc.excl72.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP72 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl72 <- summary(model.output.arc.excl72.q2)

# Model for excl72 Q3
model.output.arc.excl72.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP72 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl72 <- summary(model.output.arc.excl72.q3)
cat('Model number 72 processed\n')

# Model for excl73 Q1
model.output.arc.excl73.q1 <- glmer(PA_ARCX_EXCL_TOP73 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl73 <- summary(model.output.arc.excl73.q1)

# Data prep Q2,Q3 for excl73
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 73)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 73), paste0('RELABUN_ARCX_EXCL_TOP', 73), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP73 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 73)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP73 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 73)]))

# Model for excl73 Q2
model.output.arc.excl73.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP73 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl73 <- summary(model.output.arc.excl73.q2)

# Model for excl73 Q3
model.output.arc.excl73.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP73 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl73 <- summary(model.output.arc.excl73.q3)
cat('Model number 73 processed\n')

# Model for excl74 Q1
model.output.arc.excl74.q1 <- glmer(PA_ARCX_EXCL_TOP74 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl74 <- summary(model.output.arc.excl74.q1)

# Data prep Q2,Q3 for excl74
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 74)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 74), paste0('RELABUN_ARCX_EXCL_TOP', 74), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP74 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 74)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP74 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 74)]))

# Model for excl74 Q2
model.output.arc.excl74.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP74 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl74 <- summary(model.output.arc.excl74.q2)

# Model for excl74 Q3
model.output.arc.excl74.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP74 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl74 <- summary(model.output.arc.excl74.q3)
cat('Model number 74 processed\n')

# Model for excl75 Q1
model.output.arc.excl75.q1 <- glmer(PA_ARCX_EXCL_TOP75 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl75 <- summary(model.output.arc.excl75.q1)

# Data prep Q2,Q3 for excl75
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 75)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 75), paste0('RELABUN_ARCX_EXCL_TOP', 75), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP75 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 75)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP75 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 75)]))

# Model for excl75 Q2
model.output.arc.excl75.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP75 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl75 <- summary(model.output.arc.excl75.q2)

# Model for excl75 Q3
model.output.arc.excl75.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP75 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl75 <- summary(model.output.arc.excl75.q3)
cat('Model number 75 processed\n')

# Model for excl76 Q1
model.output.arc.excl76.q1 <- glmer(PA_ARCX_EXCL_TOP76 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl76 <- summary(model.output.arc.excl76.q1)

# Data prep Q2,Q3 for excl76
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 76)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 76), paste0('RELABUN_ARCX_EXCL_TOP', 76), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP76 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 76)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP76 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 76)]))

# Model for excl76 Q2
model.output.arc.excl76.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP76 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl76 <- summary(model.output.arc.excl76.q2)

# Model for excl76 Q3
model.output.arc.excl76.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP76 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl76 <- summary(model.output.arc.excl76.q3)
cat('Model number 76 processed\n')

# Model for excl77 Q1
model.output.arc.excl77.q1 <- glmer(PA_ARCX_EXCL_TOP77 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl77 <- summary(model.output.arc.excl77.q1)

# Data prep Q2,Q3 for excl77
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 77)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 77), paste0('RELABUN_ARCX_EXCL_TOP', 77), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP77 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 77)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP77 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 77)]))

# Model for excl77 Q2
model.output.arc.excl77.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP77 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl77 <- summary(model.output.arc.excl77.q2)

# Model for excl77 Q3
model.output.arc.excl77.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP77 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl77 <- summary(model.output.arc.excl77.q3)
cat('Model number 77 processed\n')

# Model for excl78 Q1
model.output.arc.excl78.q1 <- glmer(PA_ARCX_EXCL_TOP78 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl78 <- summary(model.output.arc.excl78.q1)

# Data prep Q2,Q3 for excl78
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 78)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 78), paste0('RELABUN_ARCX_EXCL_TOP', 78), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP78 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 78)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP78 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 78)]))

# Model for excl78 Q2
model.output.arc.excl78.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP78 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl78 <- summary(model.output.arc.excl78.q2)

# Model for excl78 Q3
model.output.arc.excl78.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP78 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl78 <- summary(model.output.arc.excl78.q3)
cat('Model number 78 processed\n')

# Model for excl79 Q1
model.output.arc.excl79.q1 <- glmer(PA_ARCX_EXCL_TOP79 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl79 <- summary(model.output.arc.excl79.q1)

# Data prep Q2,Q3 for excl79
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 79)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 79), paste0('RELABUN_ARCX_EXCL_TOP', 79), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP79 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 79)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP79 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 79)]))

# Model for excl79 Q2
model.output.arc.excl79.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP79 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl79 <- summary(model.output.arc.excl79.q2)

# Model for excl79 Q3
model.output.arc.excl79.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP79 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl79 <- summary(model.output.arc.excl79.q3)
cat('Model number 79 processed\n')

# Model for excl80 Q1
model.output.arc.excl80.q1 <- glmer(PA_ARCX_EXCL_TOP80 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl80 <- summary(model.output.arc.excl80.q1)

# Data prep Q2,Q3 for excl80
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 80)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 80), paste0('RELABUN_ARCX_EXCL_TOP', 80), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP80 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 80)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP80 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 80)]))

# Model for excl80 Q2
model.output.arc.excl80.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP80 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl80 <- summary(model.output.arc.excl80.q2)

# Model for excl80 Q3
model.output.arc.excl80.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP80 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl80 <- summary(model.output.arc.excl80.q3)
cat('Model number 80 processed\n')

# Model for excl81 Q1
model.output.arc.excl81.q1 <- glmer(PA_ARCX_EXCL_TOP81 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl81 <- summary(model.output.arc.excl81.q1)

# Data prep Q2,Q3 for excl81
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 81)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 81), paste0('RELABUN_ARCX_EXCL_TOP', 81), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP81 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 81)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP81 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 81)]))

# Model for excl81 Q2
model.output.arc.excl81.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP81 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl81 <- summary(model.output.arc.excl81.q2)

# Model for excl81 Q3
model.output.arc.excl81.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP81 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl81 <- summary(model.output.arc.excl81.q3)
cat('Model number 81 processed\n')

# Model for excl82 Q1
model.output.arc.excl82.q1 <- glmer(PA_ARCX_EXCL_TOP82 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl82 <- summary(model.output.arc.excl82.q1)

# Data prep Q2,Q3 for excl82
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 82)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 82), paste0('RELABUN_ARCX_EXCL_TOP', 82), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP82 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 82)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP82 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 82)]))

# Model for excl82 Q2
model.output.arc.excl82.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP82 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl82 <- summary(model.output.arc.excl82.q2)

# Model for excl82 Q3
model.output.arc.excl82.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP82 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl82 <- summary(model.output.arc.excl82.q3)
cat('Model number 82 processed\n')

# Model for excl83 Q1
model.output.arc.excl83.q1 <- glmer(PA_ARCX_EXCL_TOP83 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl83 <- summary(model.output.arc.excl83.q1)

# Data prep Q2,Q3 for excl83
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 83)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 83), paste0('RELABUN_ARCX_EXCL_TOP', 83), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP83 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 83)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP83 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 83)]))

# Model for excl83 Q2
model.output.arc.excl83.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP83 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl83 <- summary(model.output.arc.excl83.q2)

# Model for excl83 Q3
model.output.arc.excl83.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP83 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl83 <- summary(model.output.arc.excl83.q3)
cat('Model number 83 processed\n')

# Model for excl84 Q1
model.output.arc.excl84.q1 <- glmer(PA_ARCX_EXCL_TOP84 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl84 <- summary(model.output.arc.excl84.q1)

# Data prep Q2,Q3 for excl84
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 84)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 84), paste0('RELABUN_ARCX_EXCL_TOP', 84), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP84 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 84)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP84 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 84)]))

# Model for excl84 Q2
model.output.arc.excl84.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP84 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl84 <- summary(model.output.arc.excl84.q2)

# Model for excl84 Q3
model.output.arc.excl84.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP84 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl84 <- summary(model.output.arc.excl84.q3)
cat('Model number 84 processed\n')

# Model for excl85 Q1
model.output.arc.excl85.q1 <- glmer(PA_ARCX_EXCL_TOP85 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl85 <- summary(model.output.arc.excl85.q1)

# Data prep Q2,Q3 for excl85
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 85)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 85), paste0('RELABUN_ARCX_EXCL_TOP', 85), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP85 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 85)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP85 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 85)]))

# Model for excl85 Q2
model.output.arc.excl85.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP85 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl85 <- summary(model.output.arc.excl85.q2)

# Model for excl85 Q3
model.output.arc.excl85.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP85 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl85 <- summary(model.output.arc.excl85.q3)
cat('Model number 85 processed\n')

# Model for excl86 Q1
model.output.arc.excl86.q1 <- glmer(PA_ARCX_EXCL_TOP86 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl86 <- summary(model.output.arc.excl86.q1)

# Data prep Q2,Q3 for excl86
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 86)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 86), paste0('RELABUN_ARCX_EXCL_TOP', 86), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP86 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 86)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP86 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 86)]))

# Model for excl86 Q2
model.output.arc.excl86.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP86 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl86 <- summary(model.output.arc.excl86.q2)

# Model for excl86 Q3
model.output.arc.excl86.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP86 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl86 <- summary(model.output.arc.excl86.q3)
cat('Model number 86 processed\n')

# Model for excl87 Q1
model.output.arc.excl87.q1 <- glmer(PA_ARCX_EXCL_TOP87 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl87 <- summary(model.output.arc.excl87.q1)

# Data prep Q2,Q3 for excl87
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 87)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 87), paste0('RELABUN_ARCX_EXCL_TOP', 87), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP87 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 87)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP87 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 87)]))

# Model for excl87 Q2
model.output.arc.excl87.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP87 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl87 <- summary(model.output.arc.excl87.q2)

# Model for excl87 Q3
model.output.arc.excl87.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP87 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl87 <- summary(model.output.arc.excl87.q3)
cat('Model number 87 processed\n')

# Model for excl88 Q1
model.output.arc.excl88.q1 <- glmer(PA_ARCX_EXCL_TOP88 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl88 <- summary(model.output.arc.excl88.q1)

# Data prep Q2,Q3 for excl88
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 88)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 88), paste0('RELABUN_ARCX_EXCL_TOP', 88), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP88 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 88)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP88 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 88)]))

# Model for excl88 Q2
model.output.arc.excl88.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP88 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl88 <- summary(model.output.arc.excl88.q2)

# Model for excl88 Q3
model.output.arc.excl88.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP88 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl88 <- summary(model.output.arc.excl88.q3)
cat('Model number 88 processed\n')

# Model for excl89 Q1
model.output.arc.excl89.q1 <- glmer(PA_ARCX_EXCL_TOP89 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl89 <- summary(model.output.arc.excl89.q1)

# Data prep Q2,Q3 for excl89
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 89)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 89), paste0('RELABUN_ARCX_EXCL_TOP', 89), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP89 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 89)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP89 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 89)]))

# Model for excl89 Q2
model.output.arc.excl89.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP89 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl89 <- summary(model.output.arc.excl89.q2)

# Model for excl89 Q3
model.output.arc.excl89.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP89 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl89 <- summary(model.output.arc.excl89.q3)
cat('Model number 89 processed\n')

# Model for excl90 Q1
model.output.arc.excl90.q1 <- glmer(PA_ARCX_EXCL_TOP90 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl90 <- summary(model.output.arc.excl90.q1)

# Data prep Q2,Q3 for excl90
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 90)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 90), paste0('RELABUN_ARCX_EXCL_TOP', 90), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP90 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 90)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP90 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 90)]))

# Model for excl90 Q2
model.output.arc.excl90.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP90 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl90 <- summary(model.output.arc.excl90.q2)

# Model for excl90 Q3
model.output.arc.excl90.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP90 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl90 <- summary(model.output.arc.excl90.q3)
cat('Model number 90 processed\n')

# Model for excl91 Q1
model.output.arc.excl91.q1 <- glmer(PA_ARCX_EXCL_TOP91 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl91 <- summary(model.output.arc.excl91.q1)

# Data prep Q2,Q3 for excl91
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 91)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 91), paste0('RELABUN_ARCX_EXCL_TOP', 91), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP91 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 91)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP91 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 91)]))

# Model for excl91 Q2
model.output.arc.excl91.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP91 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl91 <- summary(model.output.arc.excl91.q2)

# Model for excl91 Q3
model.output.arc.excl91.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP91 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl91 <- summary(model.output.arc.excl91.q3)
cat('Model number 91 processed\n')

# Model for excl92 Q1
model.output.arc.excl92.q1 <- glmer(PA_ARCX_EXCL_TOP92 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl92 <- summary(model.output.arc.excl92.q1)

# Data prep Q2,Q3 for excl92
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 92)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 92), paste0('RELABUN_ARCX_EXCL_TOP', 92), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP92 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 92)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP92 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 92)]))

# Model for excl92 Q2
model.output.arc.excl92.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP92 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl92 <- summary(model.output.arc.excl92.q2)

# Model for excl92 Q3
model.output.arc.excl92.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP92 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl92 <- summary(model.output.arc.excl92.q3)
cat('Model number 92 processed\n')

# Model for excl93 Q1
model.output.arc.excl93.q1 <- glmer(PA_ARCX_EXCL_TOP93 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl93 <- summary(model.output.arc.excl93.q1)

# Data prep Q2,Q3 for excl93
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 93)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 93), paste0('RELABUN_ARCX_EXCL_TOP', 93), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP93 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 93)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP93 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 93)]))

# Model for excl93 Q2
model.output.arc.excl93.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP93 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl93 <- summary(model.output.arc.excl93.q2)

# Model for excl93 Q3
model.output.arc.excl93.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP93 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl93 <- summary(model.output.arc.excl93.q3)
cat('Model number 93 processed\n')

# Model for excl94 Q1
model.output.arc.excl94.q1 <- glmer(PA_ARCX_EXCL_TOP94 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl94 <- summary(model.output.arc.excl94.q1)

# Data prep Q2,Q3 for excl94
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 94)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 94), paste0('RELABUN_ARCX_EXCL_TOP', 94), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP94 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 94)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP94 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 94)]))

# Model for excl94 Q2
model.output.arc.excl94.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP94 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl94 <- summary(model.output.arc.excl94.q2)

# Model for excl94 Q3
model.output.arc.excl94.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP94 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl94 <- summary(model.output.arc.excl94.q3)
cat('Model number 94 processed\n')

# Model for excl95 Q1
model.output.arc.excl95.q1 <- glmer(PA_ARCX_EXCL_TOP95 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl95 <- summary(model.output.arc.excl95.q1)

# Data prep Q2,Q3 for excl95
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 95)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 95), paste0('RELABUN_ARCX_EXCL_TOP', 95), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP95 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 95)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP95 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 95)]))

# Model for excl95 Q2
model.output.arc.excl95.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP95 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl95 <- summary(model.output.arc.excl95.q2)

# Model for excl95 Q3
model.output.arc.excl95.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP95 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl95 <- summary(model.output.arc.excl95.q3)
cat('Model number 95 processed\n')

# Model for excl96 Q1
model.output.arc.excl96.q1 <- glmer(PA_ARCX_EXCL_TOP96 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl96 <- summary(model.output.arc.excl96.q1)

# Data prep Q2,Q3 for excl96
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 96)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 96), paste0('RELABUN_ARCX_EXCL_TOP', 96), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP96 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 96)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP96 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 96)]))

# Model for excl96 Q2
model.output.arc.excl96.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP96 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl96 <- summary(model.output.arc.excl96.q2)

# Model for excl96 Q3
model.output.arc.excl96.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP96 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl96 <- summary(model.output.arc.excl96.q3)
cat('Model number 96 processed\n')

# Model for excl97 Q1
model.output.arc.excl97.q1 <- glmer(PA_ARCX_EXCL_TOP97 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl97 <- summary(model.output.arc.excl97.q1)

# Data prep Q2,Q3 for excl97
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 97)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 97), paste0('RELABUN_ARCX_EXCL_TOP', 97), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP97 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 97)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP97 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 97)]))

# Model for excl97 Q2
model.output.arc.excl97.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP97 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl97 <- summary(model.output.arc.excl97.q2)

# Model for excl97 Q3
model.output.arc.excl97.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP97 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl97 <- summary(model.output.arc.excl97.q3)
cat('Model number 97 processed\n')

# Model for excl98 Q1
model.output.arc.excl98.q1 <- glmer(PA_ARCX_EXCL_TOP98 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl98 <- summary(model.output.arc.excl98.q1)

# Data prep Q2,Q3 for excl98
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 98)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 98), paste0('RELABUN_ARCX_EXCL_TOP', 98), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP98 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 98)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP98 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 98)]))

# Model for excl98 Q2
model.output.arc.excl98.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP98 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl98 <- summary(model.output.arc.excl98.q2)

# Model for excl98 Q3
model.output.arc.excl98.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP98 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl98 <- summary(model.output.arc.excl98.q3)
cat('Model number 98 processed\n')

# Model for excl99 Q1
model.output.arc.excl99.q1 <- glmer(PA_ARCX_EXCL_TOP99 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl99 <- summary(model.output.arc.excl99.q1)

# Data prep Q2,Q3 for excl99
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 99)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 99), paste0('RELABUN_ARCX_EXCL_TOP', 99), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP99 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 99)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP99 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 99)]))

# Model for excl99 Q2
model.output.arc.excl99.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP99 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl99 <- summary(model.output.arc.excl99.q2)

# Model for excl99 Q3
model.output.arc.excl99.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP99 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl99 <- summary(model.output.arc.excl99.q3)
cat('Model number 99 processed\n')

# Model for excl100 Q1
model.output.arc.excl100.q1 <- glmer(PA_ARCX_EXCL_TOP100 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl100 <- summary(model.output.arc.excl100.q1)

# Data prep Q2,Q3 for excl100
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 100)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 100), paste0('RELABUN_ARCX_EXCL_TOP', 100), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP100 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 100)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP100 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 100)]))

# Model for excl100 Q2
model.output.arc.excl100.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP100 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl100 <- summary(model.output.arc.excl100.q2)

# Model for excl100 Q3
model.output.arc.excl100.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP100 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl100 <- summary(model.output.arc.excl100.q3)
cat('Model number 100 processed\n')

# Model for excl101 Q1
model.output.arc.excl101.q1 <- glmer(PA_ARCX_EXCL_TOP101 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl101 <- summary(model.output.arc.excl101.q1)

# Data prep Q2,Q3 for excl101
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 101)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 101), paste0('RELABUN_ARCX_EXCL_TOP', 101), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP101 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 101)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP101 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 101)]))

# Model for excl101 Q2
model.output.arc.excl101.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP101 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl101 <- summary(model.output.arc.excl101.q2)

# Model for excl101 Q3
model.output.arc.excl101.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP101 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl101 <- summary(model.output.arc.excl101.q3)
cat('Model number 101 processed\n')

# Model for excl102 Q1
model.output.arc.excl102.q1 <- glmer(PA_ARCX_EXCL_TOP102 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl102 <- summary(model.output.arc.excl102.q1)

# Data prep Q2,Q3 for excl102
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 102)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 102), paste0('RELABUN_ARCX_EXCL_TOP', 102), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP102 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 102)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP102 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 102)]))

# Model for excl102 Q2
model.output.arc.excl102.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP102 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl102 <- summary(model.output.arc.excl102.q2)

# Model for excl102 Q3
model.output.arc.excl102.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP102 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl102 <- summary(model.output.arc.excl102.q3)
cat('Model number 102 processed\n')

# Model for excl103 Q1
model.output.arc.excl103.q1 <- glmer(PA_ARCX_EXCL_TOP103 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl103 <- summary(model.output.arc.excl103.q1)

# Data prep Q2,Q3 for excl103
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 103)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 103), paste0('RELABUN_ARCX_EXCL_TOP', 103), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP103 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 103)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP103 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 103)]))

# Model for excl103 Q2
model.output.arc.excl103.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP103 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl103 <- summary(model.output.arc.excl103.q2)

# Model for excl103 Q3
model.output.arc.excl103.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP103 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl103 <- summary(model.output.arc.excl103.q3)
cat('Model number 103 processed\n')

# Model for excl104 Q1
model.output.arc.excl104.q1 <- glmer(PA_ARCX_EXCL_TOP104 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl104 <- summary(model.output.arc.excl104.q1)

# Data prep Q2,Q3 for excl104
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 104)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 104), paste0('RELABUN_ARCX_EXCL_TOP', 104), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP104 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 104)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP104 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 104)]))

# Model for excl104 Q2
model.output.arc.excl104.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP104 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl104 <- summary(model.output.arc.excl104.q2)

# Model for excl104 Q3
model.output.arc.excl104.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP104 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl104 <- summary(model.output.arc.excl104.q3)
cat('Model number 104 processed\n')

# Model for excl105 Q1
model.output.arc.excl105.q1 <- glmer(PA_ARCX_EXCL_TOP105 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl105 <- summary(model.output.arc.excl105.q1)

# Data prep Q2,Q3 for excl105
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 105)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 105), paste0('RELABUN_ARCX_EXCL_TOP', 105), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP105 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 105)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP105 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 105)]))

# Model for excl105 Q2
model.output.arc.excl105.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP105 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl105 <- summary(model.output.arc.excl105.q2)

# Model for excl105 Q3
model.output.arc.excl105.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP105 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl105 <- summary(model.output.arc.excl105.q3)
cat('Model number 105 processed\n')

# Model for excl106 Q1
model.output.arc.excl106.q1 <- glmer(PA_ARCX_EXCL_TOP106 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl106 <- summary(model.output.arc.excl106.q1)

# Data prep Q2,Q3 for excl106
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 106)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 106), paste0('RELABUN_ARCX_EXCL_TOP', 106), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP106 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 106)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP106 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 106)]))

# Model for excl106 Q2
model.output.arc.excl106.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP106 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl106 <- summary(model.output.arc.excl106.q2)

# Model for excl106 Q3
model.output.arc.excl106.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP106 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl106 <- summary(model.output.arc.excl106.q3)
cat('Model number 106 processed\n')

# Model for excl107 Q1
model.output.arc.excl107.q1 <- glmer(PA_ARCX_EXCL_TOP107 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl107 <- summary(model.output.arc.excl107.q1)

# Data prep Q2,Q3 for excl107
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 107)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 107), paste0('RELABUN_ARCX_EXCL_TOP', 107), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP107 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 107)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP107 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 107)]))

# Model for excl107 Q2
model.output.arc.excl107.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP107 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl107 <- summary(model.output.arc.excl107.q2)

# Model for excl107 Q3
model.output.arc.excl107.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP107 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl107 <- summary(model.output.arc.excl107.q3)
cat('Model number 107 processed\n')

# Model for excl108 Q1
model.output.arc.excl108.q1 <- glmer(PA_ARCX_EXCL_TOP108 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl108 <- summary(model.output.arc.excl108.q1)

# Data prep Q2,Q3 for excl108
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 108)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 108), paste0('RELABUN_ARCX_EXCL_TOP', 108), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP108 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 108)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP108 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 108)]))

# Model for excl108 Q2
model.output.arc.excl108.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP108 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl108 <- summary(model.output.arc.excl108.q2)

# Model for excl108 Q3
model.output.arc.excl108.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP108 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl108 <- summary(model.output.arc.excl108.q3)
cat('Model number 108 processed\n')

# Model for excl109 Q1
model.output.arc.excl109.q1 <- glmer(PA_ARCX_EXCL_TOP109 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl109 <- summary(model.output.arc.excl109.q1)

# Data prep Q2,Q3 for excl109
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 109)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 109), paste0('RELABUN_ARCX_EXCL_TOP', 109), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP109 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 109)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP109 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 109)]))

# Model for excl109 Q2
model.output.arc.excl109.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP109 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl109 <- summary(model.output.arc.excl109.q2)

# Model for excl109 Q3
model.output.arc.excl109.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP109 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl109 <- summary(model.output.arc.excl109.q3)
cat('Model number 109 processed\n')

# Model for excl110 Q1
model.output.arc.excl110.q1 <- glmer(PA_ARCX_EXCL_TOP110 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl110 <- summary(model.output.arc.excl110.q1)

# Data prep Q2,Q3 for excl110
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 110)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 110), paste0('RELABUN_ARCX_EXCL_TOP', 110), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP110 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 110)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP110 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 110)]))

# Model for excl110 Q2
model.output.arc.excl110.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP110 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl110 <- summary(model.output.arc.excl110.q2)

# Model for excl110 Q3
model.output.arc.excl110.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP110 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl110 <- summary(model.output.arc.excl110.q3)
cat('Model number 110 processed\n')

# Model for excl111 Q1
model.output.arc.excl111.q1 <- glmer(PA_ARCX_EXCL_TOP111 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl111 <- summary(model.output.arc.excl111.q1)

# Data prep Q2,Q3 for excl111
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 111)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 111), paste0('RELABUN_ARCX_EXCL_TOP', 111), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP111 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 111)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP111 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 111)]))

# Model for excl111 Q2
model.output.arc.excl111.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP111 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl111 <- summary(model.output.arc.excl111.q2)

# Model for excl111 Q3
model.output.arc.excl111.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP111 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl111 <- summary(model.output.arc.excl111.q3)
cat('Model number 111 processed\n')

# Model for excl112 Q1
model.output.arc.excl112.q1 <- glmer(PA_ARCX_EXCL_TOP112 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl112 <- summary(model.output.arc.excl112.q1)

# Data prep Q2,Q3 for excl112
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 112)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 112), paste0('RELABUN_ARCX_EXCL_TOP', 112), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP112 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 112)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP112 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 112)]))

# Model for excl112 Q2
model.output.arc.excl112.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP112 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl112 <- summary(model.output.arc.excl112.q2)

# Model for excl112 Q3
model.output.arc.excl112.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP112 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl112 <- summary(model.output.arc.excl112.q3)
cat('Model number 112 processed\n')

# Model for excl113 Q1
model.output.arc.excl113.q1 <- glmer(PA_ARCX_EXCL_TOP113 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl113 <- summary(model.output.arc.excl113.q1)

# Data prep Q2,Q3 for excl113
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 113)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 113), paste0('RELABUN_ARCX_EXCL_TOP', 113), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP113 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 113)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP113 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 113)]))

# Model for excl113 Q2
model.output.arc.excl113.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP113 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl113 <- summary(model.output.arc.excl113.q2)

# Model for excl113 Q3
model.output.arc.excl113.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP113 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl113 <- summary(model.output.arc.excl113.q3)
cat('Model number 113 processed\n')

# Model for excl114 Q1
model.output.arc.excl114.q1 <- glmer(PA_ARCX_EXCL_TOP114 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl114 <- summary(model.output.arc.excl114.q1)

# Data prep Q2,Q3 for excl114
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 114)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 114), paste0('RELABUN_ARCX_EXCL_TOP', 114), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP114 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 114)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP114 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 114)]))

# Model for excl114 Q2
model.output.arc.excl114.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP114 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl114 <- summary(model.output.arc.excl114.q2)

# Model for excl114 Q3
model.output.arc.excl114.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP114 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl114 <- summary(model.output.arc.excl114.q3)
cat('Model number 114 processed\n')

# Model for excl115 Q1
model.output.arc.excl115.q1 <- glmer(PA_ARCX_EXCL_TOP115 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl115 <- summary(model.output.arc.excl115.q1)

# Data prep Q2,Q3 for excl115
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 115)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 115), paste0('RELABUN_ARCX_EXCL_TOP', 115), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP115 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 115)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP115 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 115)]))

# Model for excl115 Q2
model.output.arc.excl115.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP115 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl115 <- summary(model.output.arc.excl115.q2)

# Model for excl115 Q3
model.output.arc.excl115.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP115 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl115 <- summary(model.output.arc.excl115.q3)
cat('Model number 115 processed\n')

# Model for excl116 Q1
model.output.arc.excl116.q1 <- glmer(PA_ARCX_EXCL_TOP116 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl116 <- summary(model.output.arc.excl116.q1)

# Data prep Q2,Q3 for excl116
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 116)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 116), paste0('RELABUN_ARCX_EXCL_TOP', 116), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP116 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 116)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP116 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 116)]))

# Model for excl116 Q2
model.output.arc.excl116.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP116 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl116 <- summary(model.output.arc.excl116.q2)

# Model for excl116 Q3
model.output.arc.excl116.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP116 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl116 <- summary(model.output.arc.excl116.q3)
cat('Model number 116 processed\n')

# Model for excl117 Q1
model.output.arc.excl117.q1 <- glmer(PA_ARCX_EXCL_TOP117 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl117 <- summary(model.output.arc.excl117.q1)

# Data prep Q2,Q3 for excl117
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 117)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 117), paste0('RELABUN_ARCX_EXCL_TOP', 117), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP117 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 117)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP117 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 117)]))

# Model for excl117 Q2
model.output.arc.excl117.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP117 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl117 <- summary(model.output.arc.excl117.q2)

# Model for excl117 Q3
model.output.arc.excl117.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP117 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl117 <- summary(model.output.arc.excl117.q3)
cat('Model number 117 processed\n')

# Model for excl118 Q1
model.output.arc.excl118.q1 <- glmer(PA_ARCX_EXCL_TOP118 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl118 <- summary(model.output.arc.excl118.q1)

# Data prep Q2,Q3 for excl118
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 118)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 118), paste0('RELABUN_ARCX_EXCL_TOP', 118), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP118 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 118)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP118 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 118)]))

# Model for excl118 Q2
model.output.arc.excl118.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP118 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl118 <- summary(model.output.arc.excl118.q2)

# Model for excl118 Q3
model.output.arc.excl118.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP118 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl118 <- summary(model.output.arc.excl118.q3)
cat('Model number 118 processed\n')

# Model for excl119 Q1
model.output.arc.excl119.q1 <- glmer(PA_ARCX_EXCL_TOP119 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl119 <- summary(model.output.arc.excl119.q1)

# Data prep Q2,Q3 for excl119
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 119)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 119), paste0('RELABUN_ARCX_EXCL_TOP', 119), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP119 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 119)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP119 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 119)]))

# Model for excl119 Q2
model.output.arc.excl119.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP119 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl119 <- summary(model.output.arc.excl119.q2)

# Model for excl119 Q3
model.output.arc.excl119.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP119 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl119 <- summary(model.output.arc.excl119.q3)
cat('Model number 119 processed\n')

# Model for excl120 Q1
model.output.arc.excl120.q1 <- glmer(PA_ARCX_EXCL_TOP120 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl120 <- summary(model.output.arc.excl120.q1)

# Data prep Q2,Q3 for excl120
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 120)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 120), paste0('RELABUN_ARCX_EXCL_TOP', 120), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP120 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 120)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP120 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 120)]))

# Model for excl120 Q2
model.output.arc.excl120.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP120 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl120 <- summary(model.output.arc.excl120.q2)

# Model for excl120 Q3
model.output.arc.excl120.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP120 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl120 <- summary(model.output.arc.excl120.q3)
cat('Model number 120 processed\n')

# Model for excl121 Q1
model.output.arc.excl121.q1 <- glmer(PA_ARCX_EXCL_TOP121 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl121 <- summary(model.output.arc.excl121.q1)

# Data prep Q2,Q3 for excl121
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 121)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 121), paste0('RELABUN_ARCX_EXCL_TOP', 121), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP121 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 121)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP121 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 121)]))

# Model for excl121 Q2
model.output.arc.excl121.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP121 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl121 <- summary(model.output.arc.excl121.q2)

# Model for excl121 Q3
model.output.arc.excl121.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP121 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl121 <- summary(model.output.arc.excl121.q3)
cat('Model number 121 processed\n')

# Model for excl122 Q1
model.output.arc.excl122.q1 <- glmer(PA_ARCX_EXCL_TOP122 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl122 <- summary(model.output.arc.excl122.q1)

# Data prep Q2,Q3 for excl122
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 122)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 122), paste0('RELABUN_ARCX_EXCL_TOP', 122), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP122 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 122)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP122 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 122)]))

# Model for excl122 Q2
model.output.arc.excl122.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP122 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl122 <- summary(model.output.arc.excl122.q2)

# Model for excl122 Q3
model.output.arc.excl122.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP122 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl122 <- summary(model.output.arc.excl122.q3)
cat('Model number 122 processed\n')

# Model for excl123 Q1
model.output.arc.excl123.q1 <- glmer(PA_ARCX_EXCL_TOP123 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl123 <- summary(model.output.arc.excl123.q1)

# Data prep Q2,Q3 for excl123
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 123)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 123), paste0('RELABUN_ARCX_EXCL_TOP', 123), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP123 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 123)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP123 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 123)]))

# Model for excl123 Q2
model.output.arc.excl123.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP123 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl123 <- summary(model.output.arc.excl123.q2)

# Model for excl123 Q3
model.output.arc.excl123.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP123 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl123 <- summary(model.output.arc.excl123.q3)
cat('Model number 123 processed\n')

# Model for excl124 Q1
model.output.arc.excl124.q1 <- glmer(PA_ARCX_EXCL_TOP124 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl124 <- summary(model.output.arc.excl124.q1)

# Data prep Q2,Q3 for excl124
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 124)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 124), paste0('RELABUN_ARCX_EXCL_TOP', 124), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP124 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 124)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP124 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 124)]))

# Model for excl124 Q2
model.output.arc.excl124.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP124 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl124 <- summary(model.output.arc.excl124.q2)

# Model for excl124 Q3
model.output.arc.excl124.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP124 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl124 <- summary(model.output.arc.excl124.q3)
cat('Model number 124 processed\n')

# Model for excl125 Q1
model.output.arc.excl125.q1 <- glmer(PA_ARCX_EXCL_TOP125 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl125 <- summary(model.output.arc.excl125.q1)

# Data prep Q2,Q3 for excl125
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 125)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 125), paste0('RELABUN_ARCX_EXCL_TOP', 125), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP125 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 125)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP125 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 125)]))

# Model for excl125 Q2
model.output.arc.excl125.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP125 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl125 <- summary(model.output.arc.excl125.q2)

# Model for excl125 Q3
model.output.arc.excl125.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP125 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl125 <- summary(model.output.arc.excl125.q3)
cat('Model number 125 processed\n')

# Model for excl126 Q1
model.output.arc.excl126.q1 <- glmer(PA_ARCX_EXCL_TOP126 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl126 <- summary(model.output.arc.excl126.q1)

# Data prep Q2,Q3 for excl126
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 126)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 126), paste0('RELABUN_ARCX_EXCL_TOP', 126), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP126 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 126)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP126 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 126)]))

# Model for excl126 Q2
model.output.arc.excl126.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP126 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl126 <- summary(model.output.arc.excl126.q2)

# Model for excl126 Q3
model.output.arc.excl126.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP126 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl126 <- summary(model.output.arc.excl126.q3)
cat('Model number 126 processed\n')

# Model for excl127 Q1
model.output.arc.excl127.q1 <- glmer(PA_ARCX_EXCL_TOP127 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl127 <- summary(model.output.arc.excl127.q1)

# Data prep Q2,Q3 for excl127
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 127)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 127), paste0('RELABUN_ARCX_EXCL_TOP', 127), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP127 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 127)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP127 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 127)]))

# Model for excl127 Q2
model.output.arc.excl127.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP127 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl127 <- summary(model.output.arc.excl127.q2)

# Model for excl127 Q3
model.output.arc.excl127.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP127 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl127 <- summary(model.output.arc.excl127.q3)
cat('Model number 127 processed\n')

# Model for excl128 Q1
model.output.arc.excl128.q1 <- glmer(PA_ARCX_EXCL_TOP128 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl128 <- summary(model.output.arc.excl128.q1)

# Data prep Q2,Q3 for excl128
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 128)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 128), paste0('RELABUN_ARCX_EXCL_TOP', 128), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP128 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 128)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP128 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 128)]))

# Model for excl128 Q2
model.output.arc.excl128.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP128 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl128 <- summary(model.output.arc.excl128.q2)

# Model for excl128 Q3
model.output.arc.excl128.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP128 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl128 <- summary(model.output.arc.excl128.q3)
cat('Model number 128 processed\n')

# Model for excl129 Q1
model.output.arc.excl129.q1 <- glmer(PA_ARCX_EXCL_TOP129 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl129 <- summary(model.output.arc.excl129.q1)

# Data prep Q2,Q3 for excl129
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 129)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 129), paste0('RELABUN_ARCX_EXCL_TOP', 129), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP129 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 129)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP129 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 129)]))

# Model for excl129 Q2
model.output.arc.excl129.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP129 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl129 <- summary(model.output.arc.excl129.q2)

# Model for excl129 Q3
model.output.arc.excl129.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP129 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl129 <- summary(model.output.arc.excl129.q3)
cat('Model number 129 processed\n')

# Model for excl130 Q1
model.output.arc.excl130.q1 <- glmer(PA_ARCX_EXCL_TOP130 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl130 <- summary(model.output.arc.excl130.q1)

# Data prep Q2,Q3 for excl130
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 130)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 130), paste0('RELABUN_ARCX_EXCL_TOP', 130), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP130 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 130)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP130 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 130)]))

# Model for excl130 Q2
model.output.arc.excl130.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP130 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl130 <- summary(model.output.arc.excl130.q2)

# Model for excl130 Q3
model.output.arc.excl130.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP130 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl130 <- summary(model.output.arc.excl130.q3)
cat('Model number 130 processed\n')

# Model for excl131 Q1
model.output.arc.excl131.q1 <- glmer(PA_ARCX_EXCL_TOP131 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl131 <- summary(model.output.arc.excl131.q1)

# Data prep Q2,Q3 for excl131
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 131)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 131), paste0('RELABUN_ARCX_EXCL_TOP', 131), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP131 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 131)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP131 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 131)]))

# Model for excl131 Q2
model.output.arc.excl131.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP131 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl131 <- summary(model.output.arc.excl131.q2)

# Model for excl131 Q3
model.output.arc.excl131.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP131 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl131 <- summary(model.output.arc.excl131.q3)
cat('Model number 131 processed\n')

# Model for excl132 Q1
model.output.arc.excl132.q1 <- glmer(PA_ARCX_EXCL_TOP132 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl132 <- summary(model.output.arc.excl132.q1)

# Data prep Q2,Q3 for excl132
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 132)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 132), paste0('RELABUN_ARCX_EXCL_TOP', 132), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP132 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 132)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP132 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 132)]))

# Model for excl132 Q2
model.output.arc.excl132.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP132 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl132 <- summary(model.output.arc.excl132.q2)

# Model for excl132 Q3
model.output.arc.excl132.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP132 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl132 <- summary(model.output.arc.excl132.q3)
cat('Model number 132 processed\n')

# Model for excl133 Q1
model.output.arc.excl133.q1 <- glmer(PA_ARCX_EXCL_TOP133 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl133 <- summary(model.output.arc.excl133.q1)

# Data prep Q2,Q3 for excl133
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 133)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 133), paste0('RELABUN_ARCX_EXCL_TOP', 133), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP133 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 133)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP133 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 133)]))

# Model for excl133 Q2
model.output.arc.excl133.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP133 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl133 <- summary(model.output.arc.excl133.q2)

# Model for excl133 Q3
model.output.arc.excl133.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP133 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl133 <- summary(model.output.arc.excl133.q3)
cat('Model number 133 processed\n')

# Model for excl134 Q1
model.output.arc.excl134.q1 <- glmer(PA_ARCX_EXCL_TOP134 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl134 <- summary(model.output.arc.excl134.q1)

# Data prep Q2,Q3 for excl134
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 134)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 134), paste0('RELABUN_ARCX_EXCL_TOP', 134), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP134 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 134)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP134 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 134)]))

# Model for excl134 Q2
model.output.arc.excl134.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP134 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl134 <- summary(model.output.arc.excl134.q2)

# Model for excl134 Q3
model.output.arc.excl134.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP134 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl134 <- summary(model.output.arc.excl134.q3)
cat('Model number 134 processed\n')

# Model for excl135 Q1
model.output.arc.excl135.q1 <- glmer(PA_ARCX_EXCL_TOP135 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl135 <- summary(model.output.arc.excl135.q1)

# Data prep Q2,Q3 for excl135
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 135)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 135), paste0('RELABUN_ARCX_EXCL_TOP', 135), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP135 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 135)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP135 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 135)]))

# Model for excl135 Q2
model.output.arc.excl135.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP135 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl135 <- summary(model.output.arc.excl135.q2)

# Model for excl135 Q3
model.output.arc.excl135.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP135 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl135 <- summary(model.output.arc.excl135.q3)
cat('Model number 135 processed\n')

# Model for excl136 Q1
model.output.arc.excl136.q1 <- glmer(PA_ARCX_EXCL_TOP136 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl136 <- summary(model.output.arc.excl136.q1)

# Data prep Q2,Q3 for excl136
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 136)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 136), paste0('RELABUN_ARCX_EXCL_TOP', 136), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP136 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 136)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP136 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 136)]))

# Model for excl136 Q2
model.output.arc.excl136.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP136 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl136 <- summary(model.output.arc.excl136.q2)

# Model for excl136 Q3
model.output.arc.excl136.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP136 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl136 <- summary(model.output.arc.excl136.q3)
cat('Model number 136 processed\n')

# Model for excl137 Q1
model.output.arc.excl137.q1 <- glmer(PA_ARCX_EXCL_TOP137 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl137 <- summary(model.output.arc.excl137.q1)

# Data prep Q2,Q3 for excl137
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 137)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 137), paste0('RELABUN_ARCX_EXCL_TOP', 137), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP137 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 137)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP137 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 137)]))

# Model for excl137 Q2
model.output.arc.excl137.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP137 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl137 <- summary(model.output.arc.excl137.q2)

# Model for excl137 Q3
model.output.arc.excl137.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP137 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl137 <- summary(model.output.arc.excl137.q3)
cat('Model number 137 processed\n')

# Model for excl138 Q1
model.output.arc.excl138.q1 <- glmer(PA_ARCX_EXCL_TOP138 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl138 <- summary(model.output.arc.excl138.q1)

# Data prep Q2,Q3 for excl138
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 138)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 138), paste0('RELABUN_ARCX_EXCL_TOP', 138), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP138 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 138)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP138 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 138)]))

# Model for excl138 Q2
model.output.arc.excl138.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP138 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl138 <- summary(model.output.arc.excl138.q2)

# Model for excl138 Q3
model.output.arc.excl138.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP138 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl138 <- summary(model.output.arc.excl138.q3)
cat('Model number 138 processed\n')

# Model for excl139 Q1
model.output.arc.excl139.q1 <- glmer(PA_ARCX_EXCL_TOP139 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl139 <- summary(model.output.arc.excl139.q1)

# Data prep Q2,Q3 for excl139
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 139)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 139), paste0('RELABUN_ARCX_EXCL_TOP', 139), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP139 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 139)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP139 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 139)]))

# Model for excl139 Q2
model.output.arc.excl139.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP139 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl139 <- summary(model.output.arc.excl139.q2)

# Model for excl139 Q3
model.output.arc.excl139.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP139 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl139 <- summary(model.output.arc.excl139.q3)
cat('Model number 139 processed\n')

# Model for excl140 Q1
model.output.arc.excl140.q1 <- glmer(PA_ARCX_EXCL_TOP140 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl140 <- summary(model.output.arc.excl140.q1)

# Data prep Q2,Q3 for excl140
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 140)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 140), paste0('RELABUN_ARCX_EXCL_TOP', 140), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP140 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 140)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP140 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 140)]))

# Model for excl140 Q2
model.output.arc.excl140.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP140 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl140 <- summary(model.output.arc.excl140.q2)

# Model for excl140 Q3
model.output.arc.excl140.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP140 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl140 <- summary(model.output.arc.excl140.q3)
cat('Model number 140 processed\n')

# Model for excl141 Q1
model.output.arc.excl141.q1 <- glmer(PA_ARCX_EXCL_TOP141 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl141 <- summary(model.output.arc.excl141.q1)

# Data prep Q2,Q3 for excl141
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 141)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 141), paste0('RELABUN_ARCX_EXCL_TOP', 141), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP141 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 141)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP141 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 141)]))

# Model for excl141 Q2
model.output.arc.excl141.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP141 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl141 <- summary(model.output.arc.excl141.q2)

# Model for excl141 Q3
model.output.arc.excl141.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP141 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl141 <- summary(model.output.arc.excl141.q3)
cat('Model number 141 processed\n')

# Model for excl142 Q1
model.output.arc.excl142.q1 <- glmer(PA_ARCX_EXCL_TOP142 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl142 <- summary(model.output.arc.excl142.q1)

# Data prep Q2,Q3 for excl142
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 142)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 142), paste0('RELABUN_ARCX_EXCL_TOP', 142), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP142 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 142)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP142 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 142)]))

# Model for excl142 Q2
model.output.arc.excl142.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP142 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl142 <- summary(model.output.arc.excl142.q2)

# Model for excl142 Q3
model.output.arc.excl142.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP142 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl142 <- summary(model.output.arc.excl142.q3)
cat('Model number 142 processed\n')

# Model for excl143 Q1
model.output.arc.excl143.q1 <- glmer(PA_ARCX_EXCL_TOP143 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl143 <- summary(model.output.arc.excl143.q1)

# Data prep Q2,Q3 for excl143
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 143)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 143), paste0('RELABUN_ARCX_EXCL_TOP', 143), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP143 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 143)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP143 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 143)]))

# Model for excl143 Q2
model.output.arc.excl143.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP143 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl143 <- summary(model.output.arc.excl143.q2)

# Model for excl143 Q3
model.output.arc.excl143.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP143 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl143 <- summary(model.output.arc.excl143.q3)
cat('Model number 143 processed\n')

# Model for excl144 Q1
model.output.arc.excl144.q1 <- glmer(PA_ARCX_EXCL_TOP144 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl144 <- summary(model.output.arc.excl144.q1)

# Data prep Q2,Q3 for excl144
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 144)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 144), paste0('RELABUN_ARCX_EXCL_TOP', 144), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP144 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 144)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP144 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 144)]))

# Model for excl144 Q2
model.output.arc.excl144.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP144 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl144 <- summary(model.output.arc.excl144.q2)

# Model for excl144 Q3
model.output.arc.excl144.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP144 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl144 <- summary(model.output.arc.excl144.q3)
cat('Model number 144 processed\n')

# Model for excl145 Q1
model.output.arc.excl145.q1 <- glmer(PA_ARCX_EXCL_TOP145 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl145 <- summary(model.output.arc.excl145.q1)

# Data prep Q2,Q3 for excl145
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 145)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 145), paste0('RELABUN_ARCX_EXCL_TOP', 145), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP145 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 145)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP145 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 145)]))

# Model for excl145 Q2
model.output.arc.excl145.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP145 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl145 <- summary(model.output.arc.excl145.q2)

# Model for excl145 Q3
model.output.arc.excl145.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP145 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl145 <- summary(model.output.arc.excl145.q3)
cat('Model number 145 processed\n')

# Model for excl146 Q1
model.output.arc.excl146.q1 <- glmer(PA_ARCX_EXCL_TOP146 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl146 <- summary(model.output.arc.excl146.q1)

# Data prep Q2,Q3 for excl146
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 146)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 146), paste0('RELABUN_ARCX_EXCL_TOP', 146), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP146 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 146)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP146 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 146)]))

# Model for excl146 Q2
model.output.arc.excl146.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP146 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl146 <- summary(model.output.arc.excl146.q2)

# Model for excl146 Q3
model.output.arc.excl146.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP146 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl146 <- summary(model.output.arc.excl146.q3)
cat('Model number 146 processed\n')

# Model for excl147 Q1
model.output.arc.excl147.q1 <- glmer(PA_ARCX_EXCL_TOP147 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl147 <- summary(model.output.arc.excl147.q1)

# Data prep Q2,Q3 for excl147
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 147)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 147), paste0('RELABUN_ARCX_EXCL_TOP', 147), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP147 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 147)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP147 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 147)]))

# Model for excl147 Q2
model.output.arc.excl147.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP147 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl147 <- summary(model.output.arc.excl147.q2)

# Model for excl147 Q3
model.output.arc.excl147.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP147 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl147 <- summary(model.output.arc.excl147.q3)
cat('Model number 147 processed\n')

# Model for excl148 Q1
model.output.arc.excl148.q1 <- glmer(PA_ARCX_EXCL_TOP148 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl148 <- summary(model.output.arc.excl148.q1)

# Data prep Q2,Q3 for excl148
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 148)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 148), paste0('RELABUN_ARCX_EXCL_TOP', 148), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP148 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 148)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP148 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 148)]))

# Model for excl148 Q2
model.output.arc.excl148.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP148 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl148 <- summary(model.output.arc.excl148.q2)

# Model for excl148 Q3
model.output.arc.excl148.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP148 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl148 <- summary(model.output.arc.excl148.q3)
cat('Model number 148 processed\n')

# Model for excl149 Q1
model.output.arc.excl149.q1 <- glmer(PA_ARCX_EXCL_TOP149 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl149 <- summary(model.output.arc.excl149.q1)

# Data prep Q2,Q3 for excl149
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 149)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 149), paste0('RELABUN_ARCX_EXCL_TOP', 149), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP149 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 149)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP149 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 149)]))

# Model for excl149 Q2
model.output.arc.excl149.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP149 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl149 <- summary(model.output.arc.excl149.q2)

# Model for excl149 Q3
model.output.arc.excl149.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP149 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl149 <- summary(model.output.arc.excl149.q3)
cat('Model number 149 processed\n')

# Model for excl150 Q1
model.output.arc.excl150.q1 <- glmer(PA_ARCX_EXCL_TOP150 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl150 <- summary(model.output.arc.excl150.q1)

# Data prep Q2,Q3 for excl150
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 150)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 150), paste0('RELABUN_ARCX_EXCL_TOP', 150), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP150 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 150)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP150 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 150)]))

# Model for excl150 Q2
model.output.arc.excl150.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP150 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl150 <- summary(model.output.arc.excl150.q2)

# Model for excl150 Q3
model.output.arc.excl150.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP150 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl150 <- summary(model.output.arc.excl150.q3)
cat('Model number 150 processed\n')

# Model for excl151 Q1
model.output.arc.excl151.q1 <- glmer(PA_ARCX_EXCL_TOP151 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl151 <- summary(model.output.arc.excl151.q1)

# Data prep Q2,Q3 for excl151
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 151)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 151), paste0('RELABUN_ARCX_EXCL_TOP', 151), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP151 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 151)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP151 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 151)]))

# Model for excl151 Q2
model.output.arc.excl151.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP151 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl151 <- summary(model.output.arc.excl151.q2)

# Model for excl151 Q3
model.output.arc.excl151.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP151 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl151 <- summary(model.output.arc.excl151.q3)
cat('Model number 151 processed\n')

# Model for excl152 Q1
model.output.arc.excl152.q1 <- glmer(PA_ARCX_EXCL_TOP152 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl152 <- summary(model.output.arc.excl152.q1)

# Data prep Q2,Q3 for excl152
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 152)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 152), paste0('RELABUN_ARCX_EXCL_TOP', 152), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP152 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 152)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP152 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 152)]))

# Model for excl152 Q2
model.output.arc.excl152.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP152 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl152 <- summary(model.output.arc.excl152.q2)

# Model for excl152 Q3
model.output.arc.excl152.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP152 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl152 <- summary(model.output.arc.excl152.q3)
cat('Model number 152 processed\n')

# Model for excl153 Q1
model.output.arc.excl153.q1 <- glmer(PA_ARCX_EXCL_TOP153 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl153 <- summary(model.output.arc.excl153.q1)

# Data prep Q2,Q3 for excl153
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 153)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 153), paste0('RELABUN_ARCX_EXCL_TOP', 153), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP153 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 153)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP153 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 153)]))

# Model for excl153 Q2
model.output.arc.excl153.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP153 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl153 <- summary(model.output.arc.excl153.q2)

# Model for excl153 Q3
model.output.arc.excl153.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP153 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl153 <- summary(model.output.arc.excl153.q3)
cat('Model number 153 processed\n')

# Model for excl154 Q1
model.output.arc.excl154.q1 <- glmer(PA_ARCX_EXCL_TOP154 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl154 <- summary(model.output.arc.excl154.q1)

# Data prep Q2,Q3 for excl154
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 154)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 154), paste0('RELABUN_ARCX_EXCL_TOP', 154), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP154 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 154)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP154 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 154)]))

# Model for excl154 Q2
model.output.arc.excl154.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP154 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl154 <- summary(model.output.arc.excl154.q2)

# Model for excl154 Q3
model.output.arc.excl154.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP154 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl154 <- summary(model.output.arc.excl154.q3)
cat('Model number 154 processed\n')

# Model for excl155 Q1
model.output.arc.excl155.q1 <- glmer(PA_ARCX_EXCL_TOP155 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl155 <- summary(model.output.arc.excl155.q1)

# Data prep Q2,Q3 for excl155
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 155)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 155), paste0('RELABUN_ARCX_EXCL_TOP', 155), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP155 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 155)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP155 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 155)]))

# Model for excl155 Q2
model.output.arc.excl155.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP155 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl155 <- summary(model.output.arc.excl155.q2)

# Model for excl155 Q3
model.output.arc.excl155.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP155 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl155 <- summary(model.output.arc.excl155.q3)
cat('Model number 155 processed\n')

# Model for excl156 Q1
model.output.arc.excl156.q1 <- glmer(PA_ARCX_EXCL_TOP156 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl156 <- summary(model.output.arc.excl156.q1)

# Data prep Q2,Q3 for excl156
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 156)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 156), paste0('RELABUN_ARCX_EXCL_TOP', 156), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP156 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 156)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP156 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 156)]))

# Model for excl156 Q2
model.output.arc.excl156.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP156 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl156 <- summary(model.output.arc.excl156.q2)

# Model for excl156 Q3
model.output.arc.excl156.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP156 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl156 <- summary(model.output.arc.excl156.q3)
cat('Model number 156 processed\n')

# Model for excl157 Q1
model.output.arc.excl157.q1 <- glmer(PA_ARCX_EXCL_TOP157 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl157 <- summary(model.output.arc.excl157.q1)

# Data prep Q2,Q3 for excl157
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 157)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 157), paste0('RELABUN_ARCX_EXCL_TOP', 157), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP157 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 157)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP157 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 157)]))

# Model for excl157 Q2
model.output.arc.excl157.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP157 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl157 <- summary(model.output.arc.excl157.q2)

# Model for excl157 Q3
model.output.arc.excl157.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP157 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl157 <- summary(model.output.arc.excl157.q3)
cat('Model number 157 processed\n')

# Model for excl158 Q1
model.output.arc.excl158.q1 <- glmer(PA_ARCX_EXCL_TOP158 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl158 <- summary(model.output.arc.excl158.q1)

# Data prep Q2,Q3 for excl158
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 158)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 158), paste0('RELABUN_ARCX_EXCL_TOP', 158), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP158 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 158)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP158 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 158)]))

# Model for excl158 Q2
model.output.arc.excl158.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP158 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl158 <- summary(model.output.arc.excl158.q2)

# Model for excl158 Q3
model.output.arc.excl158.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP158 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl158 <- summary(model.output.arc.excl158.q3)
cat('Model number 158 processed\n')

# Model for excl159 Q1
model.output.arc.excl159.q1 <- glmer(PA_ARCX_EXCL_TOP159 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl159 <- summary(model.output.arc.excl159.q1)

# Data prep Q2,Q3 for excl159
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 159)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 159), paste0('RELABUN_ARCX_EXCL_TOP', 159), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP159 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 159)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP159 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 159)]))

# Model for excl159 Q2
model.output.arc.excl159.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP159 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl159 <- summary(model.output.arc.excl159.q2)

# Model for excl159 Q3
model.output.arc.excl159.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP159 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl159 <- summary(model.output.arc.excl159.q3)
cat('Model number 159 processed\n')

# Model for excl160 Q1
model.output.arc.excl160.q1 <- glmer(PA_ARCX_EXCL_TOP160 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl160 <- summary(model.output.arc.excl160.q1)

# Data prep Q2,Q3 for excl160
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 160)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 160), paste0('RELABUN_ARCX_EXCL_TOP', 160), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP160 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 160)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP160 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 160)]))

# Model for excl160 Q2
model.output.arc.excl160.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP160 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl160 <- summary(model.output.arc.excl160.q2)

# Model for excl160 Q3
model.output.arc.excl160.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP160 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl160 <- summary(model.output.arc.excl160.q3)
cat('Model number 160 processed\n')

# Model for excl161 Q1
model.output.arc.excl161.q1 <- glmer(PA_ARCX_EXCL_TOP161 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl161 <- summary(model.output.arc.excl161.q1)

# Data prep Q2,Q3 for excl161
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 161)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 161), paste0('RELABUN_ARCX_EXCL_TOP', 161), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP161 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 161)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP161 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 161)]))

# Model for excl161 Q2
model.output.arc.excl161.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP161 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl161 <- summary(model.output.arc.excl161.q2)

# Model for excl161 Q3
model.output.arc.excl161.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP161 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl161 <- summary(model.output.arc.excl161.q3)
cat('Model number 161 processed\n')

# Model for excl162 Q1
model.output.arc.excl162.q1 <- glmer(PA_ARCX_EXCL_TOP162 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl162 <- summary(model.output.arc.excl162.q1)

# Data prep Q2,Q3 for excl162
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 162)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 162), paste0('RELABUN_ARCX_EXCL_TOP', 162), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP162 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 162)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP162 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 162)]))

# Model for excl162 Q2
model.output.arc.excl162.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP162 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl162 <- summary(model.output.arc.excl162.q2)

# Model for excl162 Q3
model.output.arc.excl162.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP162 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl162 <- summary(model.output.arc.excl162.q3)
cat('Model number 162 processed\n')

# Model for excl163 Q1
model.output.arc.excl163.q1 <- glmer(PA_ARCX_EXCL_TOP163 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl163 <- summary(model.output.arc.excl163.q1)

# Data prep Q2,Q3 for excl163
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 163)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 163), paste0('RELABUN_ARCX_EXCL_TOP', 163), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP163 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 163)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP163 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 163)]))

# Model for excl163 Q2
model.output.arc.excl163.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP163 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl163 <- summary(model.output.arc.excl163.q2)

# Model for excl163 Q3
model.output.arc.excl163.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP163 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl163 <- summary(model.output.arc.excl163.q3)
cat('Model number 163 processed\n')

# Model for excl164 Q1
model.output.arc.excl164.q1 <- glmer(PA_ARCX_EXCL_TOP164 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl164 <- summary(model.output.arc.excl164.q1)

# Data prep Q2,Q3 for excl164
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 164)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 164), paste0('RELABUN_ARCX_EXCL_TOP', 164), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP164 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 164)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP164 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 164)]))

# Model for excl164 Q2
model.output.arc.excl164.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP164 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl164 <- summary(model.output.arc.excl164.q2)

# Model for excl164 Q3
model.output.arc.excl164.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP164 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl164 <- summary(model.output.arc.excl164.q3)
cat('Model number 164 processed\n')

# Model for excl165 Q1
model.output.arc.excl165.q1 <- glmer(PA_ARCX_EXCL_TOP165 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl165 <- summary(model.output.arc.excl165.q1)

# Data prep Q2,Q3 for excl165
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 165)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 165), paste0('RELABUN_ARCX_EXCL_TOP', 165), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP165 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 165)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP165 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 165)]))

# Model for excl165 Q2
model.output.arc.excl165.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP165 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl165 <- summary(model.output.arc.excl165.q2)

# Model for excl165 Q3
model.output.arc.excl165.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP165 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl165 <- summary(model.output.arc.excl165.q3)
cat('Model number 165 processed\n')

# Model for excl166 Q1
model.output.arc.excl166.q1 <- glmer(PA_ARCX_EXCL_TOP166 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl166 <- summary(model.output.arc.excl166.q1)

# Data prep Q2,Q3 for excl166
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 166)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 166), paste0('RELABUN_ARCX_EXCL_TOP', 166), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP166 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 166)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP166 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 166)]))

# Model for excl166 Q2
model.output.arc.excl166.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP166 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl166 <- summary(model.output.arc.excl166.q2)

# Model for excl166 Q3
model.output.arc.excl166.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP166 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl166 <- summary(model.output.arc.excl166.q3)
cat('Model number 166 processed\n')

# Model for excl167 Q1
model.output.arc.excl167.q1 <- glmer(PA_ARCX_EXCL_TOP167 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl167 <- summary(model.output.arc.excl167.q1)

# Data prep Q2,Q3 for excl167
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 167)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 167), paste0('RELABUN_ARCX_EXCL_TOP', 167), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP167 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 167)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP167 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 167)]))

# Model for excl167 Q2
model.output.arc.excl167.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP167 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl167 <- summary(model.output.arc.excl167.q2)

# Model for excl167 Q3
model.output.arc.excl167.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP167 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl167 <- summary(model.output.arc.excl167.q3)
cat('Model number 167 processed\n')

# Model for excl168 Q1
model.output.arc.excl168.q1 <- glmer(PA_ARCX_EXCL_TOP168 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl168 <- summary(model.output.arc.excl168.q1)

# Data prep Q2,Q3 for excl168
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 168)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 168), paste0('RELABUN_ARCX_EXCL_TOP', 168), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP168 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 168)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP168 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 168)]))

# Model for excl168 Q2
model.output.arc.excl168.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP168 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl168 <- summary(model.output.arc.excl168.q2)

# Model for excl168 Q3
model.output.arc.excl168.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP168 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl168 <- summary(model.output.arc.excl168.q3)
cat('Model number 168 processed\n')

# Model for excl169 Q1
model.output.arc.excl169.q1 <- glmer(PA_ARCX_EXCL_TOP169 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl169 <- summary(model.output.arc.excl169.q1)

# Data prep Q2,Q3 for excl169
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 169)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 169), paste0('RELABUN_ARCX_EXCL_TOP', 169), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP169 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 169)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP169 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 169)]))

# Model for excl169 Q2
model.output.arc.excl169.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP169 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl169 <- summary(model.output.arc.excl169.q2)

# Model for excl169 Q3
model.output.arc.excl169.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP169 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl169 <- summary(model.output.arc.excl169.q3)
cat('Model number 169 processed\n')

# Model for excl170 Q1
model.output.arc.excl170.q1 <- glmer(PA_ARCX_EXCL_TOP170 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl170 <- summary(model.output.arc.excl170.q1)

# Data prep Q2,Q3 for excl170
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 170)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 170), paste0('RELABUN_ARCX_EXCL_TOP', 170), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP170 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 170)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP170 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 170)]))

# Model for excl170 Q2
model.output.arc.excl170.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP170 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl170 <- summary(model.output.arc.excl170.q2)

# Model for excl170 Q3
model.output.arc.excl170.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP170 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl170 <- summary(model.output.arc.excl170.q3)
cat('Model number 170 processed\n')

# Model for excl171 Q1
model.output.arc.excl171.q1 <- glmer(PA_ARCX_EXCL_TOP171 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl171 <- summary(model.output.arc.excl171.q1)

# Data prep Q2,Q3 for excl171
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 171)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 171), paste0('RELABUN_ARCX_EXCL_TOP', 171), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP171 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 171)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP171 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 171)]))

# Model for excl171 Q2
model.output.arc.excl171.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP171 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl171 <- summary(model.output.arc.excl171.q2)

# Model for excl171 Q3
model.output.arc.excl171.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP171 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl171 <- summary(model.output.arc.excl171.q3)
cat('Model number 171 processed\n')

# Model for excl172 Q1
model.output.arc.excl172.q1 <- glmer(PA_ARCX_EXCL_TOP172 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl172 <- summary(model.output.arc.excl172.q1)

# Data prep Q2,Q3 for excl172
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 172)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 172), paste0('RELABUN_ARCX_EXCL_TOP', 172), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP172 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 172)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP172 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 172)]))

# Model for excl172 Q2
model.output.arc.excl172.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP172 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl172 <- summary(model.output.arc.excl172.q2)

# Model for excl172 Q3
model.output.arc.excl172.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP172 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl172 <- summary(model.output.arc.excl172.q3)
cat('Model number 172 processed\n')

# Model for excl173 Q1
model.output.arc.excl173.q1 <- glmer(PA_ARCX_EXCL_TOP173 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl173 <- summary(model.output.arc.excl173.q1)

# Data prep Q2,Q3 for excl173
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 173)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 173), paste0('RELABUN_ARCX_EXCL_TOP', 173), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP173 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 173)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP173 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 173)]))

# Model for excl173 Q2
model.output.arc.excl173.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP173 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl173 <- summary(model.output.arc.excl173.q2)

# Model for excl173 Q3
model.output.arc.excl173.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP173 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl173 <- summary(model.output.arc.excl173.q3)
cat('Model number 173 processed\n')

# Model for excl174 Q1
model.output.arc.excl174.q1 <- glmer(PA_ARCX_EXCL_TOP174 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl174 <- summary(model.output.arc.excl174.q1)

# Data prep Q2,Q3 for excl174
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 174)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 174), paste0('RELABUN_ARCX_EXCL_TOP', 174), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP174 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 174)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP174 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 174)]))

# Model for excl174 Q2
model.output.arc.excl174.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP174 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl174 <- summary(model.output.arc.excl174.q2)

# Model for excl174 Q3
model.output.arc.excl174.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP174 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl174 <- summary(model.output.arc.excl174.q3)
cat('Model number 174 processed\n')

# Model for excl175 Q1
model.output.arc.excl175.q1 <- glmer(PA_ARCX_EXCL_TOP175 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl175 <- summary(model.output.arc.excl175.q1)

# Data prep Q2,Q3 for excl175
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 175)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 175), paste0('RELABUN_ARCX_EXCL_TOP', 175), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP175 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 175)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP175 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 175)]))

# Model for excl175 Q2
model.output.arc.excl175.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP175 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl175 <- summary(model.output.arc.excl175.q2)

# Model for excl175 Q3
model.output.arc.excl175.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP175 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl175 <- summary(model.output.arc.excl175.q3)
cat('Model number 175 processed\n')

# Model for excl176 Q1
model.output.arc.excl176.q1 <- glmer(PA_ARCX_EXCL_TOP176 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl176 <- summary(model.output.arc.excl176.q1)

# Data prep Q2,Q3 for excl176
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 176)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 176), paste0('RELABUN_ARCX_EXCL_TOP', 176), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP176 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 176)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP176 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 176)]))

# Model for excl176 Q2
model.output.arc.excl176.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP176 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl176 <- summary(model.output.arc.excl176.q2)

# Model for excl176 Q3
model.output.arc.excl176.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP176 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl176 <- summary(model.output.arc.excl176.q3)
cat('Model number 176 processed\n')

# Model for excl177 Q1
model.output.arc.excl177.q1 <- glmer(PA_ARCX_EXCL_TOP177 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl177 <- summary(model.output.arc.excl177.q1)

# Data prep Q2,Q3 for excl177
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 177)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 177), paste0('RELABUN_ARCX_EXCL_TOP', 177), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP177 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 177)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP177 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 177)]))

# Model for excl177 Q2
model.output.arc.excl177.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP177 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl177 <- summary(model.output.arc.excl177.q2)

# Model for excl177 Q3
model.output.arc.excl177.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP177 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl177 <- summary(model.output.arc.excl177.q3)
cat('Model number 177 processed\n')

# Model for excl178 Q1
model.output.arc.excl178.q1 <- glmer(PA_ARCX_EXCL_TOP178 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl178 <- summary(model.output.arc.excl178.q1)

# Data prep Q2,Q3 for excl178
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 178)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 178), paste0('RELABUN_ARCX_EXCL_TOP', 178), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP178 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 178)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP178 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 178)]))

# Model for excl178 Q2
model.output.arc.excl178.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP178 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl178 <- summary(model.output.arc.excl178.q2)

# Model for excl178 Q3
model.output.arc.excl178.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP178 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl178 <- summary(model.output.arc.excl178.q3)
cat('Model number 178 processed\n')

# Model for excl179 Q1
model.output.arc.excl179.q1 <- glmer(PA_ARCX_EXCL_TOP179 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl179 <- summary(model.output.arc.excl179.q1)

# Data prep Q2,Q3 for excl179
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 179)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 179), paste0('RELABUN_ARCX_EXCL_TOP', 179), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP179 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 179)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP179 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 179)]))

# Model for excl179 Q2
model.output.arc.excl179.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP179 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl179 <- summary(model.output.arc.excl179.q2)

# Model for excl179 Q3
model.output.arc.excl179.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP179 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl179 <- summary(model.output.arc.excl179.q3)
cat('Model number 179 processed\n')

# Model for excl180 Q1
model.output.arc.excl180.q1 <- glmer(PA_ARCX_EXCL_TOP180 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl180 <- summary(model.output.arc.excl180.q1)

# Data prep Q2,Q3 for excl180
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 180)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 180), paste0('RELABUN_ARCX_EXCL_TOP', 180), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP180 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 180)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP180 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 180)]))

# Model for excl180 Q2
model.output.arc.excl180.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP180 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl180 <- summary(model.output.arc.excl180.q2)

# Model for excl180 Q3
model.output.arc.excl180.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP180 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl180 <- summary(model.output.arc.excl180.q3)
cat('Model number 180 processed\n')

# Model for excl181 Q1
model.output.arc.excl181.q1 <- glmer(PA_ARCX_EXCL_TOP181 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl181 <- summary(model.output.arc.excl181.q1)

# Data prep Q2,Q3 for excl181
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 181)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 181), paste0('RELABUN_ARCX_EXCL_TOP', 181), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP181 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 181)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP181 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 181)]))

# Model for excl181 Q2
model.output.arc.excl181.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP181 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl181 <- summary(model.output.arc.excl181.q2)

# Model for excl181 Q3
model.output.arc.excl181.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP181 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl181 <- summary(model.output.arc.excl181.q3)
cat('Model number 181 processed\n')

# Model for excl182 Q1
model.output.arc.excl182.q1 <- glmer(PA_ARCX_EXCL_TOP182 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl182 <- summary(model.output.arc.excl182.q1)

# Data prep Q2,Q3 for excl182
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 182)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 182), paste0('RELABUN_ARCX_EXCL_TOP', 182), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP182 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 182)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP182 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 182)]))

# Model for excl182 Q2
model.output.arc.excl182.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP182 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl182 <- summary(model.output.arc.excl182.q2)

# Model for excl182 Q3
model.output.arc.excl182.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP182 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl182 <- summary(model.output.arc.excl182.q3)
cat('Model number 182 processed\n')

# Model for excl183 Q1
model.output.arc.excl183.q1 <- glmer(PA_ARCX_EXCL_TOP183 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl183 <- summary(model.output.arc.excl183.q1)

# Data prep Q2,Q3 for excl183
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 183)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 183), paste0('RELABUN_ARCX_EXCL_TOP', 183), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP183 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 183)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP183 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 183)]))

# Model for excl183 Q2
model.output.arc.excl183.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP183 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl183 <- summary(model.output.arc.excl183.q2)

# Model for excl183 Q3
model.output.arc.excl183.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP183 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl183 <- summary(model.output.arc.excl183.q3)
cat('Model number 183 processed\n')

# Model for excl184 Q1
model.output.arc.excl184.q1 <- glmer(PA_ARCX_EXCL_TOP184 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl184 <- summary(model.output.arc.excl184.q1)

# Data prep Q2,Q3 for excl184
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 184)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 184), paste0('RELABUN_ARCX_EXCL_TOP', 184), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP184 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 184)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP184 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 184)]))

# Model for excl184 Q2
model.output.arc.excl184.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP184 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl184 <- summary(model.output.arc.excl184.q2)

# Model for excl184 Q3
model.output.arc.excl184.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP184 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl184 <- summary(model.output.arc.excl184.q3)
cat('Model number 184 processed\n')

# Model for excl185 Q1
model.output.arc.excl185.q1 <- glmer(PA_ARCX_EXCL_TOP185 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl185 <- summary(model.output.arc.excl185.q1)

# Data prep Q2,Q3 for excl185
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 185)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 185), paste0('RELABUN_ARCX_EXCL_TOP', 185), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP185 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 185)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP185 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 185)]))

# Model for excl185 Q2
model.output.arc.excl185.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP185 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl185 <- summary(model.output.arc.excl185.q2)

# Model for excl185 Q3
model.output.arc.excl185.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP185 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl185 <- summary(model.output.arc.excl185.q3)
cat('Model number 185 processed\n')

# Model for excl186 Q1
model.output.arc.excl186.q1 <- glmer(PA_ARCX_EXCL_TOP186 ~ YEARs + NB_SPECIESs + LATs + LONs + TEMP10s + (1|CROP_TYPE) + (1|MONTH) + (1|Biblioref), family=binomial, data=awc_header_studyperiod, control = glmerControl(optimizer = 'bobyqa', optCtrl = list(maxfun = 1e5)))
summary.model.arc.q1.excl186 <- summary(model.output.arc.excl186.q1)

# Data prep Q2,Q3 for excl186
awc_header_studyperiod_invaded_arcx_excl <- subset(awc_header_studyperiod, get(paste0('RELABUN_ARCX_EXCL_TOP', 186)) > 0)
# Selecting relevant columns
relevant_cols <- c('YEAR', 'LAT', 'LON', 'TEMP10', paste0('NB_ARCXS_EXCL_TOP', 186), paste0('RELABUN_ARCX_EXCL_TOP', 186), 'NB_SPECIES', 'MONTH', 'Biblioref', 'CROP_TYPE')
awc_header_studyperiod_invaded_arcx_excl <- awc_header_studyperiod_invaded_arcx_excl[, relevant_cols]
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RATIO_ARCX_EXCL_TOP186 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('NB_ARCXS_EXCL_TOP', 186)] / awc_header_studyperiod_invaded_arcx_excl$NB_SPECIES))
awc_header_studyperiod_invaded_arcx_excl$ASIN_SQRT_RELABUN_ARCX_EXCL_TOP186 <- asin(sqrt(awc_header_studyperiod_invaded_arcx_excl[, paste0('RELABUN_ARCX_EXCL_TOP', 186)]))

# Model for excl186 Q2
model.output.arc.excl186.q2 <- lmerTest::lmer(ASIN_SQRT_RATIO_ARCX_EXCL_TOP186 ~ YEAR + LAT + LON + TEMP10 + (1|MONTH) + (1|Biblioref) + (1|CROP_TYPE), data=awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q2.excl186 <- summary(model.output.arc.excl186.q2)

# Model for excl186 Q3
model.output.arc.excl186.q3 <- lmerTest::lmer(ASIN_SQRT_RELABUN_ARCX_EXCL_TOP186 ~ YEAR + LAT + LON + TEMP10 + (1|Biblioref) + (1|MONTH) + (1|CROP_TYPE), data = awc_header_studyperiod_invaded_arcx_excl)
summary.model.arc.q3.excl186 <- summary(model.output.arc.excl186.q3)
cat('Model number 186 processed\n')